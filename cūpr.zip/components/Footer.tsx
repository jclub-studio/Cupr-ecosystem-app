import Link from 'next/link';

export function Footer() {
  return (
    <footer className="border-t border-white/10 mt-24 py-12 px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 lg:gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Link href="/" className="text-2xl font-mono tracking-widest uppercase">
            CŪPR
          </Link>
          <p className="text-sm text-white/50 max-w-sm font-light leading-relaxed">
            Cannabis Ūtility Performance Research. Sophisticated hardware and software ecosystem for the modern, active consumer.
          </p>
        </div>
        
        <div className="space-y-4">
          <h4 className="text-xs uppercase tracking-[0.1em] text-white/40">B2C Ecosystem</h4>
          <nav className="flex flex-col space-y-3">
            <Link href="/hardgoods" className="text-sm font-light text-white/70 hover:text-white transition-colors">Hardgoods</Link>
            <Link href="/softgoods" className="text-sm font-light text-white/70 hover:text-white transition-colors">Softgoods</Link>
            <Link href="/consumables" className="text-sm font-light text-white/70 hover:text-white transition-colors">Consumables</Link>
            <Link href="/budbook" className="text-sm font-light text-white/70 hover:text-white transition-colors">Mobile Apps</Link>
            <Link href="/proprietary" className="text-sm font-light text-white/70 hover:text-white transition-colors">Proprietary</Link>
          </nav>
        </div>

        <div className="space-y-4">
          <h4 className="text-xs uppercase tracking-[0.1em] text-white/40">B2B Solutions</h4>
          <nav className="flex flex-col space-y-3">
            <Link href="/web-dev" className="text-sm font-light text-white/70 hover:text-white transition-colors">Web Dev</Link>
            <Link href="/integration" className="text-sm font-light text-white/70 hover:text-white transition-colors">Integration</Link>
            <Link href="/promotion" className="text-sm font-light text-white/70 hover:text-white transition-colors">Promotion</Link>
            <Link href="/print-media" className="text-sm font-light text-white/70 hover:text-white transition-colors">Print Media</Link>
            <Link href="/data-insights" className="text-sm font-light text-white/70 hover:text-white transition-colors">Data Insights</Link>
          </nav>
        </div>

        <div className="space-y-4">
          <h4 className="text-xs uppercase tracking-[0.1em] text-white/40">Company</h4>
          <nav className="flex flex-col space-y-3">
            <Link href="/" className="text-sm font-light text-white/70 hover:text-white transition-colors">Intro</Link>
            <Link href="/market" className="text-sm font-light text-white/70 hover:text-white transition-colors">Vantage</Link>
            <Link href="/story" className="text-sm font-light text-white/70 hover:text-white transition-colors">Origin</Link>
            <Link href="/join" className="text-sm font-light text-white/70 hover:text-white transition-colors">Join</Link>
          </nav>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-xs text-white/30 tracking-wide font-mono uppercase">
          © {new Date().getFullYear()} CŪPR. All rights reserved.
        </p>
        <div className="flex items-center space-x-6 text-xs text-white/30 tracking-wide font-mono uppercase">
          <a href="#" className="hover:text-white">Privacy</a>
          <a href="#" className="hover:text-white">Terms</a>
        </div>
      </div>
    </footer>
  );
}
