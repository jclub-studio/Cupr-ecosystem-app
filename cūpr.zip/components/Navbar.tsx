'use client';

import Link from 'next/link';
import { Menu, X, ChevronDown } from 'lucide-react';
import { useState } from 'react';
import { usePathname } from 'next/navigation';
import { AnimatePresence, motion } from 'motion/react';
import { ThemeToggle } from './ThemeToggle';

const NAV_LINKS = [
  { href: '/', label: 'INTRO' },
  { href: '/market', label: 'VANTAGE' },
  {
    href: '#',
    label: 'SOLUTIONS',
    dropdown: true,
    categories: [
      {
        title: 'B2C',
        links: [
          { href: '/hardgoods', label: 'Hardgoods' },
          { href: '/softgoods', label: 'Softgoods' },
          { href: '/consumables', label: 'Consumables' },
          { href: '/budbook', label: 'Mobile Apps' },
          { href: '/proprietary', label: 'Proprietary', special: true },
        ],
      },
      {
        title: 'B2B',
        links: [
          { href: '/web-dev', label: 'Web Dev' },
          { href: '/integration', label: 'Integration' },
          { href: '/promotion', label: 'Promotion' },
          { href: '/print-media', label: 'Print Media' },
          { href: '/data-insights', label: 'Data Insights' },
        ],
      },
    ],
  },
  { href: '/story', label: 'ORIGIN' },
];

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [isSolutionsHovered, setIsSolutionsHovered] = useState(false);
  const [isMobileSolutionsOpen, setIsMobileSolutionsOpen] = useState(false);
  const pathname = usePathname();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 mix-blend-difference border-b border-white/10 bg-black/50 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <Link href="/" className="text-xl font-mono tracking-widest uppercase relative z-10">
          CŪPR
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center space-x-8">
          {NAV_LINKS.map((link) => {
            if (link.dropdown) {
              const isActive = pathname?.startsWith('/solutions') || pathname === '/hardgoods' || pathname === '/budbook' || pathname === '/softgoods' || pathname === '/consumables' || pathname === '/proprietary' || pathname === '/web-dev' || pathname === '/integration' || pathname === '/promotion' || pathname === '/print-media' || pathname === '/data-insights';
              return (
                <div 
                  key="solutions" 
                  className="group relative" 
                  onMouseEnter={() => setIsSolutionsHovered(true)} 
                  onMouseLeave={() => setIsSolutionsHovered(false)}
                >
                  <button className={`flex items-center gap-1 text-xs uppercase tracking-[0.1em] transition-colors py-8 ${isActive ? 'text-white' : 'text-white/50 group-hover:text-white'}`}>
                     {link.label}
                     <ChevronDown className="w-3 h-3 transition-transform group-hover:rotate-180" />
                     {isActive && (
                        <motion.div
                          layoutId="nav-indicator"
                          className="absolute bottom-0 left-0 right-0 h-0.5 bg-white"
                        />
                      )}
                  </button>
                  
                  <AnimatePresence>
                    {isSolutionsHovered && (
                       <motion.div
                         initial={{ opacity: 0, y: 10, scale: 0.95 }}
                         animate={{ opacity: 1, y: 0, scale: 1 }}
                         exit={{ opacity: 0, y: 10, scale: 0.95 }}
                         transition={{ duration: 0.2, ease: "easeOut" }}
                         className="absolute top-full left-1/2 -translate-x-1/2 w-[600px] bg-black/95 backdrop-blur-3xl border border-white/10 p-8 grid grid-cols-2 gap-12 rounded-xl shadow-2xl overflow-hidden before:absolute before:inset-0 before:bg-gradient-to-b before:from-white/5 before:to-transparent before:pointer-events-none"
                       >
                          {link.categories?.map(category => (
                             <div key={category.title} className="relative z-10">
                                <h4 className="text-white/40 text-[10px] tracking-[0.2em] font-mono uppercase mb-6 drop-shadow-sm">{category.title}</h4>
                                <ul className="space-y-4">
                                   {category.links.map(sublink => (
                                      <li key={sublink.href}>
                                         <Link 
                                            href={sublink.href}
                                            className={`block text-xs uppercase tracking-[0.1em] ${sublink.special ? 'text-white/70 hover:text-white hover:drop-shadow-[0_0_8px_rgba(200,200,255,0.6)] transition-all duration-300' : 'text-white/50 hover:text-white transition-colors duration-200'}`}
                                         >
                                            <span className={sublink.special ? 'relative inline-block hover:after:absolute hover:after:inset-0 hover:after:bg-gradient-to-r hover:after:from-transparent hover:after:via-white/30 hover:after:to-transparent hover:after:bg-[length:200%_100%] hover:after:animate-[shine_1.5s_ease-in-out_infinite]' : ''}>
                                              {sublink.label}
                                            </span>
                                         </Link>
                                      </li>
                                   ))}
                                </ul>
                             </div>
                          ))}
                       </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            }

            return (
              <Link
                key={link.href}
                href={link.href}
                className={`text-xs uppercase tracking-[0.1em] transition-colors relative py-8 ${
                  pathname === link.href ? 'text-white' : 'text-white/50 hover:text-white'
                }`}
              >
                {link.label}
                {pathname === link.href && (
                  <motion.div
                    layoutId="nav-indicator"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-white"
                  />
                )}
              </Link>
            )
          })}
          <div className="flex items-center gap-4 ml-4">
            <ThemeToggle />
            <Link href="/join" className="nav-pill border border-white/30 rounded-full px-5 py-2 text-xs uppercase tracking-widest text-white hover:bg-white hover:text-black transition-colors block w-fit">
              JOIN
            </Link>
          </div>
        </nav>

        {/* Mobile Toggle */}
        <button
          className="md:hidden relative z-10 text-white"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-0 left-0 right-0 h-[100dvh] bg-black overflow-y-auto flex flex-col pt-24 px-6 pb-20"
          >
            <div className="flex flex-col space-y-6">
              {NAV_LINKS.map((link) => {
                if (link.dropdown) {
                  return (
                    <div key="mobile-solutions" className="space-y-4">
                      <button 
                        onClick={() => setIsMobileSolutionsOpen(!isMobileSolutionsOpen)}
                        className="w-full flex items-center justify-between text-2xl font-light tracking-wide text-white/50"
                      >
                        {link.label}
                        <ChevronDown className={`w-6 h-6 transition-transform ${isMobileSolutionsOpen ? 'rotate-180' : ''}`} />
                      </button>
                      <AnimatePresence>
                        {isMobileSolutionsOpen && (
                          <motion.div 
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden"
                          >
                            <div className="pl-6 border-l border-white/10 space-y-8 py-4">
                              {link.categories?.map(cat => (
                                <div key={cat.title} className="space-y-4">
                                  <h4 className="text-[10px] font-mono tracking-widest uppercase text-white/30">{cat.title}</h4>
                                  <ul className="space-y-4">
                                    {cat.links.map(sublink => (
                                      <li key={sublink.href}>
                                        <Link
                                          href={sublink.href}
                                          onClick={() => setIsOpen(false)}
                                          className={`block text-xl font-light tracking-wide ${sublink.special ? 'text-white drop-shadow-[0_0_8px_rgba(200,200,255,0.4)]' : 'text-white/80'}`}
                                        >
                                          {sublink.label}
                                        </Link>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                }
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setIsOpen(false)}
                    className={`text-2xl font-light tracking-wide ${
                      pathname === link.href ? 'text-white' : 'text-white/50'
                    }`}
                  >
                    {link.label}
                  </Link>
                );
              })}
              <Link href="/join" onClick={() => setIsOpen(false)} className="mt-8 border text-center border-white/30 rounded-full px-8 py-3 text-sm uppercase tracking-widest text-white hover:bg-white hover:text-black transition-colors w-full max-w-xs self-center">
                 JOIN
              </Link>
              <div className="flex justify-center mt-4">
                 <ThemeToggle />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
