'use client';

import { motion } from 'motion/react';

export default function MarketOpportunity() {
  return (
    <div className="flex flex-col w-full overflow-hidden">
      
      {/* Hero Header */}
      <section className="pt-32 pb-20 px-6 max-w-7xl mx-auto w-full border-b border-white/10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-6"
        >
          <span className="text-xs uppercase tracking-[0.2em] font-mono text-neutral-500">
            Market Opportunity
          </span>
          <h1 className="text-5xl md:text-7xl font-light tracking-tighter leading-tight">
            The White Space <br />
            <span className="italic text-neutral-400">in Cannabis Tech.</span>
          </h1>
          <p className="max-w-2xl text-neutral-400 font-light leading-relaxed text-lg pt-4">
            The cannabis accessory market is expanding rapidly, yet it remains fragmented by low-quality novelty goods. CŪPR is positioned to capture the high-end, data-driven consumer segment.
          </p>
        </motion.div>
      </section>

      {/* Data Section */}
      <section className="py-24 px-6 bg-neutral-950">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16 md:gap-8 min-h-[400px]">
          {/* Left: Text & Pitch */}
          <div className="space-y-8 flex flex-col justify-center">
            <h2 className="text-3xl font-light tracking-tight">An Untapped Premium Segment</h2>
            <p className="text-neutral-400 font-light leading-relaxed">
              As legalization spreads and social stigmas dissolve, the consumer base has rapidly matured. Today&apos;s cannabis consumers are health-conscious professionals who track their sleep, optimize their fitness, and appreciate minimalist, premium consumer electronics.
            </p>
            <p className="text-neutral-400 font-light leading-relaxed">
              Despite this evolution, the hardware market has not kept pace. Existing solutions lack aesthetic intelligence, robust digital integration, and functional longevity. CŪPR answers this demand with a unified hardware-software ecosystem.
            </p>
          </div>

          {/* Right: Data Visualization Placeholder */}
          <div className="relative border border-white/10 rounded-3xl p-8 bg-black flex flex-col justify-between overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-neutral-900/50 to-transparent pointer-events-none" />
            <div className="relative z-10 flex justify-between items-end pb-8 border-b border-white/10">
              <span className="text-sm font-mono text-neutral-500 uppercase tracking-widest">Growth Trajectory</span>
              <span className="text-4xl font-mono tracking-tighter">$42B+</span>
            </div>
            
            <div className="relative z-10 mt-12 grid grid-cols-3 gap-4 items-end h-40">
              <div className="w-full bg-neutral-800 rounded-t-sm h-[40%]" />
              <div className="w-full bg-neutral-600 rounded-t-sm h-[65%]" />
              <div className="w-full bg-white rounded-t-sm h-[100%] relative">
                <div className="absolute -top-8 left-1/2 -translate-x-1/2 text-xs font-mono text-black bg-white px-2 py-1 rounded shadow-[0_0_15px_rgba(255,255,255,0.4)]">
                  CŪPR TAM
                </div>
              </div>
            </div>
            <div className="relative z-10 flex justify-between mt-4 text-[10px] uppercase font-mono text-neutral-500">
              <span>Novlety (Declining)</span>
              <span>Mid-Tier</span>
              <span>Premium Tech</span>
            </div>
          </div>
        </div>
      </section>

      {/* Positioning Framework */}
      <section className="py-32 px-6">
        <div className="max-w-7xl mx-auto space-y-16">
          <div className="border-b border-white/10 pb-4">
            <h3 className="text-lg uppercase tracking-widest font-mono text-neutral-500 mb-2">Strategic Positioning</h3>
            <p className="text-2xl font-light">Where performance meets lifestyle.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
             {[
               { title: 'The Problem', text: 'Stigmatized, flashy, inefficient novelty items that break quickly and provide zero feedback.' },
               { title: 'The Consumer', text: 'Highly active, sophisticated, values privacy, sleek aesthetics, and data tracking (like Whoop/Oura).' },
               { title: 'The Solution', text: 'Minimalist, meticulously engineered devices combined with powerful companion software.' },
               { title: 'The Moat', text: 'Proprietary patent-pending hardware and an integrated ecosystem that competitors cannot easily replicate.' },
             ].map((block, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1, duration: 0.6 }}
                  className="p-6 border border-white/10 rounded-2xl bg-neutral-950/20 hover:bg-neutral-900 transition-colors"
                >
                  <h4 className="text-xs uppercase font-mono tracking-widest text-white/50 mb-4 pb-4 border-b border-white/5">{block.title}</h4>
                  <p className="text-sm text-neutral-300 font-light leading-relaxed">{block.text}</p>
                </motion.div>
             ))}
          </div>
        </div>
      </section>

    </div>
  );
}
