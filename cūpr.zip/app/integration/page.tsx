'use client';

import { motion } from 'motion/react';
import { ArrowDown, Globe, MapPin, Search, Store, ShoppingBag, Truck, Zap, Activity, ScanLine, ShieldX, Box, Building2, Camera, Wand2, Smartphone } from 'lucide-react';

const DIGITAL_PLATFORMS = [
  { icon: Globe, name: 'BudBook Profiles', desc: 'Claim and optimize your verified hub within the CŪPR ecosystem.' },
  { icon: MapPin, name: 'Google Business', desc: 'Synchronized hours, menus, and reviews for local SEO dominance.' },
  { icon: Smartphone, name: 'Apple Business Connect', desc: 'Manage your location presence across Apple Maps, Siri, and Wallet.' },
  { icon: Search, name: 'Snapchat & Yelp Optimization', desc: 'Reputation management, Snap Map visibility, and uniform data presentation.' },
  { icon: Activity, name: 'Weedmaps & Leafly', desc: 'Real-time menu syncing and platform-specific profile enhancement.' },
  { icon: Store, name: 'Dutchie Systems', desc: 'Seamless integration with your existing POS and online ordering.' },
  { icon: ShoppingBag, name: 'E-Commerce & Pickup', desc: 'Frictionless click-and-collect workflows for in-store pickup.' },
  { icon: Truck, name: 'Delivery Outfitting', desc: 'Logistics integration, fleet management routing, and digital outfitting.' }
];

export default function IntegrationPage() {
  return (
    <div className="flex flex-col w-full overflow-hidden relative">
      
      {/* Hero Section */}
      <section className="relative min-h-[70vh] flex flex-col justify-center px-6 border-b border-white/10 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-neutral-800/30 via-black to-black pointer-events-none" />
        
        <div className="max-w-7xl mx-auto w-full relative z-10 space-y-8 mt-16">
          <span className="font-mono text-xs uppercase tracking-[0.2em] text-neutral-500">B2B Solutions</span>
          <h1 className="text-6xl md:text-8xl font-light tracking-tighter">
            Omnichannel <br className="hidden md:block"/>
            <span className="italic text-neutral-500">Ecosystem.</span>
          </h1>
          <p className="max-w-xl text-neutral-400 font-light text-lg leading-relaxed">
            Eliminate fragmented data. We seamlessly connect your physical retail operations with the industry&apos;s most critical digital platforms, creating a unified, high-performing presence.
          </p>
          
          <div className="pt-12 text-neutral-600 animate-bounce">
            <ArrowDown className="w-6 h-6" />
          </div>
        </div>
      </section>

      {/* Digital Presence Grid */}
      <section className="py-32 px-6 border-b border-white/10">
        <div className="max-w-7xl mx-auto">
          <div className="mb-20 space-y-4">
            <h2 className="text-3xl font-light tracking-tight">The Unified Digital Presence</h2>
            <p className="text-neutral-400 font-light max-w-2xl">
              Inconsistent hours, menus, and branding cost you customers. We standardize and maintain your digital footprint across every critical touchpoint, ensuring perfect data parity.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {DIGITAL_PLATFORMS.map((platform, i) => {
              const Icon = platform.icon;
              return (
                <motion.div 
                  key={platform.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="p-8 bg-neutral-950 border border-white/10 rounded-2xl flex flex-col hover:bg-neutral-900 transition-colors group"
                >
                  <Icon className="w-8 h-8 text-neutral-500 mb-6 group-hover:text-white transition-colors" />
                  <h3 className="text-lg font-medium text-white mb-3">{platform.name}</h3>
                  <p className="text-sm text-neutral-500 font-light leading-relaxed">{platform.desc}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* BudBook Pro Partners Integration */}
      <section className="py-32 px-6 border-b border-white/10 relative overflow-hidden">
        {/* Background Graphic */}
        <div className="absolute top-1/2 right-0 -translate-y-1/2 translate-x-1/4 w-[800px] h-[800px] bg-neutral-900/50 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center relative z-10">
          <div className="order-2 lg:order-1 relative aspect-square md:aspect-[4/3] rounded-2xl border border-white/10 overflow-hidden bg-[#0a0a0a] flex items-center justify-center p-8">
            <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:2rem_2rem]" />
            
            {/* Mock Data Display UI */}
            <div className="w-full max-w-sm space-y-4 relative z-10">
              <div className="p-4 border border-white/10 rounded-xl bg-black/50 backdrop-blur-md">
                <div className="flex justify-between items-center mb-4 border-b border-white/5 pb-2">
                  <span className="text-xs font-mono text-neutral-500 uppercase">Analysis: Northern Lights</span>
                  <ScanLine className="w-4 h-4 text-white" />
                </div>
                <div className="space-y-3">
                  {['Myrcene (1.2%)', 'Pinene (0.8%)', 'Caryophyllene (0.5%)'].map((terp, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-[10px] font-mono text-neutral-400">
                        <span>{terp.split(' ')[0]}</span>
                        <span>{terp.split(' ')[1]}</span>
                      </div>
                      <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          whileInView={{ width: `${100 - (idx * 25)}%` }}
                          transition={{ duration: 1, delay: 0.5 + (idx * 0.2) }}
                          className="h-full bg-white" 
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="order-1 lg:order-2 space-y-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 text-xs font-mono uppercase tracking-widest">
              <Zap className="w-4 h-4 text-yellow-500" />
              BudBook Pro
            </div>
            <h2 className="text-4xl md:text-5xl font-light tracking-tight">
              Enhanced Analytical Display
            </h2>
            <p className="text-lg text-neutral-400 font-light leading-relaxed">
              Standard menus only tell half the story. Our BudBook Pro integration provides producers and dispensaries the tools to display deep-dive analytics directly to consumers.
            </p>
            <ul className="space-y-4 pt-4">
              {[
                'Full terpene profiling and lab analysis visualization.',
                'Interactive strain lineage and genetics mapping.',
                'Rich media upload for unboxing and trichome macro shots.',
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-4 text-neutral-300 font-light">
                  <span className="font-mono text-neutral-600 mt-1">0{i + 1}</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Generative AI Product Rendering */}
      <section className="py-32 px-6 border-b border-white/10 relative overflow-hidden bg-neutral-950">
        <div className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-white/[0.03] rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center relative z-10">
          
          <div className="order-2 lg:order-2 relative aspect-[4/3] rounded-2xl border border-white/10 overflow-hidden bg-[#050505] flex items-center justify-center p-8 group">
            {/* Abstract AI Scanning UI */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent opacity-50" />
            
            <div className="relative w-full max-w-sm">
              <div className="aspect-square rounded-xl border border-white/20 p-2 relative overflow-hidden flex items-center justify-center backdrop-blur-md">
                {/* Scanning line animation */}
                <motion.div 
                  animate={{ y: ['-100%', '100%'] }}
                  transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                  className="absolute left-0 right-0 h-1 bg-white/50 shadow-[0_0_15px_rgba(255,255,255,0.8)] z-20"
                />
                
                {/* Placeholder 3D shape / vase */}
                <div className="w-3/4 h-3/4 bg-white/5 rounded-full blur-md absolute"></div>
                <div className="w-1/2 h-1/2 border border-white/20 rounded-lg rotate-12 relative z-10"></div>
                
                {/* Generation specs overlay */}
                <div className="absolute bottom-4 left-4 right-4 flex justify-between text-[10px] font-mono text-neutral-400 z-20">
                  <span className="flex items-center gap-1"><Camera className="w-3 h-3" /> Input</span>
                  <span className="flex items-center gap-1"><Wand2 className="w-3 h-3" /> 1:1 Generated</span>
                </div>
              </div>
            </div>
          </div>

          <div className="order-1 lg:order-1 space-y-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 text-xs font-mono uppercase tracking-widest text-neutral-300">
              <Wand2 className="w-4 h-4 text-white" />
              Generative AI
            </div>
            <h2 className="text-4xl md:text-5xl font-light tracking-tight">
              AI-Powered Product <br /> Representation
            </h2>
            <p className="text-lg text-neutral-400 font-light leading-relaxed">
              Create flawless digital storefronts without a photography studio. By taking a simple photo or uploading an image, CŪPR&apos;s AI intelligently generates striking product imagery.
            </p>
            <ul className="space-y-4 pt-4 border-t border-white/10">
              {[
                'Showcase products from any angle with perfect studio lighting.',
                'Verified 1:1 dimensional accuracy backed by our extensive product scan database.',
                'Empowers owners to easily curate how their physical inventory is represented online.',
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-4 text-neutral-300 font-light">
                  <span className="font-mono text-neutral-600 mt-1">0{i + 1}</span>
                  <span className="leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* High-Risk Payments & POS */}
      <section className="py-32 px-6 border-b border-white/10 relative overflow-hidden">
        <div className="absolute top-1/2 left-0 -translate-y-1/2 -translate-x-1/4 w-[800px] h-[800px] bg-neutral-900/40 rounded-full blur-[120px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center relative z-10">
          <div className="order-2 lg:order-1 space-y-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 text-xs font-mono uppercase tracking-widest">
               <Zap className="w-4 h-4 text-emerald-500" />
               E-Commerce Infrastructure
            </div>
            <h2 className="text-4xl md:text-5xl font-light tracking-tight">
              High-Risk Payment & <br /> POS Compatibility
            </h2>
            <p className="text-lg text-neutral-400 font-light leading-relaxed">
              Standard e-commerce platforms often reject industry transactions. CŪPR&apos;s bespoke web solutions are engineered from the ground up for native compatibility with high-risk payment processors and specialized POS platforms.
            </p>
            <ul className="space-y-4 pt-4 border-t border-white/10">
              {[
                'Seamless handshake with industry-standard POS (Dutchie, Flowhub, Treez).',
                'Pre-configured for compliant, high-risk merchant account gateways.',
                'Secure, reliable transaction routing protecting your revenue stream.',
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-4 text-neutral-300 font-light">
                  <span className="font-mono text-neutral-600 mt-1">0{i + 1}</span>
                  <span className="leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="order-1 lg:order-2 relative aspect-[4/3] rounded-2xl border border-white/10 overflow-hidden bg-neutral-950 flex flex-col items-center justify-center p-8 group">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-transparent opacity-50" />
            
            {/* Abstract POS Data Flow */}
            <div className="w-full max-w-sm border border-white/10 rounded-xl bg-black/80 backdrop-blur p-6 relative z-10 shadow-2xl">
              <div className="flex items-center justify-between mb-8 pb-4 border-b border-white/5">
                 <span className="text-xs font-mono text-neutral-500 uppercase tracking-widest">Gateway Status</span>
                 <div className="flex items-center gap-2">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    <span className="text-xs font-mono text-emerald-500">SECURE</span>
                 </div>
              </div>
              
              <div className="space-y-4">
                 {[
                   { label: 'POS Sync', value: 'Connected', icon: Store },
                   { label: 'Merchant ID', value: 'Verified', icon: ShieldX },
                   { label: 'Compliance Protocol', value: 'Active', icon: Activity }
                 ].map((stat, idx) => {
                   const StatIcon = stat.icon;
                   return (
                     <div key={idx} className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02] border border-white/5">
                        <div className="flex items-center gap-3">
                          <StatIcon className="w-4 h-4 text-neutral-400" />
                          <span className="text-sm font-light text-neutral-300">{stat.label}</span>
                        </div>
                        <span className="text-xs font-mono text-neutral-500 uppercase">{stat.value}</span>
                     </div>
                   )
                 })}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Smokeshop/Headshop Integration */}
      <section className="py-32 px-6">
        <div className="max-w-7xl mx-auto space-y-20">
          
          <div className="text-center max-w-3xl mx-auto space-y-6">
            <h2 className="text-4xl md:text-5xl font-light tracking-tight">The CŪPR Distribution Network</h2>
            <p className="text-lg text-neutral-400 font-light leading-relaxed">
              We are transforming smokeshop e-commerce. By hosting your online inventory on the CŪPR distribution platform, we connect local shops directly with domestic consumers, expanding your reach beyond foot traffic.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 border border-white/10 rounded-2xl bg-neutral-950 flex flex-col items-center text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-black border border-white/10 flex items-center justify-center mb-4">
                <Box className="w-8 h-8 text-neutral-400" />
              </div>
              <h3 className="text-xl font-medium">Domestic Supply Chain</h3>
              <p className="text-sm text-neutral-500 font-light leading-relaxed">
                Stop relying on overseas imports with zero brand equity. We promote locally stocked, premium accessories shipped faster and more reliably.
              </p>
            </div>
            
            <div className="p-8 border border-white/10 rounded-2xl bg-neutral-950 flex flex-col items-center text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-black border border-white/10 flex items-center justify-center mb-4">
                <Building2 className="w-8 h-8 text-neutral-400" />
              </div>
              <h3 className="text-xl font-medium">B2B Storefronts</h3>
              <p className="text-sm text-neutral-500 font-light leading-relaxed">
                Smokeshops receive a dedicated portal on CŪPR, instantly indexing their localized inventory to our wider national audience.
              </p>
            </div>

            <div className="p-8 border border-white/10 rounded-2xl bg-neutral-950 flex flex-col items-center text-center space-y-4 relative overflow-hidden">
              <div className="absolute inset-0 bg-red-500/5 mix-blend-overlay" />
              <div className="w-16 h-16 rounded-full bg-black border border-red-500/30 flex items-center justify-center mb-4 relative z-10">
                <ShieldX className="w-8 h-8 text-red-500" />
              </div>
              <h3 className="text-xl font-medium text-red-500 relative z-10">Strict Curation</h3>
              <p className="text-sm font-light text-red-500/80 leading-relaxed relative z-10">
                A strictly enforced platform standard. Absolutely no tobacco, nicotine, or spacegas products will ever be listed or permitted on the network.
              </p>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}