'use client';

import { motion } from 'motion/react';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import Image from 'next/image';

export default function Home() {
  return (
    <div className="flex flex-col w-full overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex flex-col items-center justify-center px-6 text-center">
        {/* Abstract dark tech background elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
           <div className="absolute top-[20%] left-[50%] -translate-x-[50%] w-[800px] h-[800px] bg-neutral-900/40 rounded-full blur-[120px] mix-blend-screen" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10 max-w-4xl space-y-8"
        >
          <div className="flex justify-center mb-8">
            <span className="border border-white/20 rounded-full px-4 py-1 text-[10px] uppercase tracking-[0.2em] text-white/70 font-mono">
              Cannabis Ūtility Performance Research
            </span>
          </div>

          <h1 className="text-5xl md:text-7xl lg:text-8xl font-light tracking-tighter leading-[0.9]">
            Utility and <br className="hidden md:block" />
            <span className="italic text-neutral-400">Performance.</span>
          </h1>

          <p className="text-base md:text-xl font-light text-neutral-400 max-w-2xl mx-auto leading-relaxed">
            Redefining the active-lifestyle cannabis experience through precision engineering, proprietary hardware, and data-driven insights. Built for those who demand more from their rituals.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mt-12 pt-8">
            <Link 
              href="/hardware"
              className="group flex items-center justify-between w-full sm:w-[220px] bg-white text-black px-6 py-4 rounded-full text-xs uppercase tracking-widest font-medium hover:bg-neutral-200 transition-colors"
            >
              Explore Hardware
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link 
              href="/market"
              className="group flex items-center justify-between w-full sm:w-[220px] bg-transparent text-white border border-white/30 px-6 py-4 rounded-full text-xs uppercase tracking-widest font-medium hover:bg-white/5 transition-colors"
            >
              The Market Gap
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Mission Statement Section */}
      <section className="py-32 px-6 border-t border-white/10 bg-neutral-950">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1 }}
            className="space-y-8"
          >
            <h2 className="text-sm font-mono uppercase tracking-[0.15em] text-neutral-500">
              01 // The Mission
            </h2>
            <h3 className="text-3xl md:text-5xl font-light leading-tight tracking-tight">
              Sophisticated utility,<br />
              <span className="text-neutral-500 italic">not just novelty.</span>
            </h3>
            <p className="text-neutral-400 font-light leading-relaxed max-w-md text-sm md:text-base">
              The modern cannabis consumer has evolved. They are athletes, professionals, and creatives who integrate cannabis into an active lifestyle. Yet, the accessory market remains saturated with novelty items that fail to meet their aesthetic and functional standards.
            </p>
            <p className="text-neutral-400 font-light leading-relaxed max-w-md text-sm md:text-base">
              CŪPR bridges this gap by engineering high-end, intelligent hardware and software ecosystems designed to optimize performance, track consumption, and elevate the ritual to a premium experience.
            </p>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            className="relative aspect-square md:aspect-[4/5] rounded-[2rem] overflow-hidden bg-neutral-900 border border-white/10"
          >
            {/* Placeholder for sleek hardware rendering */}
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-neutral-700 font-mono text-xs uppercase tracking-widest">[ Abstract Hardware Render ]</span>
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
          </motion.div>
        </div>
      </section>

      {/* Philosophy / Features Grid */}
      <section className="py-32 px-6 border-t border-white/10">
        <div className="max-w-7xl mx-auto space-y-20">
          <div className="text-center space-y-4">
            <h2 className="text-sm font-mono uppercase tracking-[0.15em] text-neutral-500">
              The CŪPR Ecosystem
            </h2>
            <p className="text-2xl font-light tracking-tight">A holistic approach to modern consumption.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                id: '01',
                title: 'Data-Driven Design',
                desc: 'Every curve and material is chosen not just for aesthetics, but for measurable utility and longevity.',
              },
              {
                id: '02',
                title: 'Intelligent Software',
                desc: 'BudBook syncs perfectly with your lifestyle, giving you deep insights into strains, sessions, and effects.',
              },
              {
                id: '03',
                title: 'Premium Materials',
                desc: 'Aerospace-grade aluminums and medical-grade glass replace the standard novelty plastics.',
              }
            ].map((item, i) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: i * 0.1 }}
                className="p-8 rounded-[2rem] border border-white/10 bg-neutral-950/50 hover:bg-neutral-900/50 transition-colors flex flex-col justify-between h-72"
              >
                <span className="text-neutral-600 font-mono text-xl">{item.id}</span>
                <div className="space-y-3">
                  <h4 className="text-lg font-medium">{item.title}</h4>
                  <p className="text-sm text-neutral-500 font-light leading-relaxed">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
