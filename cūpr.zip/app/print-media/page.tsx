'use client';

import { motion } from 'motion/react';

export default function PrintMediaPage() {
  return (
    <div className="flex flex-col w-full overflow-hidden relative">
      <section className="relative min-h-[60vh] flex flex-col justify-center px-6 border-b border-white/10 overflow-hidden bg-black">
        {/* Background Graphic */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-neutral-800/20 via-black to-black pointer-events-none" />
        
        <div className="max-w-7xl mx-auto w-full relative z-10 space-y-8 mt-16 text-center">
          <span className="font-mono text-xs uppercase tracking-[0.2em] text-neutral-500">
            Print Media
          </span>
          <h1 className="text-5xl md:text-7xl font-light tracking-tighter leading-[1.1] text-white">
            Analog <br className="hidden md:block"/>
            <span className="italic text-neutral-500">Permanence.</span>
          </h1>
          <p className="max-w-2xl mx-auto text-neutral-400 font-light text-lg md:text-xl leading-relaxed">
            A dual-format approach to consumption journaling. Premium physical notebooks for the ritualist, completing the CŪPR ecosystem.
          </p>
        </div>
      </section>

      {/* The Physical Tier */}
      <section className="py-24 px-6 bg-neutral-950">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="order-2 md:order-1 relative aspect-[3/4] max-w-md mx-auto w-full bg-neutral-900 border border-white/10 rounded-xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] overflow-hidden group flex flex-col justify-center items-center"
          >
            <span className="text-white/30 text-sm font-mono tracking-widest uppercase mb-4">Print Manual Preview</span>
            <div className="w-16 h-16 rounded-full border border-white/20 flex items-center justify-center bg-black/20">
               <span className="text-white/40 text-xs font-mono">PDF</span>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="order-1 md:order-2 space-y-6"
          >
            <h2 className="text-sm font-mono uppercase tracking-[0.15em] text-neutral-500">The Print Edition</h2>
            <h3 className="text-4xl font-light tracking-tight text-white">A tactile journaling experience.</h3>
            <p className="text-neutral-400 font-light leading-relaxed text-lg">
               Distributed exclusively through premium B2B dispensary partnerships, the BudBook print edition offers a tactile journaling experience. Bound in matte-finish, sustainable materials with minimal, scientific templating, it elevates the act of recording strains and effects.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}