import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { session_id, user_email } = await req.json();

        if (!session_id || !user_email) {
            return Response.json({ 
                success: false, 
                message: 'Session ID and user email are required' 
            }, { status: 400 });
        }

        // Verify the requesting user is the one being confirmed
        if (user.email !== user_email) {
            return Response.json({ 
                success: false, 
                message: 'You can only confirm your own participation' 
            }, { status: 403 });
        }

        // Use service role to update the session
        const session = await base44.asServiceRole.entities.Session.get(session_id);
        
        if (!session) {
            return Response.json({ 
                success: false, 
                message: 'Session not found' 
            }, { status: 404 });
        }

        // Check if user was actually invited
        if (!session.tagged_friends?.includes(user_email)) {
            return Response.json({ 
                success: false, 
                message: 'You were not invited to this session' 
            }, { status: 403 });
        }

        // Check if already confirmed
        if (session.confirmed_friends?.includes(user_email)) {
            return Response.json({ 
                success: true, 
                message: 'Participation already confirmed' 
            });
        }

        // Add user to confirmed_friends array
        const updatedConfirmedFriends = [...(session.confirmed_friends || []), user_email];
        
        await base44.asServiceRole.entities.Session.update(session_id, {
            confirmed_friends: updatedConfirmedFriends
        });

        return Response.json({ 
            success: true, 
            message: 'Participation confirmed successfully' 
        });

    } catch (error) {
        console.error('Error confirming session participation:', error);
        return Response.json({ 
            success: false, 
            message: 'Internal server error' 
        }, { status: 500 });
    }
});