import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { request_id, action } = await req.json();

        if (!request_id || !action) {
            return Response.json({ 
                success: false, 
                message: 'Request ID and action are required' 
            }, { status: 400 });
        }

        if (!['accept', 'decline'].includes(action)) {
            return Response.json({ 
                success: false, 
                message: 'Invalid action. Must be "accept" or "decline"' 
            }, { status: 400 });
        }

        // Get the friend request
        const friendRequest = await base44.entities.FriendRequest.get(request_id);

        if (!friendRequest) {
            return Response.json({ 
                success: false, 
                message: 'Friend request not found' 
            }, { status: 404 });
        }

        // Verify the current user is the receiver
        if (friendRequest.receiver_email !== user.email) {
            return Response.json({ 
                success: false, 
                message: 'You can only respond to requests sent to you' 
            }, { status: 403 });
        }

        // Update request status
        const newStatus = action === 'accept' ? 'accepted' : 'declined';
        await base44.entities.FriendRequest.update(request_id, {
            status: newStatus
        });

        // If accepted, update both users' friends lists
        if (action === 'accept') {
            // Get both users with service role to ensure we can update them
            const [senderUser, receiverUser] = await Promise.all([
                base44.asServiceRole.entities.User.filter({ email: friendRequest.sender_email }).then(users => users[0]),
                base44.asServiceRole.entities.User.filter({ email: friendRequest.receiver_email }).then(users => users[0])
            ]);

            if (senderUser && receiverUser) {
                // Update sender's friends list
                const senderFriends = senderUser.friends || [];
                if (!senderFriends.includes(receiverUser.email)) {
                    await base44.asServiceRole.entities.User.update(senderUser.id, {
                        friends: [...senderFriends, receiverUser.email]
                    });
                }

                // Update receiver's friends list
                const receiverFriends = receiverUser.friends || [];
                if (!receiverFriends.includes(senderUser.email)) {
                    await base44.asServiceRole.entities.User.update(receiverUser.id, {
                        friends: [...receiverFriends, senderUser.email]
                    });
                }
            }
        }

        return Response.json({ 
            success: true, 
            message: action === 'accept' ? 'Friend request accepted!' : 'Friend request declined'
        });

    } catch (error) {
        console.error('Error responding to friend request:', error);
        return Response.json({ 
            success: false, 
            message: 'Internal server error' 
        }, { status: 500 });
    }
});