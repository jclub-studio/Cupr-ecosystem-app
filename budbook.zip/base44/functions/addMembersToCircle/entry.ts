import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { circle_id, user_emails } = await req.json();

        if (!circle_id || !user_emails || !Array.isArray(user_emails)) {
            return Response.json({ 
                success: false, 
                message: 'circle_id and user_emails array are required' 
            }, { status: 400 });
        }

        // Get the circle
        const circle = await base44.entities.SmokeCircle.get(circle_id);

        if (!circle) {
            return Response.json({ 
                success: false, 
                message: 'Circle not found' 
            }, { status: 404 });
        }

        // Verify the current user is the owner
        if (circle.owner_email !== user.email) {
            return Response.json({ 
                success: false, 
                message: 'Only the circle owner can add members' 
            }, { status: 403 });
        }

        // Get current members
        const currentMembers = circle.members || [];
        const newMembers = [...currentMembers];
        const addedUsers = [];
        const skippedUsers = [];

        // Process each email
        for (const email of user_emails) {
            // Check if already a member
            if (currentMembers.includes(email)) {
                skippedUsers.push({ email, reason: 'Already a member' });
                continue;
            }

            // Verify user exists using service role
            const users = await base44.asServiceRole.entities.User.filter({ email });
            
            if (users.length === 0) {
                skippedUsers.push({ email, reason: 'User not found' });
                continue;
            }

            // Add to members list
            newMembers.push(email);
            addedUsers.push({
                email,
                username: users[0].username,
                full_name: users[0].full_name
            });
        }

        // Update the circle
        await base44.entities.SmokeCircle.update(circle_id, {
            members: newMembers
        });

        return Response.json({ 
            success: true, 
            message: `Successfully added ${addedUsers.length} member(s)`,
            added_users: addedUsers,
            skipped_users: skippedUsers
        });

    } catch (error) {
        console.error('Error adding members to circle:', error);
        return Response.json({ 
            success: false, 
            message: 'Internal server error' 
        }, { status: 500 });
    }
});