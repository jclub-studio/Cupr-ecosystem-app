import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { receiver_username, message } = await req.json();

        if (!receiver_username) {
            return Response.json({ 
                success: false, 
                message: 'Receiver username is required' 
            }, { status: 400 });
        }

        // Find the receiver by username using service role
        const receiverUsers = await base44.asServiceRole.entities.User.filter({ 
            username: receiver_username 
        });

        if (receiverUsers.length === 0) {
            return Response.json({ 
                success: false, 
                message: 'User not found' 
            }, { status: 404 });
        }

        const receiver = receiverUsers[0];

        // Prevent sending request to self
        if (receiver.email === user.email) {
            return Response.json({ 
                success: false, 
                message: 'Cannot send friend request to yourself' 
            }, { status: 400 });
        }

        // Check if they're already friends
        if (user.friends && user.friends.includes(receiver.email)) {
            return Response.json({ 
                success: false, 
                message: 'You are already friends with this user' 
            }, { status: 400 });
        }

        // Check if a pending request already exists
        const existingRequests = await base44.entities.FriendRequest.filter({
            sender_email: user.email,
            receiver_email: receiver.email,
            status: 'pending'
        });

        if (existingRequests.length > 0) {
            return Response.json({ 
                success: false, 
                message: 'Friend request already sent' 
            }, { status: 400 });
        }

        // Create friend request
        const friendRequest = await base44.entities.FriendRequest.create({
            sender_email: user.email,
            receiver_email: receiver.email,
            sender_username: user.username,
            receiver_username: receiver.username,
            status: 'pending',
            message: message || ''
        });

        return Response.json({ 
            success: true, 
            message: 'Friend request sent successfully',
            friend_request: friendRequest
        });

    } catch (error) {
        console.error('Error sending friend request:', error);
        return Response.json({ 
            success: false, 
            message: 'Internal server error' 
        }, { status: 500 });
    }
});