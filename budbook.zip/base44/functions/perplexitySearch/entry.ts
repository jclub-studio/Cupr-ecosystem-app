import { createClientFromRequest } from 'npm:@base44/sdk@0.7.0';

const PERPLEXITY_API_KEY = Deno.env.get("PERPLEXITY_API_KEY");
const API_URL = 'https://api.perplexity.ai/chat/completions';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        if (!user) {
            return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json' } });
        }

        const { query } = await req.json();
        if (!query) {
            return new Response(JSON.stringify({ error: 'Query parameter is required' }), { status: 400, headers: { 'Content-Type': 'application/json' } });
        }
        
        if (!PERPLEXITY_API_KEY) {
            return new Response(JSON.stringify({ error: 'Perplexity API key is not configured on the server.' }), { status: 500, headers: { 'Content-Type': 'application/json' } });
        }

        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${PERPLEXITY_API_KEY}`
            },
            body: JSON.stringify({
                model: 'llama-3.1-sonar-small-128k-online', // Updated to current available model
                messages: [
                    { role: 'system', content: 'You are a helpful assistant that provides concise and accurate information based on web searches. You are being used as a tool to find information about cannabis products and dispensaries.' },
                    { role: 'user', content: query }
                ]
            })
        });

        if (!response.ok) {
            const errorBody = await response.text();
            throw new Error(`Perplexity API Error: ${response.status} - ${errorBody}`);
        }

        const data = await response.json();
        const content = data.choices[0].message.content;

        return new Response(JSON.stringify({ result: content }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('perplexitySearch function error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { 'Content-Type': 'application/json' } });
    }
});