import { createClientFromRequest } from 'npm:@base44/sdk@0.7.0';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        // Basic auth check to ensure a user is logged in
        const user = await base44.auth.me();
        if (!user) {
            return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { 'Content-Type': 'application/json' } });
        }

        const { action, ...params } = await req.json();
        const apiKey = Deno.env.get("GOOGLE_PLACES_API_KEY");

        if (!apiKey) {
            throw new Error("Google Places API key is not configured on the server.");
        }

        let url;
        
        if (action === 'nearby') {
            const { latitude, longitude, radius = 50000 } = params;
            if (!latitude || !longitude) {
                throw new Error("Latitude and longitude are required for nearby search.");
            }
            // Use cannabis_store type with maximum radius for comprehensive search
            url = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${latitude},${longitude}&radius=${radius}&type=cannabis_store&keyword=dispensary&key=${apiKey}`;
        } else if (action === 'details') {
            const { place_id } = params;
            if (!place_id) {
                throw new Error("Place ID is required for details search.");
            }
            url = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${place_id}&fields=name,formatted_address,formatted_phone_number,website,opening_hours,rating,reviews,photos,geometry,url&key=${apiKey}`;
        } else {
            throw new Error("Invalid action specified.");
        }

        const response = await fetch(url);
        const data = await response.json();

        if (data.status !== 'OK' && data.status !== 'ZERO_RESULTS') {
            throw new Error(`Google Places API Error: ${data.status} - ${data.error_message || 'Unknown error'}`);
        }
        
        // Filter results to only include actual cannabis dispensaries
        if (action === 'nearby' && data.results) {
            data.results = data.results.filter(place => {
                // Check if the place is explicitly classified as a cannabis_store
                const isCannabisStore = place.types && place.types.includes('cannabis_store');
                
                // Additional name filtering to exclude obvious non-dispensaries
                const name = place.name.toLowerCase();
                const isLikelyDispensary = name.includes('dispensary') || 
                                         name.includes('cannabis') || 
                                         name.includes('marijuana') || 
                                         name.includes('medical') ||
                                         name.includes('recreational') ||
                                         name.includes('weed') ||
                                         name.includes('herb') ||
                                         name.includes('green') ||
                                         name.includes('leaf') ||
                                         name.includes('bud');
                
                // Exclude obvious non-dispensaries
                const isNotDispensary = name.includes('convenience') ||
                                       name.includes('gas station') ||
                                       name.includes('grocery') ||
                                       name.includes('mart') ||
                                       name.includes('shop') && !name.includes('cannabis') && !name.includes('dispensary');
                
                // Must be classified as cannabis_store OR have dispensary-like name, but not be an obvious non-dispensary
                return (isCannabisStore || isLikelyDispensary) && !isNotDispensary;
            });
        }
        
        // Create full photo URLs for easier frontend consumption
        if (action === 'details' && data.result && data.result.photos) {
            data.result.photos = data.result.photos.slice(0, 5).map(photo => {
                return `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${photo.photo_reference}&key=${apiKey}`;
            });
        }

        return new Response(JSON.stringify(data), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
        });

    } catch (error) {
        console.error('googlePlaces function error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { 'Content-Type': 'application/json' } });
    }
});