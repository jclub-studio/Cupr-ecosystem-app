import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
    let strain_name;
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        if (!user) {
            return new Response(JSON.stringify({ error: 'Unauthorized' }), { 
                status: 401, 
                headers: { 'Content-Type': 'application/json' } 
            });
        }

        const requestBody = await req.json();
        strain_name = requestBody.strain_name;

        if (!strain_name || strain_name.trim() === "") {
            return new Response(JSON.stringify({ error: 'Strain name is required' }), { 
                status: 400, 
                headers: { 'Content-Type': 'application/json' } 
            });
        }

        console.log(`[getStrainTerpenes] Searching for terpenes in strain: "${strain_name}"`);

        const prompt = `Research the cannabis strain "${strain_name}" using authoritative sources (like leafly, weedmaps, allbud) to find its most accurate terpene profile.

Provide the PRIMARY terpenes consistently reported across multiple trusted sources. Order them from most to least prominent based on consensus.

If no reliable information is found, return an empty array.`;

        const terpeneArray = await base44.integrations.Core.InvokeLLM({
            prompt: prompt,
            add_context_from_internet: true,
            response_json_schema: {
                type: "object",
                properties: {
                    terpenes: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                terpene_name: { type: "string" },
                                percentage: { type: "number" }
                            }
                        }
                    }
                }
            }
        });

        const validTerpenes = (terpeneArray.terpenes || []).filter(t => 
            t && typeof t.terpene_name === 'string' && t.terpene_name.trim()
        );

        console.log(`[getStrainTerpenes] Success: Found ${validTerpenes.length} terpenes for ${strain_name}.`);

        return new Response(JSON.stringify({ terpenes: validTerpenes }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error(`[getStrainTerpenes] Error for strain "${strain_name || 'unknown'}": ${error.message}`);
        return new Response(JSON.stringify({ error: error.message }), { 
            status: 500,
            headers: { 'Content-Type': 'application/json' } 
        });
    }
});