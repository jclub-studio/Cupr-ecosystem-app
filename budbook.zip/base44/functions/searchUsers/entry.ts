import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { search_query } = await req.json();

        if (!search_query || search_query.trim().length < 2) {
            return Response.json({ 
                success: false, 
                message: 'Search query must be at least 2 characters' 
            }, { status: 400 });
        }

        const query = search_query.trim().toLowerCase();

        // Search users by username (using service role to access all users)
        const allUsers = await base44.asServiceRole.entities.User.list();
        
        // Filter users by username match (case insensitive) and exclude current user
        const matchingUsers = allUsers
            .filter(u => 
                u.email !== user.email && 
                u.username && 
                u.username.toLowerCase().includes(query)
            )
            .slice(0, 20) // Limit results
            .map(u => ({
                id: u.id,
                username: u.username,
                full_name: u.full_name,
                profile_photo_url: u.profile_photo_url,
                bio: u.bio,
                email: u.email // Include for friend request purposes
            }));

        return Response.json({ 
            success: true, 
            users: matchingUsers
        });

    } catch (error) {
        console.error('Error searching users:', error);
        return Response.json({ 
            success: false, 
            message: 'Internal server error' 
        }, { status: 500 });
    }
});