import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { image_url } = await req.json();

        if (!image_url) {
            return Response.json({ 
                error: 'image_url is required',
                status: 'error'
            }, { status: 400 });
        }

        // Get all brands to help with matching
        const allBrands = await base44.asServiceRole.entities.Brand.list();

        const visionResponse = await fetch(
            `https://vision.googleapis.com/v1/images:annotate?key=${Deno.env.get('GOOGLE_VISION_API_KEY')}`,
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    requests: [{
                        image: { source: { imageUri: image_url } },
                        features: [{ type: 'TEXT_DETECTION' }]
                    }]
                })
            }
        );

        if (!visionResponse.ok) {
            throw new Error(`Vision API failed: ${visionResponse.status}`);
        }

        const visionData = await visionResponse.json();
        const rawText = visionData.responses?.[0]?.fullTextAnnotation?.text || '';

        if (!rawText) {
            return Response.json({
                status: 'error',
                error: 'No text found in image'
            }, { status: 400 });
        }

        // Create a brand matching context for the LLM
        const brandContext = allBrands.map(b => ({
            id: b.id,
            name: b.name,
            abbreviations: b.common_abbreviations || [],
            categories: b.primary_categories || []
        }));

        const structuredPrompt = `
Extract cannabis product information from this text found on a product label:

"${rawText}"

Available brands in database:
${JSON.stringify(brandContext, null, 2)}

Instructions:
1. Try to match the brand name from the text to one of the available brands by:
   - Exact name match
   - Matching common abbreviations
   - Fuzzy matching (e.g., "Phat Panda" vs "PHAT PANDA" vs "Panda")
2. If you find a match, return the brand_id and set brand_matched to true
3. If no match found, extract the brand name as text and set brand_matched to false
4. Extract all other product information
5. If you see a dispensary name (often at bottom or top of label), extract it

Return structured data with these fields:
`;

        const geminiResponse = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${Deno.env.get('GOOGLE_GEMINI_API_KEY')}`,
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{
                        parts: [{
                            text: structuredPrompt
                        }]
                    }],
                    generationConfig: {
                        temperature: 0.1,
                        responseMimeType: 'application/json',
                        responseSchema: {
                            type: 'object',
                            properties: {
                                strain_name: { type: 'string' },
                                brand: { type: 'string' },
                                brand_id: { type: 'string' },
                                brand_matched: { type: 'boolean' },
                                type: { 
                                    type: 'string', 
                                    enum: ['indica', 'sativa', 'hybrid'] 
                                },
                                category: { 
                                    type: 'string',
                                    enum: ['flower', 'preroll', 'blunt', 'edible', 'vape', 'cartridge', 'tincture', 'topical', 'oil', 'concentrate', 'capsule', 'drink', 'other']
                                },
                                amount: { type: 'string' },
                                thc_percentage: { type: 'number' },
                                thca_percentage: { type: 'number' },
                                cbd_percentage: { type: 'number' },
                                cbda_percentage: { type: 'number' },
                                cbg_percentage: { type: 'number' },
                                cbn_percentage: { type: 'number' },
                                packed_date: { type: 'string' },
                                expiration_date: { type: 'string' },
                                batch_number: { type: 'string' },
                                suggested_dispensary_name: { type: 'string' },
                                is_new_dispensary: { type: 'boolean' }
                            }
                        }
                    }
                })
            }
        );

        if (!geminiResponse.ok) {
            throw new Error(`Gemini API failed: ${geminiResponse.status}`);
        }

        const geminiData = await geminiResponse.json();
        const extractedText = geminiData.candidates?.[0]?.content?.parts?.[0]?.text;

        if (!extractedText) {
            throw new Error('No structured data extracted from Gemini');
        }

        const structured_data = JSON.parse(extractedText);

        return Response.json({
            status: 'success',
            raw_text: rawText,
            structured_data: structured_data
        }, { status: 200 });

    } catch (error) {
        console.error('ProductIdentification error:', error);
        return Response.json({
            status: 'error',
            error: error.message
        }, { status: 500 });
    }
});