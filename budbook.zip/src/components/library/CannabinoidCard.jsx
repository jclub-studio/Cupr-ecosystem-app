import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Pill, Thermometer, Beaker, Zap, AlertCircle } from "lucide-react";

export default function CannabinoidCard({ cannabinoid }) {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <>
      <Card 
        className="glass-card border-white/40 hover:shadow-xl transition-all duration-300 cursor-pointer group"
        onClick={() => setShowDetails(true)}
      >
        <CardHeader>
          <CardTitle className="flex items-center justify-between text-lg">
            <div className="flex items-center gap-2">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                cannabinoid.is_psychoactive 
                  ? 'bg-gradient-to-br from-purple-400 to-purple-600' 
                  : 'bg-gradient-to-br from-blue-400 to-blue-600'
              }`}>
                <Pill className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-bold text-gray-900">{cannabinoid.name}</div>
                {cannabinoid.full_name && (
                  <div className="text-xs text-gray-600 font-normal">{cannabinoid.full_name}</div>
                )}
              </div>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {cannabinoid.is_psychoactive && (
            <Badge className="bg-purple-100 text-purple-800">Psychoactive</Badge>
          )}
          
          {cannabinoid.therapeutic_uses && cannabinoid.therapeutic_uses.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-gray-500 uppercase mb-2">Therapeutic Uses</div>
              <div className="flex flex-wrap gap-1">
                {cannabinoid.therapeutic_uses.slice(0, 3).map((use, idx) => (
                  <Badge key={idx} variant="outline" className="text-xs">
                    {use}
                  </Badge>
                ))}
                {cannabinoid.therapeutic_uses.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{cannabinoid.therapeutic_uses.length - 3} more
                  </Badge>
                )}
              </div>
            </div>
          )}

          <p className="text-sm text-gray-600 line-clamp-3 group-hover:text-gray-900 transition-colors">
            {cannabinoid.description || "Click to learn more about this cannabinoid's therapeutic properties."}
          </p>
        </CardContent>
      </Card>

      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="glass-card border-white/40 max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3 text-2xl">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                cannabinoid.is_psychoactive 
                  ? 'bg-gradient-to-br from-purple-400 to-purple-600' 
                  : 'bg-gradient-to-br from-blue-400 to-blue-600'
              }`}>
                <Pill className="w-6 h-6 text-white" />
              </div>
              <div>
                <div>{cannabinoid.name}</div>
                {cannabinoid.full_name && (
                  <div className="text-sm text-gray-600 font-normal">{cannabinoid.full_name}</div>
                )}
              </div>
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6 pt-4">
            {cannabinoid.is_psychoactive && (
              <div className="p-3 bg-purple-50/80 rounded-lg border border-purple-200/50 flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-purple-900">Psychoactive Compound</div>
                  <div className="text-sm text-purple-700">This cannabinoid produces psychoactive effects</div>
                </div>
              </div>
            )}

            {cannabinoid.description && (
              <div>
                <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <Beaker className="w-4 h-4 text-blue-600" />
                  About
                </h3>
                <p className="text-gray-700 leading-relaxed">{cannabinoid.description}</p>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {cannabinoid.chemical_formula && (
                <div className="p-3 glass-card border-white/40 rounded-lg">
                  <div className="text-xs font-semibold text-gray-500 uppercase mb-1">Chemical Formula</div>
                  <div className="text-lg font-mono font-semibold text-gray-900">{cannabinoid.chemical_formula}</div>
                </div>
              )}

              {cannabinoid.boiling_point && (
                <div className="p-3 glass-card border-white/40 rounded-lg">
                  <div className="text-xs font-semibold text-gray-500 uppercase mb-1 flex items-center gap-1">
                    <Thermometer className="w-3 h-3" />
                    Boiling Point
                  </div>
                  <div className="text-lg font-semibold text-gray-900">{cannabinoid.boiling_point}°C</div>
                </div>
              )}

              {cannabinoid.precursor && (
                <div className="p-3 glass-card border-white/40 rounded-lg">
                  <div className="text-xs font-semibold text-gray-500 uppercase mb-1">Precursor</div>
                  <div className="text-lg font-semibold text-gray-900">{cannabinoid.precursor}</div>
                </div>
              )}
            </div>

            {cannabinoid.therapeutic_uses && cannabinoid.therapeutic_uses.length > 0 && (
              <div>
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-green-600" />
                  Therapeutic Uses
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {cannabinoid.therapeutic_uses.map((use, idx) => (
                    <div key={idx} className="p-2 glass-card border-green-200/50 rounded-lg text-sm">
                      {use}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {cannabinoid.effects && cannabinoid.effects.length > 0 && (
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Effects & Benefits</h3>
                <div className="flex flex-wrap gap-2">
                  {cannabinoid.effects.map((effect, idx) => (
                    <Badge key={idx} className="bg-blue-100 text-blue-800">
                      {effect}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {cannabinoid.special_notes && (
              <div className="p-4 bg-amber-50/80 rounded-lg border border-amber-200/50">
                <div className="font-semibold text-amber-900 mb-2">Special Notes</div>
                <p className="text-sm text-amber-800">{cannabinoid.special_notes}</p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}