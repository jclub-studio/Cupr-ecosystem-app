import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { User } from '@/entities/User';
import { Star, Heart, Leaf, TestTube2, ChevronRight, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function StrainCard({ product, allSessions, user, onFavoriteToggle }) {
  const [isFavoriting, setIsFavoriting] = useState(false);
  
  const typeColors = {
    indica: "bg-purple-100/80 text-purple-800 border-purple-200/50",
    sativa: "bg-orange-100/80 text-orange-800 border-orange-200/50",
    hybrid: "bg-blue-100/80 text-blue-800 border-blue-200/50",
  };

  const categoryColors = {
    flower: "bg-green-100/80 text-green-800 border-green-200/50",
    preroll: "bg-green-100/80 text-green-800 border-green-200/50",
    edible: "bg-yellow-100/80 text-yellow-800 border-yellow-200/50",
    vape: "bg-blue-100/80 text-blue-800 border-blue-200/50",
    cartridge: "bg-blue-100/80 text-blue-800 border-blue-200/50",
    tincture: "bg-purple-100/80 text-purple-800 border-purple-200/50",
    topical: "bg-pink-100/80 text-pink-800 border-pink-200/50",
    oil: "bg-amber-100/80 text-amber-800 border-amber-200/50",
    concentrate: "bg-orange-100/80 text-orange-800 border-orange-200/50"
  };

  const userSessions = allSessions.filter(s => s.product_id === product.id);
  const averageRating = userSessions.length > 0 
    ? (userSessions.reduce((sum, s) => sum + s.rating, 0) / userSessions.length).toFixed(1)
    : null;

  const isFavorited = user?.favorite_strains?.includes(product.id);

  const handleFavoriteToggle = async () => {
    if (!user) {
      toast.error("Please sign in to favorite strains.");
      return;
    }

    setIsFavoriting(true);
    try {
      const currentFavorites = user.favorite_strains || [];
      const updatedFavorites = isFavorited
        ? currentFavorites.filter(id => id !== product.id)
        : [...currentFavorites, product.id];

      await User.updateMyUserData({ favorite_strains: updatedFavorites });
      
      if (onFavoriteToggle) {
        onFavoriteToggle();
      }
      
      toast.success(isFavorited ? "Removed from favorites" : "Added to favorites");
    } catch (error) {
      console.error("Failed to update favorites:", error);
      toast.error("Failed to update favorites");
    } finally {
      setIsFavoriting(false);
    }
  };

  return (
    <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300 group">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="flex-1 min-w-0">
            <CardTitle className="text-base md:text-lg mb-2 group-hover:text-green-600 transition-colors truncate">
              {product.name}
            </CardTitle>
            {product.brand && (
              <p className="text-sm text-gray-500 mb-3">{product.brand}</p>
            )}
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleFavoriteToggle}
            disabled={isFavoriting}
            className={`ml-2 transition-all duration-200 ${
              isFavorited 
                ? 'text-red-500 hover:text-red-600 bg-red-50/50' 
                : 'text-gray-400 hover:text-red-500 hover:bg-red-50/50'
            }`}
          >
            {isFavoriting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Heart className={`w-4 h-4 ${isFavorited ? 'fill-current' : ''}`} />
            )}
          </Button>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          <Badge className={`text-xs glass-card ${typeColors[product.type] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>
            <Leaf className="w-3 h-3 mr-1" />
            {product.type}
          </Badge>
          <Badge className={`text-xs glass-card ${categoryColors[product.category] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>
            {product.category}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Cannabinoid Profile */}
        <div className="space-y-2">
          <h5 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
            <TestTube2 className="w-4 h-4" />
            Cannabinoids
          </h5>
          <div className="grid grid-cols-2 gap-2 text-xs">
            {product.thc_percentage > 0 && (
              <div className="flex justify-between bg-green-50/80 px-2 py-1 rounded glass-card border-green-200/50">
                <span className="text-green-700">THC</span>
                <span className="font-semibold text-green-800">{product.thc_percentage}%</span>
              </div>
            )}
            {product.cbd_percentage > 0 && (
              <div className="flex justify-between bg-blue-50/80 px-2 py-1 rounded glass-card border-blue-200/50">
                <span className="text-blue-700">CBD</span>
                <span className="font-semibold text-blue-800">{product.cbd_percentage}%</span>
              </div>
            )}
            {product.cbg_percentage > 0 && (
              <div className="flex justify-between bg-purple-50/80 px-2 py-1 rounded glass-card border-purple-200/50">
                <span className="text-purple-700">CBG</span>
                <span className="font-semibold text-purple-800">{product.cbg_percentage}%</span>
              </div>
            )}
            {product.cbn_percentage > 0 && (
              <div className="flex justify-between bg-amber-50/80 px-2 py-1 rounded glass-card border-amber-200/50">
                <span className="text-amber-700">CBN</span>
                <span className="font-semibold text-amber-800">{product.cbn_percentage}%</span>
              </div>
            )}
          </div>
        </div>

        {/* Terpenes */}
        {product.terpene_profile && product.terpene_profile.length > 0 && (
          <div className="space-y-2">
            <h5 className="text-sm font-semibold text-gray-700">Top Terpenes</h5>
            <div className="flex flex-wrap gap-1">
              {product.terpene_profile.slice(0, 3).map((terpene, index) => (
                <Badge key={index} variant="outline" className="text-xs glass-card border-white/40">
                  {terpene.terpene_name} ({terpene.percentage}%)
                </Badge>
              ))}
              {product.terpene_profile.length > 3 && (
                <Badge variant="outline" className="text-xs glass-card border-white/40">
                  +{product.terpene_profile.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* User Experience */}
        {userSessions.length > 0 && (
          <div className="pt-3 border-t border-white/30">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 fill-current text-yellow-500" />
                <span className="font-medium">{averageRating}/5</span>
                <span className="text-gray-500">({userSessions.length} sessions)</span>
              </div>
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </div>
          </div>
        )}

        {userSessions.length === 0 && user && (
          <div className="pt-3 border-t border-white/30">
            <p className="text-sm text-gray-500 text-center">You haven't tried this strain yet</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}