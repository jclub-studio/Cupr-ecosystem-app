import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, Pill } from "lucide-react";
import CannabinoidCard from "./CannabinoidCard";

export default function CannabinoidCatalog({ cannabinoids }) {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredCannabinoids = cannabinoids.filter(cannabinoid =>
    cannabinoid.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cannabinoid.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cannabinoid.therapeutic_uses?.some(use => use.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (cannabinoids.length === 0) {
    return (
      <Card className="glass-card border-white/40">
        <CardContent className="text-center py-12">
          <Pill className="w-16 h-16 mx-auto mb-4 text-gray-300" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No Cannabinoids Yet</h3>
          <p className="text-gray-600">The cannabinoid database is being populated with therapeutic information.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Search cannabinoids by name or therapeutic use..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 glass-card border-white/40"
        />
      </div>

      {filteredCannabinoids.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {filteredCannabinoids.map(cannabinoid => (
            <CannabinoidCard key={cannabinoid.id} cannabinoid={cannabinoid} />
          ))}
        </div>
      ) : (
        <Card className="glass-card border-white/40">
          <CardContent className="text-center py-8">
            <p className="text-gray-600">No cannabinoids match your search.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}