import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { User } from '@/entities/User';
import { Heart, TestTube2, Thermometer, Leaf, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function TerpeneCard({ terpene, allProducts, allSessions, user }) {
  const [isFavoriting, setIsFavoriting] = useState(false);
  
  const effectColors = {
    'Relaxing': 'bg-blue-100/80 text-blue-800 border-blue-200/50',
    'Energizing': 'bg-orange-100/80 text-orange-800 border-orange-200/50',
    'Uplifting': 'bg-yellow-100/80 text-yellow-800 border-yellow-200/50',
    'Calming': 'bg-green-100/80 text-green-800 border-green-200/50',
    'Focus': 'bg-purple-100/80 text-purple-800 border-purple-200/50',
    'Pain Relief': 'bg-red-100/80 text-red-800 border-red-200/50',
    'Anti-inflammatory': 'bg-pink-100/80 text-pink-800 border-pink-200/50',
    'Sedating': 'bg-indigo-100/80 text-indigo-800 border-indigo-200/50'
  };

  const productsWithTerpene = allProducts.filter(product => 
    product.terpene_profile?.some(t => 
      t.terpene_name.toLowerCase() === terpene.name.toLowerCase()
    )
  );

  const isFavorited = user?.favorite_terpenes?.includes(terpene.id);

  const handleFavoriteToggle = async () => {
    if (!user) {
      toast.error("Please sign in to favorite terpenes.");
      return;
    }

    setIsFavoriting(true);
    try {
      const currentFavorites = user.favorite_terpenes || [];
      const updatedFavorites = isFavorited
        ? currentFavorites.filter(id => id !== terpene.id)
        : [...currentFavorites, terpene.id];

      await User.updateMyUserData({ favorite_terpenes: updatedFavorites });
      toast.success(isFavorited ? "Removed from favorites" : "Added to favorites");
    } catch (error) {
      console.error("Failed to update favorites:", error);
      toast.error("Failed to update favorites");
    } finally {
      setIsFavoriting(false);
    }
  };

  return (
    <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300 group">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="flex-1 min-w-0">
            <CardTitle className="text-base md:text-lg mb-1 group-hover:text-purple-600 transition-colors">
              {terpene.name}
            </CardTitle>
            {terpene.formula && (
              <p className="text-xs text-gray-500 font-mono mb-2">{terpene.formula}</p>
            )}
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleFavoriteToggle}
            disabled={isFavoriting}
            className={`ml-2 transition-all duration-200 ${
              isFavorited 
                ? 'text-red-500 hover:text-red-600 bg-red-50/50' 
                : 'text-gray-400 hover:text-red-500 hover:bg-red-50/50'
            }`}
          >
            {isFavoriting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Heart className={`w-4 h-4 ${isFavorited ? 'fill-current' : ''}`} />
            )}
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Aroma Profile */}
        <div className="space-y-2">
          <h5 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
            <TestTube2 className="w-4 h-4" />
            Aroma
          </h5>
          <p className="text-sm text-gray-600 bg-gray-50/80 p-2 rounded-lg glass-card border-white/40">
            {terpene.aroma}
          </p>
        </div>

        {/* Effects */}
        <div className="space-y-2">
          <h5 className="text-sm font-semibold text-gray-700">Effects</h5>
          <div className="flex flex-wrap gap-1">
            {terpene.effects.map((effect, index) => (
              <Badge 
                key={index} 
                className={`text-xs glass-card ${effectColors[effect] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}
              >
                {effect}
              </Badge>
            ))}
          </div>
        </div>

        {/* Boiling Point */}
        {terpene.boiling_point && (
          <div className="flex items-center gap-2 text-sm text-gray-600 bg-blue-50/80 p-2 rounded-lg glass-card border-blue-200/50">
            <Thermometer className="w-4 h-4 text-blue-600" />
            <span>Boiling point: {terpene.boiling_point}°C</span>
          </div>
        )}

        {/* Common In */}
        {terpene.common_in && terpene.common_in.length > 0 && (
          <div className="space-y-2">
            <h5 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
              <Leaf className="w-4 h-4" />
              Also found in
            </h5>
            <div className="flex flex-wrap gap-1">
              {terpene.common_in.slice(0, 4).map((plant, index) => (
                <Badge key={index} variant="outline" className="text-xs glass-card border-white/40">
                  {plant}
                </Badge>
              ))}
              {terpene.common_in.length > 4 && (
                <Badge variant="outline" className="text-xs glass-card border-white/40">
                  +{terpene.common_in.length - 4} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Products containing this terpene */}
        {productsWithTerpene.length > 0 && (
          <div className="pt-3 border-t border-white/30">
            <p className="text-sm text-gray-600">
              Found in <span className="font-medium">{productsWithTerpene.length}</span> strain{productsWithTerpene.length !== 1 ? 's' : ''} in your collection
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}