import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Leaf, Droplet, Star } from 'lucide-react';

export default function StrainBriefCard({ product, onClick, userRating }) {
  const typeColors = {
    indica: "bg-purple-100/80 text-purple-800 border-purple-200/50",
    sativa: "bg-orange-100/80 text-orange-800 border-orange-200/50",
    hybrid: "bg-blue-100/80 text-blue-800 border-blue-200/50",
  };

  const categoryColors = {
    flower: "bg-green-100/80 text-green-800 border-green-200/50",
    preroll: "bg-green-100/80 text-green-800 border-green-200/50",
    edible: "bg-yellow-100/80 text-yellow-800 border-yellow-200/50",
    vape: "bg-blue-100/80 text-blue-800 border-blue-200/50",
    cartridge: "bg-blue-100/80 text-blue-800 border-blue-200/50",
    tincture: "bg-purple-100/80 text-purple-800 border-purple-200/50",
    topical: "bg-pink-100/80 text-pink-800 border-pink-200/50",
    oil: "bg-amber-100/80 text-amber-800 border-amber-200/50",
    concentrate: "bg-orange-100/80 text-orange-800 border-orange-200/50"
  };

  return (
    <Card 
      onClick={onClick}
      className="glass-card border-white/40 hover:shadow-xl hover:scale-105 transition-all duration-300 cursor-pointer group"
    >
      <CardContent className="p-4">
        <div className="space-y-3">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <h3 className="text-base md:text-lg font-bold text-gray-900 mb-1 group-hover:text-green-600 transition-colors truncate">
                {product.name}
              </h3>
              {product.brand && (
                <p className="text-xs text-gray-500 truncate">{product.brand}</p>
              )}
            </div>
            <div className="p-2 bg-green-100/80 rounded-lg flex-shrink-0">
              <Leaf className="w-4 h-4 text-green-600" />
            </div>
          </div>

          {/* Type & Category Badges */}
          <div className="flex gap-2 flex-wrap">
            <Badge className={`text-xs glass-card ${typeColors[product.type] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>
              {product.type}
            </Badge>
            <Badge className={`text-xs glass-card ${categoryColors[product.category] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>
              {product.category}
            </Badge>
          </div>

          {/* Cannabinoid Quick View */}
          {(product.thc_percentage > 0 || product.cbd_percentage > 0) && (
            <div className="flex items-center gap-3 pt-2 border-t border-white/30">
              <Droplet className="w-3 h-3 text-gray-400 flex-shrink-0" />
              <div className="flex gap-3 text-xs">
                {product.thc_percentage > 0 && (
                  <span className="font-semibold text-red-600">THC {product.thc_percentage}%</span>
                )}
                {product.cbd_percentage > 0 && (
                  <span className="font-semibold text-green-600">CBD {product.cbd_percentage}%</span>
                )}
              </div>
            </div>
          )}

          {/* User Rating if available */}
          {userRating && (
            <div className="flex items-center gap-2 pt-2 border-t border-white/30">
              <Star className="w-3 h-3 fill-current text-yellow-500" />
              <span className="text-xs font-medium text-gray-700">Your rating: {userRating}/5</span>
            </div>
          )}

          {/* Hover Indicator */}
          <div className="text-xs text-gray-400 group-hover:text-green-600 transition-colors text-center pt-1">
            Click for details →
          </div>
        </div>
      </CardContent>
    </Card>
  );
}