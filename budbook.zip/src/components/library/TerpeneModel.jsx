
import React, { useRef, useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Play, Pause, RotateCcw, Maximize2 } from 'lucide-react';
import * as THREE from 'three';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Basic molecular structures for common terpenes (simplified representations)
const TERPENE_STRUCTURES = {
  'alpha-pinene': {
    atoms: [
      { element: 'C', position: [0, 0, 0], color: 0x404040 },
      { element: 'C', position: [1.2, 0.8, 0], color: 0x404040 },
      { element: 'C', position: [2.4, 0, 0], color: 0x404040 },
      { element: 'C', position: [2.4, -1.6, 0], color: 0x404040 },
      { element: 'C', position: [1.2, -2.4, 0], color: 0x404040 },
      { element: 'C', position: [0, -1.6, 0], color: 0x404040 },
      { element: 'C', position: [-1.2, -2.4, 0], color: 0x404040 },
      { element: 'C', position: [3.6, 0.8, 0], color: 0x404040 },
      { element: 'C', position: [3.6, -2.4, 0], color: 0x404040 },
      { element: 'C', position: [1.2, 2.0, 0], color: 0x404040 }
    ],
    bonds: [
      [0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 0],
      [5, 6], [2, 7], [3, 8], [1, 9]
    ]
  },
  'limonene': {
    atoms: [
      { element: 'C', position: [0, 0, 0], color: 0x404040 },
      { element: 'C', position: [1.2, 0.8, 0], color: 0x404040 },
      { element: 'C', position: [2.4, 0, 0], color: 0x404040 },
      { element: 'C', position: [2.4, -1.6, 0], color: 0x404040 },
      { element: 'C', position: [1.2, -2.4, 0], color: 0x404040 },
      { element: 'C', position: [0, -1.6, 0], color: 0x404040 },
      { element: 'C', position: [3.6, 0.8, 0.8], color: 0x404040 },
      { element: 'C', position: [4.8, 0, 0], color: 0x404040 },
      { element: 'C', position: [4.8, -1.6, 0.8], color: 0x404040 },
      { element: 'C', position: [3.6, -2.4, 0], color: 0x404040 }
    ],
    bonds: [
      [0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 0],
      [2, 6], [6, 7], [7, 8], [8, 9], [9, 3]
    ]
  },
  'myrcene': {
    atoms: [
      { element: 'C', position: [0, 0, 0], color: 0x404040 },
      { element: 'C', position: [1.4, 0, 0], color: 0x404040 },
      { element: 'C', position: [2.8, 0, 0], color: 0x404040 },
      { element: 'C', position: [4.2, 0, 0], color: 0x404040 },
      { element: 'C', position: [5.6, 0, 0], color: 0x404040 },
      { element: 'C', position: [7.0, 0, 0], color: 0x404040 },
      { element: 'C', position: [8.4, 0, 0], color: 0x404040 },
      { element: 'C', position: [2.8, 1.4, 0], color: 0x404040 },
      { element: 'C', position: [7.0, 1.4, 0], color: 0x404040 },
      { element: 'C', position: [7.0, -1.4, 0], color: 0x404040 }
    ],
    bonds: [
      [0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 6],
      [2, 7], [5, 8], [5, 9]
    ]
  },
  'linalool': {
    atoms: [
      { element: 'C', position: [0, 0, 0], color: 0x404040 },
      { element: 'C', position: [1.4, 0, 0], color: 0x404040 },
      { element: 'C', position: [2.8, 0, 0], color: 0x404040 },
      { element: 'C', position: [4.2, 0, 0], color: 0x404040 },
      { element: 'C', position: [5.6, 0, 0], color: 0x404040 },
      { element: 'C', position: [7.0, 0, 0], color: 0x404040 },
      { element: 'C', position: [8.4, 0, 0], color: 0x404040 },
      { element: 'O', position: [2.8, 1.4, 0], color: 0xff0000 },
      { element: 'C', position: [2.8, -1.4, 0], color: 0x404040 },
      { element: 'C', position: [7.0, 1.4, 0], color: 0x404040 }
    ],
    bonds: [
      [0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 6],
      [2, 7], [2, 8], [5, 9]
    ]
  },
  'beta-caryophyllene': {
    atoms: [
      { element: 'C', position: [0, 0, 0], color: 0x404040 },
      { element: 'C', position: [1.2, 0.8, 0], color: 0x404040 },
      { element: 'C', position: [2.4, 0, 0], color: 0x404040 },
      { element: 'C', position: [2.4, -1.6, 0], color: 0x404040 },
      { element: 'C', position: [1.2, -2.4, 0], color: 0x404040 },
      { element: 'C', position: [0, -1.6, 0], color: 0x404040 },
      { element: 'C', position: [3.6, 0.8, 0.8], color: 0x404040 },
      { element: 'C', position: [4.8, 0, 0], color: 0x404040 },
      { element: 'C', position: [6.0, 0.8, 0.8], color: 0x404040 },
      { element: 'C', position: [7.2, 0, 0], color: 0x404040 },
      { element: 'C', position: [8.4, 0.8, 0], color: 0x404040 },
      { element: 'C', position: [9.6, 0, 0], color: 0x404040 },
      { element: 'C', position: [3.6, -1.6, -0.8], color: 0x404040 },
      { element: 'C', position: [6.0, -1.6, -0.8], color: 0x404040 },
      { element: 'C', position: [8.4, -1.6, 0], color: 0x404040 }
    ],
    bonds: [
      [0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 0],
      [2, 6], [6, 7], [7, 8], [8, 9], [9, 10], [10, 11],
      [3, 12], [8, 13], [10, 14]
    ]
  }
};

function MolecularViewer({ structure, width = 300, height = 240, autoRotate = false, terpene }) {
  const mountRef = useRef(null);
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const animationIdRef = useRef(null);
  const [isRotating, setIsRotating] = useState(autoRotate);

  useEffect(() => {
    if (!mountRef.current || !structure) return;

    // Capture the current mount element
    const currentMount = mountRef.current;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf8f9fa);
    
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Clear previous content
    currentMount.innerHTML = '';
    currentMount.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(10, 10, 5);
    directionalLight.castShadow = true;
    scene.add(directionalLight);

    // Create molecule group
    const moleculeGroup = new THREE.Group();

    // Create atoms
    structure.atoms.forEach((atom, index) => {
      const geometry = new THREE.SphereGeometry(0.3, 16, 16);
      const material = new THREE.MeshPhongMaterial({ 
        color: atom.color,
        shininess: 100
      });
      const sphere = new THREE.Mesh(geometry, material);
      sphere.position.set(...atom.position);
      sphere.castShadow = true;
      sphere.receiveShadow = true;
      moleculeGroup.add(sphere);
    });

    // Create bonds
    structure.bonds.forEach(([startIndex, endIndex]) => {
      const start = new THREE.Vector3(...structure.atoms[startIndex].position);
      const end = new THREE.Vector3(...structure.atoms[endIndex].position);
      const direction = new THREE.Vector3().subVectors(end, start);
      const distance = direction.length();
      
      const geometry = new THREE.CylinderGeometry(0.1, 0.1, distance, 8);
      const material = new THREE.MeshPhongMaterial({ color: 0x666666 });
      const cylinder = new THREE.Mesh(geometry, material);
      
      cylinder.position.copy(start).add(direction.multiplyScalar(0.5));
      cylinder.lookAt(end);
      cylinder.rotateX(Math.PI / 2);
      cylinder.castShadow = true;
      cylinder.receiveShadow = true;
      
      moleculeGroup.add(cylinder);
    });

    scene.add(moleculeGroup);

    // Position camera
    const box = new THREE.Box3().setFromObject(moleculeGroup);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const maxDim = Math.max(size.x, size.y, size.z);
    
    camera.position.set(center.x, center.y, center.z + maxDim * 2);
    camera.lookAt(center);

    sceneRef.current = { scene, camera, renderer, moleculeGroup };
    rendererRef.current = renderer;

    // Animation loop
    function animate() {
      animationIdRef.current = requestAnimationFrame(animate);
      
      if (isRotating && sceneRef.current) {
        sceneRef.current.moleculeGroup.rotation.y += 0.01;
      }
      
      renderer.render(scene, camera);
    }
    animate();

    return () => {
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      if (currentMount && renderer.domElement && currentMount.contains(renderer.domElement)) {
        currentMount.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [structure, width, height, isRotating]);

  const toggleRotation = () => {
    setIsRotating(!isRotating);
  };

  const resetView = () => {
    if (sceneRef.current) {
      sceneRef.current.moleculeGroup.rotation.set(0, 0, 0);
    }
  };

  return (
    <div className="relative bg-gray-50 rounded-lg overflow-hidden">
      <div ref={mountRef} style={{ width, height }} />
      <div className="absolute bottom-2 right-2 flex gap-1">
        <Button
          size="sm"
          variant="secondary"
          onClick={toggleRotation}
          className="opacity-80 hover:opacity-100"
        >
          {isRotating ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
        </Button>
        <Button
          size="sm"
          variant="secondary"
          onClick={resetView}
          className="opacity-80 hover:opacity-100"
        >
          <RotateCcw className="w-3 h-3" />
        </Button>
        <Dialog>
          <DialogTrigger asChild>
            <Button size="sm" variant="secondary" className="opacity-80 hover:opacity-100">
              <Maximize2 className="w-3 h-3" />
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>{terpene.name} - 3D Molecular Structure</DialogTitle>
            </DialogHeader>
            <div className="flex justify-center">
              <MolecularViewer 
                structure={structure} 
                width={600} 
                height={400} 
                autoRotate={true}
                terpene={terpene}
              />
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

export default function TerpeneModel({ terpene }) {
  const terpeneName = terpene.name.toLowerCase().replace(/[α-]/g, 'alpha-').replace(/[β-]/g, 'beta-');
  const structure = TERPENE_STRUCTURES[terpeneName];

  if (!structure) {
    return (
      <div className="relative bg-gray-50 rounded-lg overflow-hidden flex items-center justify-center" style={{ height: '240px' }}>
        <div className="text-center p-4">
          <div className="w-12 h-12 bg-gray-300 rounded-full mx-auto mb-2 flex items-center justify-center">
            <span className="text-gray-600 font-bold text-lg">{terpene.name.charAt(0)}</span>
          </div>
          <p className="text-sm text-gray-500">3D structure coming soon</p>
        </div>
      </div>
    );
  }

  return <MolecularViewer structure={structure} terpene={terpene} />;
}
