
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Search, BarChart3 } from 'lucide-react';
import TerpeneBriefCard from './TerpeneBriefCard';
import TerpeneCard from './TerpeneCard';
import TerpeneReferenceChart from './TerpeneReferenceChart';

export default function TerpeneCatalog({ terpenes, products, sessions, user }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [showChart, setShowChart] = useState(false);
  const [selectedTerpene, setSelectedTerpene] = useState(null);

  const filteredTerpenes = terpenes.filter(terpene =>
    terpene.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    terpene.aroma.toLowerCase().includes(searchTerm.toLowerCase()) ||
    terpene.effects.some(e => e.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search terpenes by name, aroma, or effect..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 glass-card border-white/40"
          />
        </div>
        <Button
          onClick={() => setShowChart(true)}
          className="bg-purple-600/90 hover:bg-purple-700/90 shadow-lg min-h-[44px] gap-2"
        >
          <BarChart3 className="w-4 h-4" />
          View Reference Chart
        </Button>
      </div>

      <div className="pt-6 border-t border-white/30">
        <h3 className="text-xl font-semibold mb-4">Terpene Profiles</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTerpenes.map(terpene => (
            <TerpeneBriefCard
              key={terpene.id}
              terpene={terpene}
              onClick={() => setSelectedTerpene(terpene)}
            />
          ))}
        </div>
      </div>

      {/* Reference Chart Modal */}
      <Dialog open={showChart} onOpenChange={setShowChart}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto glass-card border-white/40">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold flex items-center gap-2">
              <BarChart3 className="w-6 h-6 text-purple-600" />
              Cannabis Terpene Reference Chart
            </DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <TerpeneReferenceChart />
          </div>
        </DialogContent>
      </Dialog>

      {/* Terpene Details Modal */}
      <Dialog open={!!selectedTerpene} onOpenChange={(open) => !open && setSelectedTerpene(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto glass-card border-white/40">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-gray-900">
              {selectedTerpene?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            {selectedTerpene && (
              <TerpeneCard
                terpene={selectedTerpene}
                allProducts={products}
                allSessions={sessions}
                user={user}
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
