import React, { useState, useMemo } from 'react';
import { Input } from '@/components/ui/input';
import { Search, Star, Package } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import StrainBriefCard from './StrainBriefCard';
import StrainCard from './StrainCard';

export default function StrainCatalog({ products, sessions, inventory, user }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProduct, setSelectedProduct] = useState(null);

  const { myStrains, allOtherStrains } = useMemo(() => {
    const userProductIds = new Set([
      ...inventory.map(item => item.product_id),
      ...(user?.favorite_strains || [])
    ]);

    const myStrains = [];
    const allOtherStrains = [];

    products.forEach(p => {
      if (userProductIds.has(p.id)) {
        myStrains.push(p);
      } else {
        allOtherStrains.push(p);
      }
    });
    
    return { myStrains, allOtherStrains };
  }, [products, inventory, user]);

  const filterProducts = (productsList) => {
    if (!searchTerm) return productsList;
    return productsList.filter(product =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.brand?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  };

  const filteredMyStrains = filterProducts(myStrains);
  const filteredAllStrains = filterProducts(allOtherStrains);

  const getUserRating = (productId) => {
    const productSessions = sessions.filter(s => s.product_id === productId);
    if (productSessions.length === 0) return null;
    const avgRating = productSessions.reduce((sum, s) => sum + s.rating, 0) / productSessions.length;
    return avgRating.toFixed(1);
  };

  return (
    <div className="space-y-6">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Search all strains by name or brand..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 glass-card border-white/40"
        />
      </div>

      <Tabs defaultValue="my-strains" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="my-strains">
            <Star className="w-4 h-4 mr-2" /> My Strains
          </TabsTrigger>
          <TabsTrigger value="all-strains">
            <Package className="w-4 h-4 mr-2" /> Strain Library
          </TabsTrigger>
        </TabsList>
        <TabsContent value="my-strains" className="pt-6">
          {filteredMyStrains.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredMyStrains.map(product => (
                <StrainBriefCard
                  key={product.id}
                  product={product}
                  onClick={() => setSelectedProduct(product)}
                  userRating={getUserRating(product.id)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-gray-500">
              <p>Your personal collection is empty.</p>
              <p>Favorite strains from the library or scan a product to add them here.</p>
            </div>
          )}
        </TabsContent>
        <TabsContent value="all-strains" className="pt-6">
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredAllStrains.map(product => (
              <StrainBriefCard
                key={product.id}
                product={product}
                onClick={() => setSelectedProduct(product)}
                userRating={getUserRating(product.id)}
              />
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Strain Details Modal */}
      <Dialog open={!!selectedProduct} onOpenChange={(open) => !open && setSelectedProduct(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto glass-card border-white/40">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-gray-900">
              {selectedProduct?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            {selectedProduct && (
              <StrainCard
                product={selectedProduct}
                allSessions={sessions}
                user={user}
                onFavoriteToggle={() => {
                  // Refresh will happen automatically via parent component
                  setSelectedProduct(null);
                }}
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}