import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { TestTube2 } from 'lucide-react';

const terpeneData = [
  { name: 'Myrcene', aroma: 'Earthy, musky', sources: 'Mangoes, hops', therapeutic: 'Sedative, relax' },
  { name: 'Limonene', aroma: 'Citrusy', sources: 'Citrus fruits', therapeutic: 'Mood boost' },
  { name: 'β-Caryophyllene', aroma: 'Spicy, peppery', sources: 'Black pepper', therapeutic: 'Anti-inflam' },
  { name: 'Linalool', aroma: 'Floral', sources: 'Lavender', therapeutic: 'Anti-anxiety' },
  { name: 'α-Pinene', aroma: 'Pine, woody', sources: 'Pine needles', therapeutic: 'Bronchodilator' },
  { name: 'β-Pinene', aroma: 'Herbal, sweet', sources: 'Basil, dill', therapeutic: 'Anti-anxiety' },
  { name: 'Terpinolene', aroma: 'Floral, herbal', sources: 'Lilacs, nutmeg', therapeutic: 'Sedative' },
  { name: 'Humulene', aroma: 'Earthy, woody', sources: 'Hops, coriander', therapeutic: 'Anti-inflam' },
  { name: 'Ocimene', aroma: 'Sweet, herbal', sources: 'Mint, parsley', therapeutic: 'Antiviral' },
  { name: 'Bisabolol', aroma: 'Sweet, floral', sources: 'Chamomile', therapeutic: 'Anti-inflam' },
  { name: 'Geraniol', aroma: 'Rose-like', sources: 'Roses, geraniums', therapeutic: 'Antioxidant' },
  { name: 'Eucalyptol', aroma: 'Minty, cooling', sources: 'Eucalyptus', therapeutic: 'Cough suppress' },
  { name: 'Borneol', aroma: 'Woody, herbal', sources: 'Turmeric, thyme', therapeutic: 'Anti-inflam' },
  { name: 'Camphene', aroma: 'Woody, fir', sources: 'Ginger, camphor', therapeutic: 'Antimicrobial' },
  { name: 'Nerolidol', aroma: 'Woody, floral', sources: 'Ginger, jasmine', therapeutic: 'Antifungal' },
];

export default function TerpeneReferenceChart() {
  return (
    <Card className="bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TestTube2 className="w-5 h-5 text-green-600"/>
          Cannabis Terpenes Reference Chart
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="max-h-80 overflow-y-auto">
          <Table>
            <TableHeader className="sticky top-0 bg-gray-50">
              <TableRow>
                <TableHead className="w-1/4 font-semibold">Terpene</TableHead>
                <TableHead className="w-1/4 font-semibold">Aroma</TableHead>
                <TableHead className="w-1/4 font-semibold">Sources</TableHead>
                <TableHead className="w-1/4 font-semibold">Therapeutic</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {terpeneData.map((terpene) => (
                <TableRow key={terpene.name}>
                  <TableCell className="font-medium">{terpene.name}</TableCell>
                  <TableCell>{terpene.aroma}</TableCell>
                  <TableCell>{terpene.sources}</TableCell>
                  <TableCell>{terpene.therapeutic}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}