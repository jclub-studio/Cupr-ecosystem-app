import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TestTube2, Sparkles } from 'lucide-react';

export default function TerpeneBriefCard({ terpene, onClick }) {
  const primaryEffect = terpene.effects[0] || 'Therapeutic';
  
  const effectColors = {
    'Relaxing': 'bg-blue-100/80 text-blue-800 border-blue-200/50',
    'Energizing': 'bg-orange-100/80 text-orange-800 border-orange-200/50',
    'Uplifting': 'bg-yellow-100/80 text-yellow-800 border-yellow-200/50',
    'Calming': 'bg-green-100/80 text-green-800 border-green-200/50',
    'Focus': 'bg-purple-100/80 text-purple-800 border-purple-200/50',
    'Pain Relief': 'bg-red-100/80 text-red-800 border-red-200/50',
    'Anti-inflammatory': 'bg-pink-100/80 text-pink-800 border-pink-200/50',
    'Sedating': 'bg-indigo-100/80 text-indigo-800 border-indigo-200/50'
  };

  return (
    <Card 
      onClick={onClick}
      className="glass-card border-white/40 hover:shadow-xl hover:scale-105 transition-all duration-300 cursor-pointer group"
    >
      <CardContent className="p-4">
        <div className="space-y-3">
          {/* Header with Icon */}
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <h3 className="text-base md:text-lg font-bold text-gray-900 mb-1 group-hover:text-purple-600 transition-colors truncate">
                {terpene.name}
              </h3>
              {terpene.formula && (
                <p className="text-xs text-gray-500 font-mono">{terpene.formula}</p>
              )}
            </div>
            <div className="p-2 bg-purple-100/80 rounded-lg flex-shrink-0">
              <TestTube2 className="w-4 h-4 text-purple-600" />
            </div>
          </div>

          {/* Aroma */}
          <div className="flex items-center gap-2">
            <Sparkles className="w-3 h-3 text-gray-400 flex-shrink-0" />
            <p className="text-sm text-gray-600 truncate">{terpene.aroma}</p>
          </div>

          {/* Primary Effect Badge */}
          <div className="pt-2 border-t border-white/30">
            <Badge 
              className={`text-xs glass-card ${effectColors[primaryEffect] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}
            >
              {primaryEffect}
            </Badge>
            {terpene.effects.length > 1 && (
              <span className="text-xs text-gray-500 ml-2">
                +{terpene.effects.length - 1} more
              </span>
            )}
          </div>

          {/* Hover Indicator */}
          <div className="text-xs text-gray-400 group-hover:text-purple-600 transition-colors text-center pt-1">
            Click for details →
          </div>
        </div>
      </CardContent>
    </Card>
  );
}