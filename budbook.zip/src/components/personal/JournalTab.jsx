import React, { useState, useEffect } from "react";
import { Session, Product } from "@/entities/all";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BookOpen, Search, BarChart2 } from "lucide-react";
import JournalCharts from "../journal/JournalCharts";
import SessionCard from "../journal/SessionCard";
import SessionDetailsModal from "../journal/SessionDetailsModal";

export default function JournalTab() {
  const [sessions, setSessions] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterMethod, setFilterMethod] = useState("all");
  const [selectedSession, setSelectedSession] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [sessionsData, productsData] = await Promise.all([
        Session.list("-date"),
        Product.list()
      ]);
      setSessions(sessionsData);
      setProducts(productsData);
    } catch (error) {
      console.error("Failed to load journal data:", error);
    } finally {
      setLoading(false);
    }
  };

  const getProductById = (productId) => {
    return products.find(p => p.id === productId);
  };
  
  const consumptionMethods = [...new Set(sessions.map(s => s.consumption_method))];

  const filteredSessions = sessions.filter(session => {
    const product = getProductById(session.product_id);
    const matchesSearch = searchTerm === "" || 
                         product?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         session.notes?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesMethod = filterMethod === "all" || session.consumption_method === filterMethod;
    return matchesSearch && matchesMethod;
  });

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse max-w-7xl mx-auto">
          <div className="h-8 bg-gray-200/80 rounded w-1/4 mb-8"></div>
          <div className="h-48 bg-gray-200/80 rounded-xl mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1,2,3].map(i => <div key={i} className="h-64 bg-gray-200/80 rounded-xl"></div>)}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
        {/* Charts */}
        <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-green-600" />
              Your Wellness Trends
            </CardTitle>
          </CardHeader>
          <CardContent>
            {sessions.length > 0 ? (
              <JournalCharts sessions={sessions} products={products} />
            ) : (
              <p className="text-gray-500 text-center py-8">Log some sessions to see your trends.</p>
            )}
          </CardContent>
        </Card>

        {/* Filters and Session List */}
        <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
          <CardHeader>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-600" />
                Session History
              </CardTitle>
              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                <div className="relative flex-1 sm:flex-initial">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search sessions..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-full glass-card border-white/40"
                  />
                </div>
                <Select value={filterMethod} onValueChange={setFilterMethod}>
                  <SelectTrigger className="w-full sm:w-36 glass-card border-white/40">
                    <SelectValue placeholder="Method" />
                  </SelectTrigger>
                  <SelectContent className="glass-card border-white/40">
                    <SelectItem value="all">All Methods</SelectItem>
                    {consumptionMethods.map(method => (
                      <SelectItem key={method} value={method}>
                        {method.charAt(0).toUpperCase() + method.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {filteredSessions.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredSessions.map(session => (
                  <SessionCard 
                    key={session.id} 
                    session={session} 
                    product={getProductById(session.product_id)}
                    onViewDetails={() => setSelectedSession(session)}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No sessions found</h3>
                <p className="text-gray-600">Try adjusting your filters or log a new session.</p>
              </div>
            )}
          </CardContent>
        </Card>

      {selectedSession && (
        <SessionDetailsModal
          session={selectedSession}
          product={getProductById(selectedSession.product_id)}
          onOpenChange={() => setSelectedSession(null)}
        />
      )}
    </div>
  );
}