import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Package, Plus, Search, Leaf, ExternalLink, Droplet } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ProductBriefCard from "../inventory/ProductBriefCard";
import ProductDetailsModal from "../inventory/ProductDetailsModal";
import BrandDetailsModal from "../brand/BrandDetailsModal";

export default function StashTab() {
  const [inventory, setInventory] = useState([]);
  const [products, setProducts] = useState([]);
  const [brands, setBrands] = useState([]);
  const [dispensaries, setDispensaries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterBrand, setFilterBrand] = useState("all");
  
  // Modal states
  const [selectedInventoryItem, setSelectedInventoryItem] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showBriefModal, setShowBriefModal] = useState(false);
  const [showFullModal, setShowFullModal] = useState(false);
  const [selectedBrand, setSelectedBrand] = useState(null);
  const [showBrandModal, setShowBrandModal] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [inventoryData, productsData, dispensariesData, brandsData] = await Promise.all([
        base44.entities.UserInventory.filter({ is_active: true }, "-purchase_date"),
        base44.entities.Product.list("-created_date"),
        base44.entities.Dispensary.list("-created_date"),
        base44.entities.Brand.list("-name")
      ]);
      
      setInventory(inventoryData);
      setProducts(productsData);
      setDispensaries(dispensariesData);
      setBrands(brandsData);
    } catch (error) {
      console.error("Error loading inventory:", error);
    } finally {
      setLoading(false);
    }
  };

  const getProductById = (productId) => {
    return products.find(p => p.id === productId);
  };

  const getDispensaryById = (dispensaryId) => {
    return dispensaries.find(d => d.id === dispensaryId);
  };

  const getBrandById = (brandId) => {
    return brands.find(b => b.id === brandId);
  };

  const getBrandByName = (brandName) => {
    if (!brandName) return null;
    return brands.find(b => 
      b.name.toLowerCase() === brandName.toLowerCase() ||
      b.common_abbreviations?.some(abbr => abbr.toLowerCase() === brandName.toLowerCase())
    );
  };

  const handleProductClick = (item, product) => {
    setSelectedInventoryItem(item);
    setSelectedProduct(product);
    setShowBriefModal(true);
  };

  const handleViewFullDetails = () => {
    setShowBriefModal(false);
    setShowFullModal(true);
  };

  const handleBrandClick = (product) => {
    // Try to find brand by ID first, then by name
    const brand = product.brand_id ? getBrandById(product.brand_id) : getBrandByName(product.brand);
    if (brand) {
      setSelectedBrand(brand);
      setShowBrandModal(true);
    }
  };

  // Get unique brands from user's products
  const userBrands = Array.from(new Set(
    inventory
      .map(item => {
        const product = getProductById(item.product_id);
        return product?.brand_id || product?.brand;
      })
      .filter(Boolean)
  )).map(brandIdentifier => {
    // Try to find as ID first, then as name
    return getBrandById(brandIdentifier) || getBrandByName(brandIdentifier) || { id: brandIdentifier, name: brandIdentifier };
  });

  const filteredInventory = inventory.filter(item => {
    const product = getProductById(item.product_id);
    if (!product) return false;

    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.brand?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === "all" || product.type === filterType;
    const matchesCategory = filterCategory === "all" || product.category === filterCategory;
    
    let matchesBrand = true;
    if (filterBrand !== "all") {
      matchesBrand = product.brand_id === filterBrand || product.brand === filterBrand;
    }

    return matchesSearch && matchesType && matchesCategory && matchesBrand;
  });

  const typeColors = {
    indica: "bg-purple-100 text-purple-800",
    sativa: "bg-green-100 text-green-800",
    hybrid: "bg-blue-100 text-blue-800"
  };

  const categoryColors = {
    flower: "bg-green-100 text-green-800",
    concentrate: "bg-amber-100 text-amber-800",
    edible: "bg-red-100 text-red-800",
    vape: "bg-blue-100 text-blue-800",
    tincture: "bg-purple-100 text-purple-800",
    topical: "bg-pink-100 text-pink-800"
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1,2,3,4,5,6].map(i => (
              <div key={i} className="h-48 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 md:space-y-8">
      {/* Filters */}
      <Card className="bg-white/80 backdrop-blur-sm">
        <CardContent className="p-4 md:p-6">
          <div className="flex flex-col gap-3 md:gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 text-sm md:text-base"
              />
            </div>
            
            <div className="flex gap-2 md:gap-3 flex-wrap">
              <Select value={filterBrand} onValueChange={setFilterBrand}>
                <SelectTrigger className="w-32 md:w-40">
                  <SelectValue placeholder="Brand" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Brands</SelectItem>
                  {userBrands.map(brand => (
                    <SelectItem key={brand.id} value={brand.id}>
                      {brand.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-28 md:w-32">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="indica">Indica</SelectItem>
                  <SelectItem value="sativa">Sativa</SelectItem>
                  <SelectItem value="hybrid">Hybrid</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-28 md:w-32">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="flower">Flower</SelectItem>
                  <SelectItem value="preroll">Pre-rolled</SelectItem>
                  <SelectItem value="concentrate">Concentrate</SelectItem>
                  <SelectItem value="edible">Edible</SelectItem>
                  <SelectItem value="vape">Vape</SelectItem>
                  <SelectItem value="tincture">Tincture</SelectItem>
                  <SelectItem value="topical">Topical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Inventory Grid */}
      {filteredInventory.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {filteredInventory.map((item) => {
            const product = getProductById(item.product_id);
            if (!product) return null;

            return (
              <ProductBriefCard
                key={item.id}
                product={product}
                inventoryItem={item}
                onClick={() => handleProductClick(item, product)}
                onBrandClick={() => handleBrandClick(product)}
              />
            );
          })}
        </div>
      ) : (
        <Card className="bg-white/80 backdrop-blur-sm">
          <CardContent className="text-center py-8 md:py-12">
            <Package className="w-12 h-12 md:w-16 md:h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2">Your stash is empty</h3>
            <p className="text-gray-600 mb-4 md:mb-6 text-sm md:text-base">Start by scanning products from your dispensary</p>
            <Link to={createPageUrl("Scanner")}>
              <Button className="bg-green-600 hover:bg-green-700 w-full md:w-auto">
                <Plus className="w-4 h-4 mr-2" />
                Scan Your First Product
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}

      {/* Brief Info Modal */}
      <Dialog open={showBriefModal} onOpenChange={(open) => !open && setShowBriefModal(false)}>
        <DialogContent className="glass-card border-white/40 max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <Leaf className="w-5 h-5 text-green-600" />
              {selectedProduct?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            {selectedProduct?.brand && (
              <button
                onClick={() => handleBrandClick(selectedProduct)}
                className="text-gray-600 hover:text-green-600 hover:underline text-left transition-colors"
              >
                {selectedProduct.brand}
              </button>
            )}
            <div className="flex gap-2 flex-wrap">
              <Badge className={typeColors[selectedProduct?.type] || "bg-gray-100 text-gray-800"}>
                {selectedProduct?.type}
              </Badge>
              <Badge className={categoryColors[selectedProduct?.category] || "bg-gray-100 text-gray-800"}>
                {selectedProduct?.category}
              </Badge>
            </div>

            {/* Quantity */}
            <div className="p-3 bg-green-50/80 rounded-lg glass-card border-green-200/50">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Quantity in Stash</span>
                <span className="text-lg font-bold text-green-600">
                  {selectedInventoryItem?.quantity} {selectedInventoryItem?.unit}
                </span>
              </div>
            </div>

            {/* Cannabinoids */}
            {(selectedProduct?.thc_percentage > 0 || selectedProduct?.cbd_percentage > 0) && (
              <div className="flex items-center gap-3 pt-2 border-t border-white/30">
                <Droplet className="w-4 h-4 text-gray-400" />
                <div className="flex gap-3">
                  {selectedProduct?.thc_percentage > 0 && (
                    <span className="text-sm font-semibold text-red-600">THC {selectedProduct.thc_percentage}%</span>
                  )}
                  {selectedProduct?.cbd_percentage > 0 && (
                    <span className="text-sm font-semibold text-green-600">CBD {selectedProduct.cbd_percentage}%</span>
                  )}
                </div>
              </div>
            )}

            <div className="flex gap-2 pt-4">
              <Button 
                onClick={handleViewFullDetails}
                className="flex-1 bg-green-600 hover:bg-green-700 gap-2"
              >
                <ExternalLink className="w-4 h-4" />
                View Full Details
              </Button>
              <Link to={createPageUrl("NewSession") + `?product=${selectedProduct?.id}`} className="flex-1">
                <Button variant="outline" className="w-full glass-card border-white/40">
                  Log Session
                </Button>
              </Link>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Full Details Modal */}
      {showFullModal && selectedInventoryItem && selectedProduct && (
        <ProductDetailsModal
          inventoryItem={selectedInventoryItem}
          product={selectedProduct}
          dispensary={getDispensaryById(selectedInventoryItem.dispensary_id)}
          onOpenChange={(open) => !open && setShowFullModal(false)}
        />
      )}

      {/* Brand Details Modal */}
      {showBrandModal && selectedBrand && (
        <BrandDetailsModal
          brand={selectedBrand}
          isOpen={showBrandModal}
          onClose={() => setShowBrandModal(false)}
          onUpdate={loadData}
        />
      )}
    </div>
  );
}