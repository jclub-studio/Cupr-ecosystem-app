
import React, { useState, useEffect } from "react";
import { Session, Product, UserInventory, User, Dispensary } from "@/entities/all";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  TrendingUp,
  Package,
  Calendar,
  Star,
  Leaf,
  QrCode,
  Plus,
  ChevronRight,
  BookOpen,
  MessageSquare
} from "lucide-react";
import { format } from "date-fns";
import SessionDetailsModal from "../journal/SessionDetailsModal";
import ProductDetailsModal from "../inventory/ProductDetailsModal";

export default function DashboardTab() {
  const navigate = useNavigate();
  const [recentSessions, setRecentSessions] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [products, setProducts] = useState([]);
  const [dispensaries, setDispensaries] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedSession, setSelectedSession] = useState(null);
  const [selectedInventoryItem, setSelectedInventoryItem] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [sessionsData, inventoryData, productsData, userData, dispensariesData] = await Promise.all([
        Session.list("-date", 5),
        UserInventory.filter({ is_active: true }, "-purchase_date", 10),
        Product.list(),
        User.me(),
        Dispensary.list()
      ]);

      setCurrentUser(userData);
      setRecentSessions(sessionsData);
      setInventory(inventoryData);
      setDispensaries(dispensariesData);

      const relevantProductIds = new Set([
        ...sessionsData.map((s) => s.product_id),
        ...inventoryData.map((i) => i.product_id)
      ]);

      const allProducts = await Product.list();
      setProducts(allProducts.filter((p) => relevantProductIds.has(p.id)));

    } catch (error) {
      console.error("Error loading dashboard data:", error);
      setCurrentUser(null);
    } finally {
      setLoading(false);
    }
  };

  const getProductById = (productId) => {
    return products.find((p) => p.id === productId);
  };

  const getDispensaryById = (dispensaryId) => {
    return dispensaries.find((d) => d.id === dispensaryId);
  };

  const stats = {
    totalSessions: recentSessions.length,
    inventoryCount: inventory.length,
    avgRating: recentSessions.reduce((acc, session) => acc + (session.rating || 0), 0) / (recentSessions.length || 1),
    activePeriod: "Recent Activity"
  };

  if (loading) {
    return (
      <div className="p-3 space-y-4">
        <div className="animate-pulse">
          <div className="h-6 bg-white/60 backdrop-blur-md rounded-xl w-3/4 mb-4 shadow-sm"></div>
          <div className="grid grid-cols-2 gap-3 mb-4">
            {[1, 2, 3, 4].map((i) =>
              <div key={i} className="h-24 bg-white/60 backdrop-blur-md rounded-xl shadow-sm"></div>
            )}
          </div>
          <div className="space-y-3">
            {[1, 2].map((i) =>
              <div key={i} className="h-48 bg-white/60 backdrop-blur-md rounded-xl shadow-sm"></div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 px-3 py-4">
      {/* Welcome Header - Mobile Optimized */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-green-500/90 via-green-600/90 to-green-700/90 backdrop-blur-xl p-4 text-white shadow-2xl border border-white/20">
        <div className="absolute inset-0 bg-gradient-to-r from-black/10 to-transparent"></div>
        <div className="relative z-10">
          <h1 className="text-xl font-bold mb-2 leading-tight">
            Hey{currentUser?.full_name ? ` ${currentUser.full_name.split(' ')[0]}` : ''}! 👋
          </h1>
          <p className="text-green-50 text-sm mb-4 leading-relaxed">
            Ready to dive into your cannabis journey?
          </p>
          <Link to={createPageUrl("BuddyAI")}>
            <Button className="bg-white/90 text-green-700 hover:bg-white hover:text-green-800 shadow-lg border-0 font-medium backdrop-blur-sm transition-all duration-200 h-12 px-4 text-sm w-full sm:w-auto">
              <MessageSquare className="w-4 h-4 mr-2" /> 
              Chat with Buddy AI
            </Button>
          </Link>
        </div>
        <div className="absolute -right-2 -top-2 w-20 h-20 bg-white/10 rounded-full blur-xl"></div>
        <div className="absolute -right-4 -bottom-4 w-32 h-32 bg-white/5 rounded-full blur-2xl"></div>
      </div>

      {/* Stats Cards - Mobile Optimized Grid - Now Clickable */}
      <div className="grid grid-cols-2 gap-3">
        <Card 
          className="glass-card hover:shadow-lg transition-all duration-300 border-white/40 cursor-pointer active:scale-95"
          onClick={() => navigate(createPageUrl("Journal"))}
        >
          <CardHeader className="pb-2 px-3 pt-3">
            <div className="flex justify-between items-start">
              <CardTitle className="text-xs font-semibold text-gray-700 leading-tight">Sessions Logged</CardTitle>
              <div className="p-1.5 bg-green-100/80 rounded-lg">
                <Calendar className="w-3 h-3 text-green-600" />
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0 px-3 pb-3">
            <div className="text-2xl font-bold text-gray-900 mb-1">{stats.totalSessions}</div>
            <p className="text-xs text-gray-600">{stats.activePeriod}</p>
          </CardContent>
        </Card>

        <Card 
          className="glass-card hover:shadow-lg transition-all duration-300 border-white/40 cursor-pointer active:scale-95"
          onClick={() => navigate(createPageUrl("MyStash"))}
        >
          <CardHeader className="pb-2 px-3 pt-3">
            <div className="flex justify-between items-start">
              <CardTitle className="text-xs font-semibold text-gray-700 leading-tight">Active Products</CardTitle>
              <div className="p-1.5 bg-blue-100/80 rounded-lg">
                <Package className="w-3 h-3 text-blue-600" />
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0 px-3 pb-3">
            <div className="text-2xl font-bold text-gray-900 mb-1">{stats.inventoryCount}</div>
            <p className="text-xs text-gray-600">In your stash</p>
          </CardContent>
        </Card>

        <Card 
          className="glass-card hover:shadow-lg transition-all duration-300 border-white/40 cursor-pointer active:scale-95"
          onClick={() => navigate(createPageUrl("Journal"))}
        >
          <CardHeader className="pb-2 px-3 pt-3">
            <div className="flex justify-between items-start">
              <CardTitle className="text-xs font-semibold text-gray-700 leading-tight">Average Rating</CardTitle>
              <div className="p-1.5 bg-yellow-100/80 rounded-lg">
                <Star className="w-3 h-3 text-yellow-600" />
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0 px-3 pb-3">
            <div className="text-2xl font-bold text-gray-900 mb-1">{stats.avgRating.toFixed(1)}</div>
            <p className="text-xs text-gray-600">Out of 5.0</p>
          </CardContent>
        </Card>

        <Card 
          className="glass-card hover:shadow-lg transition-all duration-300 border-white/40 cursor-pointer active:scale-95"
          onClick={() => navigate(createPageUrl("Journal"))} // Assuming Journal for general tracking for now
        >
          <CardHeader className="pb-2 px-3 pt-3">
            <div className="flex justify-between items-start">
              <CardTitle className="text-xs font-semibold text-gray-700 leading-tight">Wellness</CardTitle>
              <div className="p-1.5 bg-green-100/80 rounded-lg">
                <TrendingUp className="w-3 h-3 text-green-600" />
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0 px-3 pb-3">
            <div className="text-lg font-bold text-gray-900 mb-1">Tracking</div>
            <p className="text-xs text-gray-600">Pain, mood & anxiety</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Sessions & Inventory - Mobile Stack */}
      <div className="space-y-4">
        <Card className="glass-card hover:shadow-lg transition-all duration-300 border-white/40">
          <CardHeader className="border-b border-white/20 pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-semibold text-gray-800">
              <div className="p-1.5 bg-green-100/80 rounded-lg">
                <BookOpen className="w-4 h-4 text-green-600" />
              </div>
              Recent Sessions
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            {recentSessions.length > 0 ? (
              <div className="space-y-3">
                {recentSessions.slice(0, 3).map((session) => {
                  const product = getProductById(session.product_id);
                  return (
                    <div 
                      key={session.id} 
                      onClick={() => setSelectedSession(session)}
                      className="flex items-center gap-3 p-3 rounded-xl bg-white/60 hover:bg-white/80 transition-all duration-200 border border-white/40 active:scale-[0.98] cursor-pointer"
                    >
                      <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-green-500 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                        <Leaf className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-gray-900 truncate text-sm">{product?.name || 'Unknown Product'}</h4>
                        <p className="text-xs text-gray-600 mt-0.5">
                          {format(new Date(session.date), "MMM d")} • {session.consumption_method}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0 bg-yellow-50/80 px-2 py-1 rounded-lg">
                        <Star className="w-3 h-3 text-yellow-500 fill-current" />
                        <span className="text-xs font-medium text-yellow-700">{session.rating || 'N/A'}</span>
                      </div>
                    </div>
                  );
                })}
                {recentSessions.length > 3 && (
                  <Link to={createPageUrl("Journal")}>
                    <Button variant="ghost" className="w-full text-sm h-10 text-gray-600 hover:text-gray-800">
                      View All Sessions
                      <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                  </Link>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="w-12 h-12 bg-gray-100/80 rounded-full flex items-center justify-center mx-auto mb-3">
                  <BookOpen className="w-6 h-6 text-gray-400" />
                </div>
                <h3 className="text-base font-semibold text-gray-900 mb-2">No sessions logged yet</h3>
                <p className="text-gray-600 mb-4 text-sm">Start your journey by logging your first session</p>
                <Link to={createPageUrl("NewSession")}>
                  <Button className="bg-green-600/90 hover:bg-green-700/90 shadow-lg border-0 h-12 px-6 font-medium w-full">
                    <Plus className="w-4 h-4 mr-2" />
                    Log Your First Session
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="glass-card hover:shadow-lg transition-all duration-300 border-white/40">
          <CardHeader className="border-b border-white/20 pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-semibold text-gray-800">
              <div className="p-1.5 bg-purple-100/80 rounded-lg">
                <Package className="w-4 h-4 text-purple-600" />
              </div>
              My Stash
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            {inventory.length > 0 ? (
              <div className="space-y-3">
                {inventory.slice(0, 3).map((item) => {
                  const product = getProductById(item.product_id);
                  return (
                    <div 
                      key={item.id} 
                      onClick={() => setSelectedInventoryItem(item)}
                      className="flex items-center gap-3 p-3 rounded-xl bg-white/60 hover:bg-white/80 transition-all duration-200 border border-white/40 active:scale-[0.98] cursor-pointer"
                    >
                      <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-purple-500 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                        <span className="text-white font-bold text-sm">
                          {product?.type?.charAt(0).toUpperCase() || 'P'}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-gray-900 truncate text-sm">{product?.name || 'Unknown Product'}</h4>
                        <p className="text-xs text-gray-600 mt-0.5">
                          {item.quantity} {item.unit} • {product?.type}
                        </p>
                      </div>
                      <Badge variant="secondary" className="bg-white/80 text-gray-700 border border-white/40 font-medium text-xs px-2 py-0.5">
                        {product?.category}
                      </Badge>
                    </div>
                  );
                })}
                {inventory.length > 3 && (
                  <Link to={createPageUrl("MyStash")}>
                    <Button variant="ghost" className="w-full text-sm h-10 text-gray-600 hover:text-gray-800">
                      View Full Stash
                      <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                  </Link>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="w-12 h-12 bg-gray-100/80 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Package className="w-6 h-6 text-gray-400" />
                </div>
                <h3 className="text-base font-semibold text-gray-900 mb-2">Your stash is empty</h3>
                <p className="text-gray-600 mb-4 text-sm">Add your first product to get started</p>
                <Link to={createPageUrl("Scanner")}>
                  <Button className="bg-purple-600/90 hover:bg-purple-700/90 shadow-lg border-0 h-12 px-6 font-medium w-full">
                    <QrCode className="w-4 h-4 mr-2" />
                    Scan Your First Product
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions - Mobile Optimized */}
      <div className="grid grid-cols-2 gap-3 pt-2">
        <Link to={createPageUrl("NewSession")}>
          <Button className="w-full h-14 bg-green-600/90 hover:bg-green-700/90 text-white font-medium shadow-lg rounded-xl flex flex-col items-center justify-center gap-1">
            <Plus className="w-5 h-5" />
            <span className="text-xs">Log Session</span>
          </Button>
        </Link>
        <Link to={createPageUrl("Scanner")}>
          <Button variant="outline" className="w-full h-14 glass-card border-white/40 hover:bg-white/60 font-medium rounded-xl flex flex-col items-center justify-center gap-1">
            <QrCode className="w-5 h-5" />
            <span className="text-xs">Add to Stash</span>
          </Button>
        </Link>
      </div>

      {/* Session Details Modal */}
      {selectedSession && (
        <SessionDetailsModal
          session={selectedSession}
          product={getProductById(selectedSession.product_id)}
          onOpenChange={() => setSelectedSession(null)}
        />
      )}

      {/* Product Details Modal */}
      {selectedInventoryItem && (
        <ProductDetailsModal
          inventoryItem={selectedInventoryItem}
          product={getProductById(selectedInventoryItem.product_id)}
          dispensary={getDispensaryById(getProductById(selectedInventoryItem.product_id)?.dispensary_id)}
          onOpenChange={() => setSelectedInventoryItem(null)}
        />
      )}
    </div>
  );
}
