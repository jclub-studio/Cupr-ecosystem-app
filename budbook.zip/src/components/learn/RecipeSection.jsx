import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Clock, Users, Star, ChefHat, Search, AlertTriangle, Loader2 } from 'lucide-react';
import RecipeDetailsModal from './RecipeDetailsModal';

export default function RecipeSection({ recipes, searchTerm, loading }) {
  const [localSearchTerm, setLocalSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterDifficulty, setFilterDifficulty] = useState('all');
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  const effectiveSearchTerm = searchTerm || localSearchTerm;

  const filteredRecipes = recipes.filter(recipe => {
    const matchesSearch = recipe.title.toLowerCase().includes(effectiveSearchTerm.toLowerCase()) ||
                         recipe.description.toLowerCase().includes(effectiveSearchTerm.toLowerCase());
    const matchesCategory = filterCategory === 'all' || recipe.category === filterCategory;
    const matchesDifficulty = filterDifficulty === 'all' || recipe.difficulty === filterDifficulty;
    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  const categoryColors = {
    brownies: "bg-amber-100/80 text-amber-800 border-amber-200/50",
    cookies: "bg-orange-100/80 text-orange-800 border-orange-200/50",
    gummies: "bg-red-100/80 text-red-800 border-red-200/50",
    chocolates: "bg-yellow-100/80 text-yellow-800 border-yellow-200/50",
    beverages: "bg-blue-100/80 text-blue-800 border-blue-200/50",
    savory: "bg-green-100/80 text-green-800 border-green-200/50",
    butter_oils: "bg-emerald-100/80 text-emerald-800 border-emerald-200/50",
    tinctures: "bg-purple-100/80 text-purple-800 border-purple-200/50"
  };

  const difficultyColors = {
    easy: "bg-green-100/80 text-green-800 border-green-200/50",
    medium: "bg-yellow-100/80 text-yellow-800 border-yellow-200/50",
    hard: "bg-red-100/80 text-red-800 border-red-200/50"
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="w-12 h-12 animate-spin text-green-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Safety Notice */}
      <Card className="glass-card border-yellow-200/50 bg-yellow-50/80">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 md:w-6 md:h-6 text-yellow-600 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-yellow-800 mb-1 text-sm md:text-base">Important Safety Notice</h4>
              <p className="text-xs md:text-sm text-yellow-700">
                Always consume edibles responsibly. Start with low doses, wait 2+ hours before consuming more, 
                and be aware of local laws regarding cannabis consumption and possession.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card className="glass-card border-white/40">
        <CardContent className="p-4 md:p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search recipes..."
                value={localSearchTerm}
                onChange={(e) => setLocalSearchTerm(e.target.value)}
                className="pl-10 glass-card border-white/40 min-h-[44px]"
              />
            </div>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-full md:w-40 glass-card border-white/40 min-h-[44px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent className="glass-card border-white/40">
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="brownies">Brownies</SelectItem>
                <SelectItem value="cookies">Cookies</SelectItem>
                <SelectItem value="gummies">Gummies</SelectItem>
                <SelectItem value="chocolates">Chocolates</SelectItem>
                <SelectItem value="beverages">Beverages</SelectItem>
                <SelectItem value="savory">Savory</SelectItem>
                <SelectItem value="butter_oils">Butter & Oils</SelectItem>
                <SelectItem value="tinctures">Tinctures</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterDifficulty} onValueChange={setFilterDifficulty}>
              <SelectTrigger className="w-full md:w-32 glass-card border-white/40 min-h-[44px]">
                <SelectValue placeholder="Difficulty" />
              </SelectTrigger>
              <SelectContent className="glass-card border-white/40">
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="easy">Easy</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="hard">Hard</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Recipe Grid */}
      {filteredRecipes.length === 0 ? (
        <Card className="glass-card border-white/40">
          <CardContent className="text-center py-12 md:py-20">
            <ChefHat className="w-12 h-12 md:w-16 md:h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2">No recipes found</h3>
            <p className="text-gray-600 text-sm md:text-base">Try adjusting your search terms or filters.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {filteredRecipes.map(recipe => (
            <Card key={recipe.id} className="glass-card border-white/40 hover:shadow-xl transition-all duration-300 cursor-pointer" onClick={() => setSelectedRecipe(recipe)}>
              <CardHeader>
                <CardTitle className="text-base md:text-lg mb-2">{recipe.title}</CardTitle>
                <p className="text-sm text-gray-600 mb-3 line-clamp-2">{recipe.description}</p>
                <div className="flex gap-2 flex-wrap">
                  <Badge className={`text-xs glass-card ${categoryColors[recipe.category] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>
                    {recipe.category.replace(/_/g, ' ')}
                  </Badge>
                  <Badge className={`text-xs glass-card ${difficultyColors[recipe.difficulty] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>
                    {recipe.difficulty}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span>{(recipe.prep_time + recipe.cook_time)} min</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-gray-500" />
                    <span>{recipe.servings} servings</span>
                  </div>
                </div>
                
                {recipe.dosage_per_serving && (
                  <div className="p-2 bg-orange-50/80 rounded-lg text-center glass-card border-orange-200/50">
                    <p className="text-xs text-orange-800 font-semibold">Est. Dosage</p>
                    <p className="font-bold text-orange-600 text-sm">{recipe.dosage_per_serving}</p>
                  </div>
                )}
                
                {recipe.rating && (
                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="font-medium text-sm">{recipe.rating}</span>
                  </div>
                )}
                
                <Button className="w-full min-h-[44px]" size="sm" variant="outline">
                  <ChefHat className="w-4 h-4 mr-2" />
                  View Recipe
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {selectedRecipe && (
        <RecipeDetailsModal
          recipe={selectedRecipe}
          onClose={() => setSelectedRecipe(null)}
        />
      )}
    </div>
  );
}