import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ExternalLink, Calendar, Users, Building, Search, CheckCircle, Loader2, BookOpen } from 'lucide-react';
import { format } from 'date-fns';

export default function ResearchSection({ studies, searchTerm, loading }) {
  const [localSearchTerm, setLocalSearchTerm] = useState('');
  const [filterFocus, setFilterFocus] = useState('all');

  const effectiveSearchTerm = searchTerm || localSearchTerm;

  const filteredStudies = studies.filter(study => {
    const matchesSearch = study.title.toLowerCase().includes(effectiveSearchTerm.toLowerCase()) ||
                         study.abstract.toLowerCase().includes(effectiveSearchTerm.toLowerCase());
    const matchesFocus = filterFocus === 'all' || study.focus_area === filterFocus;
    return matchesSearch && matchesFocus;
  });

  const focusColors = {
    medical_efficacy: "bg-blue-100/80 text-blue-800 border-blue-200/50",
    terpene_effects: "bg-green-100/80 text-green-800 border-green-200/50",
    safety: "bg-red-100/80 text-red-800 border-red-200/50",
    dosage: "bg-yellow-100/80 text-yellow-800 border-yellow-200/50",
    cultivation: "bg-emerald-100/80 text-emerald-800 border-emerald-200/50",
    extraction: "bg-purple-100/80 text-purple-800 border-purple-200/50",
    pharmacology: "bg-cyan-100/80 text-cyan-800 border-cyan-200/50"
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="w-12 h-12 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card className="glass-card border-white/40">
        <CardContent className="p-4 md:p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search research studies..."
                value={localSearchTerm}
                onChange={(e) => setLocalSearchTerm(e.target.value)}
                className="pl-10 glass-card border-white/40 min-h-[44px]"
              />
            </div>
            <Select value={filterFocus} onValueChange={setFilterFocus}>
              <SelectTrigger className="w-full md:w-48 glass-card border-white/40 min-h-[44px]">
                <SelectValue placeholder="Focus Area" />
              </SelectTrigger>
              <SelectContent className="glass-card border-white/40">
                <SelectItem value="all">All Focus Areas</SelectItem>
                <SelectItem value="medical_efficacy">Medical Efficacy</SelectItem>
                <SelectItem value="terpene_effects">Terpene Effects</SelectItem>
                <SelectItem value="safety">Safety</SelectItem>
                <SelectItem value="dosage">Dosage</SelectItem>
                <SelectItem value="cultivation">Cultivation</SelectItem>
                <SelectItem value="extraction">Extraction</SelectItem>
                <SelectItem value="pharmacology">Pharmacology</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Studies List */}
      {filteredStudies.length === 0 ? (
        <Card className="glass-card border-white/40">
          <CardContent className="text-center py-12 md:py-20">
            <BookOpen className="w-12 h-12 md:w-16 md:h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2">No research found</h3>
            <p className="text-gray-600 text-sm md:text-base">Try adjusting your search terms or filters.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {filteredStudies.map(study => (
            <Card key={study.id} className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <div className="flex justify-between items-start gap-4">
                  <div className="flex-1">
                    <CardTitle className="text-base md:text-lg mb-2 flex items-center gap-2">
                      {study.title}
                      {study.is_peer_reviewed && (
                        <CheckCircle className="w-4 h-4 md:w-5 md:h-5 text-green-600" title="Peer Reviewed" />
                      )}
                    </CardTitle>
                    <div className="flex flex-wrap gap-3 md:gap-4 text-xs md:text-sm text-gray-600 mb-3">
                      <div className="flex items-center gap-1">
                        <Users className="w-3 h-3 md:w-4 md:h-4" />
                        <span>{study.authors.slice(0, 2).join(', ')}{study.authors.length > 2 ? ` +${study.authors.length - 2} more` : ''}</span>
                      </div>
                      {study.institution && (
                        <div className="flex items-center gap-1">
                          <Building className="w-3 h-3 md:w-4 md:h-4" />
                          <span className="truncate">{study.institution}</span>
                        </div>
                      )}
                      {study.publication_date && (
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 md:w-4 md:h-4" />
                          <span>{format(new Date(study.publication_date), 'MMM yyyy')}</span>
                        </div>
                      )}
                    </div>
                    <Badge className={`glass-card ${focusColors[study.focus_area] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>
                      {study.focus_area.replace(/_/g, ' ')}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2 text-sm md:text-base">Abstract</h4>
                  <p className="text-sm text-gray-700 leading-relaxed">{study.abstract}</p>
                </div>
                
                {study.key_findings && study.key_findings.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2 text-sm md:text-base">Key Findings</h4>
                    <ul className="space-y-1">
                      {study.key_findings.map((finding, index) => (
                        <li key={index} className="text-sm text-gray-700 flex items-start gap-2">
                          <span className="w-1 h-1 bg-green-600 rounded-full mt-2 flex-shrink-0"></span>
                          <span>{finding}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center pt-3 border-t border-white/30 gap-3">
                  {study.journal && (
                    <span className="text-sm text-gray-600 italic">{study.journal}</span>
                  )}
                  <Button size="sm" variant="outline" className="glass-card border-white/40 hover:bg-white/60 min-h-[36px] w-full md:w-auto">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Read Full Study
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}