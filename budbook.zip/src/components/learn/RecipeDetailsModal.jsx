import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Clock, Users, ChefHat, AlertTriangle } from 'lucide-react';

export default function RecipeDetailsModal({ recipe, onClose }) {
  if (!recipe) return null;

  const categoryColors = {
    brownies: "bg-amber-100 text-amber-800",
    cookies: "bg-orange-100 text-orange-800", 
    gummies: "bg-red-100 text-red-800",
    chocolates: "bg-yellow-100 text-yellow-800",
    beverages: "bg-blue-100 text-blue-800",
    savory: "bg-green-100 text-green-800",
    butter_oils: "bg-emerald-100 text-emerald-800",
    tinctures: "bg-purple-100 text-purple-800"
  };

  const difficultyColors = {
    easy: "bg-green-100 text-green-800",
    medium: "bg-yellow-100 text-yellow-800",
    hard: "bg-red-100 text-red-800"
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl bg-white/95 backdrop-blur-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">{recipe.title}</DialogTitle>
          <p className="text-gray-600">{recipe.description}</p>
          <div className="flex gap-2 pt-2">
            <Badge className={categoryColors[recipe.category]}>
              {recipe.category.replace(/_/g, ' ')}
            </Badge>
            <Badge className={difficultyColors[recipe.difficulty]}>
              {recipe.difficulty}
            </Badge>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Recipe Info */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
            <div className="text-center">
              <Clock className="w-6 h-6 mx-auto mb-2 text-blue-600" />
              <p className="text-sm text-gray-600">Prep Time</p>
              <p className="font-bold">{recipe.prep_time} min</p>
            </div>
            <div className="text-center">
              <ChefHat className="w-6 h-6 mx-auto mb-2 text-green-600" />
              <p className="text-sm text-gray-600">Cook Time</p>
              <p className="font-bold">{recipe.cook_time} min</p>
            </div>
            <div className="text-center">
              <Users className="w-6 h-6 mx-auto mb-2 text-purple-600" />
              <p className="text-sm text-gray-600">Servings</p>
              <p className="font-bold">{recipe.servings}</p>
            </div>
            {recipe.dosage_per_serving && (
              <div className="text-center">
                <AlertTriangle className="w-6 h-6 mx-auto mb-2 text-orange-600" />
                <p className="text-sm text-gray-600">Est. Dosage</p>
                <p className="font-bold text-orange-600">{recipe.dosage_per_serving}</p>
              </div>
            )}
          </div>

          {/* Ingredients */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Ingredients</h3>
            <ul className="space-y-2">
              {recipe.ingredients.map((ingredient, index) => (
                <li key={index} className="flex items-start gap-3">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 flex-shrink-0"></span>
                  <span>{ingredient}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Instructions */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Instructions</h3>
            <ol className="space-y-3">
              {recipe.instructions.map((instruction, index) => (
                <li key={index} className="flex gap-4">
                  <span className="w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0">
                    {index + 1}
                  </span>
                  <p className="pt-1">{instruction}</p>
                </li>
              ))}
            </ol>
          </div>

          {/* Tips */}
          {recipe.tips && recipe.tips.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-3">Pro Tips</h3>
              <div className="bg-blue-50 p-4 rounded-lg">
                <ul className="space-y-2">
                  {recipe.tips.map((tip, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm">
                      <span className="w-1 h-1 bg-blue-600 rounded-full mt-2 flex-shrink-0"></span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* Safety Warning */}
          <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-yellow-600 mt-1 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-yellow-800 mb-2">Safety Reminder</h4>
                <p className="text-sm text-yellow-700">
                  Start with a small portion and wait at least 2 hours before consuming more. 
                  Effects can take 30 minutes to 2 hours to fully manifest. Store safely away from children and pets.
                </p>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}