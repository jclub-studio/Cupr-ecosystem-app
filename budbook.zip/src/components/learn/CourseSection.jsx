import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, Clock, User, ExternalLink, Loader2, GraduationCap } from 'lucide-react';

const CourseCard = ({ course }) => {
  const levelColors = {
    beginner: "bg-green-100/80 text-green-800 border-green-200/50",
    intermediate: "bg-yellow-100/80 text-yellow-800 border-yellow-200/50",
    advanced: "bg-red-100/80 text-red-800 border-red-200/50"
  };

  const categoryColors = {
    medical: "bg-blue-100/80 text-blue-800 border-blue-200/50",
    recreational: "bg-purple-100/80 text-purple-800 border-purple-200/50",
    business: "bg-indigo-100/80 text-indigo-800 border-indigo-200/50",
    compliance: "bg-gray-100/80 text-gray-800 border-gray-200/50",
    cultivation: "bg-green-100/80 text-green-800 border-green-200/50",
    extraction: "bg-orange-100/80 text-orange-800 border-orange-200/50"
  };

  return (
    <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300 flex flex-col h-full">
      {course.thumbnail_url && (
        <div className="relative overflow-hidden rounded-t-xl">
          <img 
            src={course.thumbnail_url} 
            alt={course.title}
            className="w-full h-40 md:h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute top-2 right-2">
            {course.price === 0 ? (
              <Badge className="bg-green-600/90 text-white font-medium">Free</Badge>
            ) : (
              <Badge className="bg-blue-600/90 text-white font-medium">${course.price}</Badge>
            )}
          </div>
        </div>
      )}
      
      <CardHeader className="flex-1">
        <div className="space-y-3">
          <CardTitle className="text-base md:text-lg line-clamp-2">{course.title}</CardTitle>
          <p className="text-sm text-gray-600 line-clamp-3">{course.description}</p>
          
          <div className="flex flex-wrap gap-2">
            <Badge className={`text-xs glass-card ${levelColors[course.level] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>
              {course.level}
            </Badge>
            <Badge className={`text-xs glass-card ${categoryColors[course.category] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>
              {course.category}
            </Badge>
          </div>
          
          <div className="space-y-2 text-sm text-gray-600">
            {course.instructor && (
              <div className="flex items-center gap-2">
                <User className="w-4 h-4" />
                <span>{course.instructor}</span>
              </div>
            )}
            {course.duration_hours && (
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>{course.duration_hours} hours</span>
              </div>
            )}
            {course.rating && (
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 fill-current text-yellow-500" />
                <span>{course.rating}/5</span>
              </div>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <Button 
          className="w-full bg-blue-600/90 hover:bg-blue-700/90 min-h-[44px] font-medium"
          onClick={() => course.course_url && window.open(course.course_url, '_blank')}
        >
          <ExternalLink className="w-4 h-4 mr-2" />
          View Course
        </Button>
      </CardContent>
    </Card>
  );
};

export default function CourseSection({ courses, searchTerm, loading }) {
  const filteredCourses = courses.filter(course =>
    course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    course.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    course.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
      </div>
    );
  }

  if (filteredCourses.length === 0) {
    return (
      <Card className="glass-card border-white/40">
        <CardContent className="text-center py-12 md:py-20">
          <GraduationCap className="w-12 h-12 md:w-16 md:h-16 mx-auto mb-4 text-gray-300" />
          <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2">No courses found</h3>
          <p className="text-gray-600 text-sm md:text-base">Try adjusting your search terms.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
      {filteredCourses.map(course => (
        <CourseCard key={course.id} course={course} />
      ))}
    </div>
  );
}