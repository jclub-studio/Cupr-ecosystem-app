import React from 'react';
import { Card, CardContent, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, BookOpen, Calendar, Download, Loader2 } from 'lucide-react';
import { format } from 'date-fns';

const EBookCard = ({ ebook }) => {
  const categoryColors = {
    indoor_growing: "bg-green-100/80 text-green-800 border-green-200/50",
    outdoor_growing: "bg-lime-100/80 text-lime-800 border-lime-200/50",
    hydroponics: "bg-cyan-100/80 text-cyan-800 border-cyan-200/50",
    organic: "bg-emerald-100/80 text-emerald-800 border-emerald-200/50",
    breeding: "bg-purple-100/80 text-purple-800 border-purple-200/50",
    pest_management: "bg-orange-100/80 text-orange-800 border-orange-200/50",
    harvesting: "bg-yellow-100/80 text-yellow-800 border-yellow-200/50",
    processing: "bg-indigo-100/80 text-indigo-800 border-indigo-200/50"
  };

  return (
    <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300 flex flex-col h-full">
      <div className="flex gap-4 p-4 md:p-6">
        {ebook.cover_url && (
          <div className="flex-shrink-0">
            <img 
              src={ebook.cover_url} 
              alt={ebook.title}
              className="w-16 h-20 md:w-20 md:h-24 object-cover rounded-lg shadow-md"
            />
          </div>
        )}
        
        <div className="flex-1 min-w-0 space-y-3">
          <div>
            <CardTitle className="text-base md:text-lg line-clamp-2">{ebook.title}</CardTitle>
            <p className="text-sm text-gray-600 mt-1">{ebook.author}</p>
          </div>
          
          <p className="text-sm text-gray-600 line-clamp-2">{ebook.description}</p>
          
          <div className="flex flex-wrap gap-2">
            <Badge className={`text-xs glass-card ${categoryColors[ebook.category] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>
              {ebook.category.replace('_', ' ')}
            </Badge>
            {ebook.is_bestseller && (
              <Badge className="text-xs bg-gold-100/80 text-gold-800 border-gold-200/50 glass-card">
                Bestseller
              </Badge>
            )}
          </div>
          
          <div className="flex flex-wrap gap-3 text-xs text-gray-500">
            {ebook.pages && (
              <div className="flex items-center gap-1">
                <BookOpen className="w-3 h-3" />
                <span>{ebook.pages} pages</span>
              </div>
            )}
            {ebook.publication_date && (
              <div className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                <span>{format(new Date(ebook.publication_date), 'MMM yyyy')}</span>
              </div>
            )}
            {ebook.rating && (
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3 fill-current text-yellow-500" />
                <span>{ebook.rating}/5</span>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <CardContent className="pt-0 mt-auto">
        <div className="flex items-center justify-between">
          <div className="text-sm font-semibold text-gray-900">
            {ebook.price === 0 ? 'Free' : `$${ebook.price}`}
          </div>
          <Button 
            size="sm"
            className="bg-green-600/90 hover:bg-green-700/90 font-medium"
            onClick={() => ebook.download_url && window.open(ebook.download_url, '_blank')}
          >
            <Download className="w-4 h-4 mr-2" />
            Download
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default function EBookSection({ ebooks, searchTerm, loading }) {
  const filteredBooks = ebooks.filter(book =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="w-12 h-12 animate-spin text-green-600" />
      </div>
    );
  }

  if (filteredBooks.length === 0) {
    return (
      <Card className="glass-card border-white/40">
        <CardContent className="text-center py-12 md:py-20">
          <BookOpen className="w-12 h-12 md:w-16 md:h-16 mx-auto mb-4 text-gray-300" />
          <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2">No e-books found</h3>
          <p className="text-gray-600 text-sm md:text-base">Try adjusting your search terms.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
      {filteredBooks.map(book => (
        <EBookCard key={book.id} ebook={book} />
      ))}
    </div>
  );
}