import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, MapPin, Clock } from 'lucide-react';

export default function DispensaryCard({ place, onSelect }) {
  const rating = place.rating || 0;

  return (
    <Card 
      className="glass-card border-white/40 hover:shadow-xl hover:ring-2 hover:ring-green-400/50 transition-all duration-300 cursor-pointer group"
      onClick={onSelect}
    >
      <CardHeader className="pb-3">
        <CardTitle className="text-base md:text-lg group-hover:text-green-600 transition-colors duration-200">
          {place.name}
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-3">
        <div className="flex items-start gap-2 text-sm text-gray-600">
          <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0 text-gray-500" />
          <span className="line-clamp-2">{place.vicinity}</span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1">
              <Star className={`w-4 h-4 ${rating > 0 ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} />
              <span className="font-medium text-sm">{rating > 0 ? rating.toFixed(1) : 'N/A'}</span>
            </div>
            {place.user_ratings_total && (
              <span className="text-xs text-gray-500">({place.user_ratings_total})</span>
            )}
          </div>
          
          {place.opening_hours ? (
            <Badge 
              className={`text-xs ${
                place.opening_hours.open_now 
                  ? 'bg-green-100/80 text-green-800 border-green-200/50' 
                  : 'bg-red-100/80 text-red-800 border-red-200/50'
              } glass-card`}
            >
              {place.opening_hours.open_now ? (
                <>
                  <Clock className="w-3 h-3 mr-1" />
                  Open Now
                </>
              ) : (
                'Closed'
              )}
            </Badge>
          ) : (
            <Badge variant="outline" className="text-xs glass-card border-white/40">
              Hours Unknown
            </Badge>
          )}
        </div>
        
        <Button 
          variant="outline" 
          size="sm" 
          className="w-full mt-3 glass-card border-white/40 hover:bg-green-50/80 hover:text-green-700 hover:border-green-200/50 transition-all duration-200 min-h-[36px] group-hover:bg-green-50/80"
        >
          View Details
        </Button>
      </CardContent>
    </Card>
  );
}