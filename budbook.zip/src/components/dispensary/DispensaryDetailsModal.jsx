
import React, { useState, useEffect } from 'react';
import { Dispensary } from "@/entities/Dispensary";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Star, MapPin, Phone, Globe, Clock, MessageSquareText, ExternalLink, Bookmark, Check } from 'lucide-react';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";

function DetailItem({ icon: Icon, label, value, href, className }) {
    const content = href ? <a href={href} target="_blank" rel="noopener noreferrer" className="hover:underline text-blue-600">{value}</a> : <span>{value}</span>;
    return (
      <div className={`flex items-start gap-3 ${className}`}>
        <Icon className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
        <div>
          <p className="text-sm text-gray-600">{label}</p>
          <div className="font-medium">{content}</div>
        </div>
      </div>
    );
}

export default function DispensaryDetailsModal({ isOpen, onClose, details, isLoading }) {
  const [isSaving, setIsSaving] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    const checkIfSaved = async () => {
      if (details?.place_id) {
        const existing = await Dispensary.filter({ google_place_id: details.place_id });
        if (existing.length > 0) {
          setIsSaved(true);
        } else {
          setIsSaved(false);
        }
      }
    };
    checkIfSaved();
  }, [details]);

  const handleSaveShop = async () => {
    if (!details || isSaved) return;

    setIsSaving(true);
    try {
      await Dispensary.create({
        name: details.name,
        address: details.formatted_address,
        phone: details.formatted_phone_number,
        website: details.website,
        hours: details.opening_hours?.weekday_text?.join('\n'),
        google_maps_url: details.url,
        google_place_id: details.place_id,
        shop_type: 'dispensary', // Found via dispensary search
      });
      setIsSaved(true);
    } catch (error) {
      console.error("Failed to save shop:", error);
      // Optionally, show an error toast to the user
    } finally {
      setIsSaving(false);
    }
  };
  
  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-3xl bg-white/90 backdrop-blur-lg">
        {isLoading || !details ? (
          <div className="h-96 flex items-center justify-center">
            <Loader2 className="animate-spin text-green-600" size={48} />
          </div>
        ) : (
          <>
            <DialogHeader className="pr-6 flex-row items-start justify-between">
              <div>
                <DialogTitle className="text-2xl font-bold text-gray-900 mb-2">{details.name}</DialogTitle>
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                        <Star className="w-5 h-5 text-yellow-400 fill-current" />
                        <span className="font-bold">{details.rating}</span>
                        <span className="text-sm text-gray-500">({details.reviews?.length || 0} reviews)</span>
                    </div>
                    {details.opening_hours?.open_now ? (
                      <Badge className="bg-green-100 text-green-800">Open Now</Badge>
                    ) : (
                      <Badge variant="destructive">Closed</Badge>
                    )}
                </div>
              </div>
              <Button 
                onClick={handleSaveShop} 
                disabled={isSaving || isSaved} 
                className="gap-2"
                variant={isSaved ? "secondary" : "default"}
              >
                {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : isSaved ? <Check className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
                {isSaving ? 'Saving...' : isSaved ? 'Saved' : 'Save Shop'}
              </Button>
            </DialogHeader>

            <div className="max-h-[70vh] overflow-y-auto p-1 pr-4 space-y-6">
              {details.photos && details.photos.length > 0 && (
                <Carousel className="w-full">
                  <CarouselContent>
                    {details.photos.map((photo, index) => (
                      <CarouselItem key={index}>
                        <img src={photo} alt={`${details.name} photo ${index + 1}`} className="w-full h-64 object-cover rounded-lg" />
                      </CarouselItem>
                    ))}
                  </CarouselContent>
                  <CarouselPrevious className="left-2" />
                  <CarouselNext className="right-2" />
                </Carousel>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                  <DetailItem icon={MapPin} label="Address" value={details.formatted_address} href={details.url} />
                  {details.formatted_phone_number && <DetailItem icon={Phone} label="Phone" value={details.formatted_phone_number} href={`tel:${details.formatted_phone_number}`} />}
                  {details.website && <DetailItem icon={Globe} label="Website" value={details.website} href={details.website} />}
              </div>

              {details.opening_hours && (
                <div>
                  <h4 className="font-semibold mb-3 flex items-center gap-2"><Clock className="w-5 h-5" /> Opening Hours</h4>
                  <div className="space-y-1 text-sm pl-7">
                    {details.opening_hours.weekday_text.map((line, i) => <p key={i}>{line}</p>)}
                  </div>
                </div>
              )}

              {details.reviews && details.reviews.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-3 flex items-center gap-2"><MessageSquareText className="w-5 h-5" /> Reviews</h4>
                  <div className="space-y-4 pl-7">
                    {details.reviews.slice(0, 2).map((review, i) => (
                      <div key={i} className="border-l-2 border-green-200 pl-4">
                          <div className="flex items-center gap-2 mb-1">
                              <img src={review.profile_photo_url} alt={review.author_name} className="w-6 h-6 rounded-full" />
                              <span className="font-medium">{review.author_name}</span>
                              <div className="flex items-center gap-0.5 ml-auto">
                                  <Star className="w-3 h-3 text-yellow-400 fill-current" />
                                  <span>{review.rating}</span>
                              </div>
                          </div>
                          <p className="text-sm text-gray-600">{review.text}</p>
                          <p className="text-xs text-gray-400 mt-1">{review.relative_time_description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
               <Button asChild className="mt-4 w-full">
                  <a href={details.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                    <ExternalLink className="w-4 h-4" /> View on Google Maps
                  </a>
               </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
