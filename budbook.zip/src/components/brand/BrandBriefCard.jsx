import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, Globe, MapPin } from 'lucide-react';

export default function BrandBriefCard({ brand, onClick }) {
  const tierColors = {
    budget: "bg-gray-100/80 text-gray-800 border-gray-200/50",
    "mid-tier": "bg-blue-100/80 text-blue-800 border-blue-200/50",
    premium: "bg-purple-100/80 text-purple-800 border-purple-200/50",
    luxury: "bg-amber-100/80 text-amber-800 border-amber-200/50"
  };

  return (
    <Card 
      onClick={onClick}
      className="glass-card border-white/40 hover:shadow-xl hover:scale-105 transition-all duration-300 cursor-pointer group"
    >
      <CardContent className="p-4">
        <div className="space-y-3">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <h3 className="text-base md:text-lg font-bold text-gray-900 mb-1 group-hover:text-green-600 transition-colors truncate">
                {brand.name}
              </h3>
              {brand.location?.state && (
                <p className="text-xs text-gray-500 flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {brand.location.state}
                </p>
              )}
            </div>
            {brand.is_favorite && (
              <Star className="w-5 h-5 text-yellow-500 fill-current flex-shrink-0" />
            )}
          </div>

          {/* Categories */}
          <div className="flex gap-1 flex-wrap">
            {brand.primary_categories?.slice(0, 3).map((category, idx) => (
              <Badge key={idx} variant="outline" className="text-xs glass-card border-white/40">
                {category}
              </Badge>
            ))}
            {brand.primary_categories?.length > 3 && (
              <Badge variant="outline" className="text-xs glass-card border-white/40">
                +{brand.primary_categories.length - 3}
              </Badge>
            )}
          </div>

          {/* Market Tier */}
          {brand.market_tier && (
            <Badge className={`text-xs glass-card ${tierColors[brand.market_tier] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>
              {brand.market_tier.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
            </Badge>
          )}

          {/* Website Indicator */}
          {brand.website && (
            <div className="flex items-center gap-2 pt-2 border-t border-white/30">
              <Globe className="w-3 h-3 text-gray-400" />
              <span className="text-xs text-gray-500">Website available</span>
            </div>
          )}

          {/* Hover Indicator */}
          <div className="text-xs text-gray-400 group-hover:text-green-600 transition-colors text-center pt-1">
            Click for details →
          </div>
        </div>
      </CardContent>
    </Card>
  );
}