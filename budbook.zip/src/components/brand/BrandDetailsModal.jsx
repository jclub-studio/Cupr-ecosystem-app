import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";
import { 
  Globe, 
  Star, 
  MapPin, 
  Calendar,
  ExternalLink,
  Heart,
  Loader2,
  Leaf,
  Instagram,
  Facebook,
  Twitter
} from 'lucide-react';
import { toast } from "sonner";

export default function BrandDetailsModal({ brand, isOpen, onClose, onUpdate }) {
  const [isFavoriting, setIsFavoriting] = useState(false);

  if (!brand) return null;

  const handleToggleFavorite = async () => {
    setIsFavoriting(true);
    try {
      await base44.entities.Brand.update(brand.id, {
        is_favorite: !brand.is_favorite
      });
      
      toast.success(brand.is_favorite ? "Removed from favorites" : "Added to favorites");
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error("Error toggling favorite:", error);
      toast.error("Failed to update favorite status");
    } finally {
      setIsFavoriting(false);
    }
  };

  const tierColors = {
    budget: "bg-gray-100/80 text-gray-800 border-gray-200/50",
    "mid-tier": "bg-blue-100/80 text-blue-800 border-blue-200/50",
    premium: "bg-purple-100/80 text-purple-800 border-purple-200/50",
    luxury: "bg-amber-100/80 text-amber-800 border-amber-200/50"
  };

  const getSocialIcon = (platform) => {
    switch(platform) {
      case 'instagram': return <Instagram className="w-4 h-4" />;
      case 'facebook': return <Facebook className="w-4 h-4" />;
      case 'twitter': return <Twitter className="w-4 h-4" />;
      default: return <Globe className="w-4 h-4" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-card border-white/40 max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between pr-6">
            <div>
              <DialogTitle className="text-2xl font-bold text-gray-900 mb-2">
                {brand.name}
              </DialogTitle>
              {brand.location?.state && (
                <p className="text-sm text-gray-600 flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  {[brand.location.state, brand.location.country].filter(Boolean).join(', ')}
                </p>
              )}
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleToggleFavorite}
              disabled={isFavoriting}
              className="hover:bg-yellow-50"
            >
              {isFavoriting ? (
                <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
              ) : (
                <Heart className={`w-5 h-5 ${brand.is_favorite ? 'fill-current text-red-500' : 'text-gray-400'}`} />
              )}
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-6 pt-4">
          {/* Description */}
          {brand.description && (
            <div>
              <p className="text-gray-700 leading-relaxed">{brand.description}</p>
            </div>
          )}

          {/* Categories and Tier */}
          <div className="space-y-3">
            <div>
              <h4 className="text-sm font-semibold text-gray-700 mb-2">Product Categories</h4>
              <div className="flex gap-2 flex-wrap">
                {brand.primary_categories?.map((category, idx) => (
                  <Badge key={idx} variant="outline" className="glass-card border-white/40">
                    {category}
                  </Badge>
                ))}
              </div>
            </div>

            {brand.market_tier && (
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-2">Market Tier</h4>
                <Badge className={`glass-card ${tierColors[brand.market_tier]}`}>
                  {brand.market_tier.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                </Badge>
              </div>
            )}
          </div>

          {/* Signature Strains */}
          {brand.signature_strains && brand.signature_strains.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                <Leaf className="w-4 h-4 text-green-600" />
                Signature Strains
              </h4>
              <div className="space-y-2">
                {brand.signature_strains.slice(0, 3).map((strain, idx) => (
                  <div key={idx} className="glass-card border-white/40 p-3 rounded-lg">
                    <p className="text-sm font-medium text-gray-900">{strain}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Website and Social Media */}
          <div className="space-y-3 pt-4 border-t border-white/30">
            {brand.website && (
              <a 
                href={brand.website} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-blue-600 hover:text-blue-700 hover:underline"
              >
                <Globe className="w-4 h-4" />
                <span className="text-sm">Visit Website</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}

            {brand.social_media_links && Object.keys(brand.social_media_links).length > 0 && (
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-2">Social Media</h4>
                <div className="flex gap-3">
                  {Object.entries(brand.social_media_links).map(([platform, url]) => (
                    url && (
                      <a
                        key={platform}
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 glass-card border-white/40 rounded-lg hover:bg-white/60 transition-colors"
                      >
                        {getSocialIcon(platform)}
                      </a>
                    )
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Founded Year */}
          {brand.founded_year && (
            <div className="flex items-center gap-2 text-sm text-gray-600 pt-2 border-t border-white/30">
              <Calendar className="w-4 h-4" />
              <span>Founded in {brand.founded_year}</span>
            </div>
          )}

          {/* Partner Brand Badge */}
          {brand.is_partner_brand && (
            <div className="glass-card bg-gradient-to-r from-purple-50/80 to-blue-50/80 border-purple-200/50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Star className="w-5 h-5 text-purple-600 fill-current" />
                <span className="font-semibold text-purple-900">Partner Brand</span>
              </div>
              <p className="text-sm text-purple-800">
                This is a verified partner brand with extended features and exclusive content.
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}