import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { Star, Clock, Eye, Music, Video, ExternalLink, Play, Users } from "lucide-react";

const MediaPreview = ({ mediaList }) => {
  if (!mediaList || mediaList.length === 0) return null;

  const getMediaIcon = (platform) => {
    switch (platform) {
      case 'youtube': return Video;
      case 'spotify': return Music;
      case 'apple_music': return Music;
      case 'netflix': return Play;
      case 'instagram': return Video;
      case 'tiktok': return Video;
      default: return ExternalLink;
    }
  };

  const handleMediaClick = (media) => {
    window.open(media.url, '_blank');
  };

  return (
    <div className="space-y-2">
      <h5 className="text-xs md:text-sm font-medium text-gray-700">Shared Media</h5>
      <div className="flex flex-wrap gap-1">
        {mediaList.slice(0, 3).map((media, index) => {
          const Icon = getMediaIcon(media.platform);
          return (
            <button
              key={index}
              onClick={() => handleMediaClick(media)}
              className="flex items-center gap-1 px-2 py-1 bg-purple-50/80 hover:bg-purple-100/80 rounded-lg text-xs text-purple-700 transition-all duration-200 glass-card border-purple-200/50"
            >
              <Icon className="w-3 h-3" />
              <span className="capitalize">{media.platform.replace('_', ' ')}</span>
            </button>
          );
        })}
        {mediaList.length > 3 && (
          <Badge variant="outline" className="text-xs glass-card border-white/40">
            +{mediaList.length - 3} more
          </Badge>
        )}
      </div>
    </div>
  );
};

export default function SessionCard({ session, product, onViewDetails }) {
  const typeColors = {
    indica: "bg-purple-100/80 text-purple-800 border-purple-200/50",
    sativa: "bg-orange-100/80 text-orange-800 border-orange-200/50",
    hybrid: "bg-blue-100/80 text-blue-800 border-blue-200/50",
  };
  
  const painRelief = session.pain_before - session.pain_after;
  const anxietyRelief = session.anxiety_before - session.anxiety_after;
  const moodImprovement = session.mood_after - session.mood_before;

  return (
    <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300 flex flex-col justify-between group">
      {session.session_image_url && (
        <div className="relative overflow-hidden rounded-t-xl">
          <img 
            src={session.session_image_url} 
            alt="Session capture" 
            className="w-full h-36 md:h-48 object-cover group-hover:scale-105 transition-transform duration-300" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
          <div className="absolute bottom-2 left-3 text-white">
            <h3 className="font-bold text-sm md:text-lg leading-tight">{product?.name || "Unknown Product"}</h3>
            <p className="text-xs md:text-sm opacity-90">{format(new Date(session.date), "MMM d, yyyy 'at' h:mm a")}</p>
          </div>
          <div className="absolute top-2 right-2 flex items-center gap-1 text-sm md:text-lg font-bold text-yellow-300 bg-black/40 px-2 py-1 rounded-full backdrop-blur-sm">
            <Star className="w-3 h-3 md:w-4 md:h-4 fill-current" />
            <span>{session.rating}</span>
          </div>
        </div>
      )}
      
      <CardHeader className={`${session.session_image_url ? 'pt-3' : ''} pb-3`}>
        {!session.session_image_url && (
          <div className="flex justify-between items-start">
            <div className="flex-1 min-w-0">
              <CardTitle className="text-base md:text-lg mb-1 truncate">{product?.name || "Unknown Product"}</CardTitle>
              <p className="text-xs md:text-sm text-gray-500">{format(new Date(session.date), "MMM d, yyyy 'at' h:mm a")}</p>
            </div>
            <div className="flex items-center gap-1 text-base md:text-lg font-bold text-yellow-500 bg-yellow-50/80 px-2 py-1 rounded-lg glass-card border-yellow-200/50 ml-2">
              <Star className="w-3 h-3 md:w-4 md:h-4 fill-current" />
              <span>{session.rating}</span>
            </div>
          </div>
        )}
      </CardHeader>

      <CardContent className="space-y-4 pt-0 flex-1">
        <div className="flex flex-wrap gap-2">
          {product && <Badge className={`text-xs md:text-sm glass-card ${typeColors[product.type] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>{product.type}</Badge>}
          <Badge variant="outline" className="text-xs md:text-sm glass-card border-white/40">{session.consumption_method}</Badge>
          {session.duration && (
            <Badge variant="secondary" className="flex items-center gap-1 text-xs glass-card border-white/40">
              <Clock className="w-3 h-3"/>
              {session.duration} min
            </Badge>
          )}
          {session.confirmed_friends && session.confirmed_friends.length > 0 && (
            <Badge variant="secondary" className="flex items-center gap-1 text-xs glass-card border-white/40">
              <Users className="w-3 h-3"/> 
              {session.confirmed_friends.length + 1}
            </Badge>
          )}
        </div>

        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="p-2 md:p-3 bg-blue-50/80 rounded-lg glass-card border-blue-200/50">
            <p className="text-xs text-gray-600 mb-1">Mood</p>
            <p className={`font-bold text-sm md:text-base ${moodImprovement > 0 ? 'text-green-600' : moodImprovement < 0 ? 'text-red-600' : 'text-gray-600'}`}>
              {moodImprovement > 0 ? `+${moodImprovement}` : moodImprovement}
            </p>
          </div>
          <div className="p-2 md:p-3 bg-green-50/80 rounded-lg glass-card border-green-200/50">
            <p className="text-xs text-gray-600 mb-1">Pain</p>
            <p className={`font-bold text-sm md:text-base ${painRelief > 0 ? 'text-green-600' : 'text-gray-600'}`}>
              {painRelief > 0 ? `-${painRelief}` : '0'}
            </p>
          </div>
          <div className="p-2 md:p-3 bg-purple-50/80 rounded-lg glass-card border-purple-200/50">
            <p className="text-xs text-gray-600 mb-1">Anxiety</p>
            <p className={`font-bold text-sm md:text-base ${anxietyRelief > 0 ? 'text-green-600' : 'text-gray-600'}`}>
              {anxietyRelief > 0 ? `-${anxietyRelief}` : '0'}
            </p>
          </div>
        </div>
        
        {session.effects_felt.length > 0 && (
          <div>
            <h4 className="text-xs md:text-sm font-medium mb-2 text-gray-700">Top Effects</h4>
            <div className="flex flex-wrap gap-1">
              {session.effects_felt.slice(0, 3).map(effect => (
                <Badge key={effect} variant="outline" className="text-xs glass-card border-white/40">{effect}</Badge>
              ))}
            </div>
          </div>
        )}

        {session.shared_media && session.shared_media.length > 0 && (
          <MediaPreview mediaList={session.shared_media} />
        )}
      </CardContent>

      <CardFooter className="pt-0">
        <Button onClick={onViewDetails} className="w-full" variant="outline" size="sm" className="glass-card border-white/40 hover:bg-white/60 min-h-[40px] font-medium">
          <Eye className="w-4 h-4 mr-2" />
          View Details
        </Button>
      </CardFooter>
    </Card>
  );
}