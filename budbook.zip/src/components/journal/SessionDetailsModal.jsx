
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { Star, Leaf, MapPin, Heart, Brain, Zap, Music, Video, ExternalLink, Play, Users, Mail, Package } from "lucide-react";

function DetailItem({ icon: Icon, label, value, className }) {
  return (
    <div className={`flex items-start gap-3 ${className}`}>
      <Icon className="w-4 h-4 md:w-5 md:h-5 text-green-600 mt-1 flex-shrink-0" />
      <div>
        <p className="text-xs md:text-sm text-gray-600">{label}</p>
        <p className="font-medium text-sm md:text-base">{value}</p>
      </div>
    </div>
  );
}

function WellnessTracker({ label, before, after, icon: Icon, color }) {
  const change = after - before;
  const changeColor = change > 0 ? 'text-green-600' : change < 0 ? 'text-red-600' : 'text-gray-500';

  return (
    <div className={`p-3 md:p-4 rounded-xl glass-card border-${color}-200/50 bg-${color}-50/80`}>
      <div className="flex items-center gap-2 mb-2">
        <Icon className={`w-4 h-4 md:w-5 md:h-5 text-${color}-600`} />
        <h4 className="font-semibold text-gray-800 text-sm md:text-base">{label}</h4>
      </div>
      <div className="flex justify-around items-center">
        <div className="text-center">
          <p className="text-xs text-gray-500">Before</p>
          <p className="text-xl md:text-2xl font-bold">{before}</p>
        </div>
        <div className={`text-lg md:text-xl font-bold ${changeColor}`}>
          {change > 0 ? `+${change}` : change}
        </div>
        <div className="text-center">
          <p className="text-xs text-gray-500">After</p>
          <p className="text-xl md:text-2xl font-bold">{after}</p>
        </div>
      </div>
    </div>
  )
}

const MediaSection = ({ mediaList }) => {
  if (!mediaList || mediaList.length === 0) return null;

  const getMediaIcon = (platform) => {
    switch (platform) {
      case 'youtube': return Video;
      case 'spotify': return Music;
      case 'apple_music': return Music;
      case 'netflix': return Play;
      case 'instagram': return Video;
      case 'tiktok': return Video;
      default: return ExternalLink;
    }
  };

  const getPlatformName = (platform) => {
    return platform === 'apple_music' ? 'Apple Music' : 
           platform.charAt(0).toUpperCase() + platform.slice(1);
  };

  const handleMediaClick = (media) => {
    window.open(media.url, '_blank');
  };

  return (
    <div>
      <h4 className="font-semibold mb-3 text-sm md:text-base">Shared Media ({mediaList.length})</h4>
      <div className="grid gap-2 md:gap-3">
        {mediaList.map((media, index) => {
          const Icon = getMediaIcon(media.platform);
          return (
            <div key={index} className="flex items-center gap-3 p-3 glass-card border-white/40 rounded-lg hover:bg-white/60 transition-all duration-200">
              <Icon className="w-4 h-4 md:w-5 md:h-5 text-purple-600 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm md:text-base">{getPlatformName(media.platform)}</p>
                {media.title && <p className="text-xs text-gray-600 truncate">{media.title}</p>}
                <p className="text-xs text-gray-500 truncate">{media.url}</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleMediaClick(media)}
                className="flex-shrink-0 glass-card border-white/40 hover:bg-white/80 min-h-[32px]"
              >
                <ExternalLink className="w-3 h-3 md:w-4 md:h-4 mr-1" />
                <span className="hidden md:inline">Open</span>
              </Button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const ParticipantsSection = ({ session }) => {
  if (!session.confirmed_friends || session.confirmed_friends.length === 0) return null;

  return (
    <div>
      <h4 className="font-semibold mb-3 flex items-center gap-2 text-sm md:text-base">
        <Users className="w-4 h-4" />
        Session Participants ({session.confirmed_friends.length + 1})
      </h4>
      <div className="grid gap-2">
        <div className="flex items-center gap-2 p-2 md:p-3 bg-green-50/80 rounded-lg glass-card border-green-200/50">
          <Mail className="w-3 h-3 md:w-4 md:h-4 text-green-600" />
          <span className="text-sm md:text-base font-medium">{session.created_by} (Host)</span>
        </div>
        {session.confirmed_friends.map((email, index) => (
          <div key={index} className="flex items-center gap-2 p-2 md:p-3 bg-blue-50/80 rounded-lg glass-card border-blue-200/50">
            <Users className="w-3 h-3 md:w-4 md:h-4 text-blue-600" />
            <span className="text-sm md:text-base">{email}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default function SessionDetailsModal({ session, product, onOpenChange }) {
  const [accessories, setAccessories] = React.useState([]);
  const [loadingAccessories, setLoadingAccessories] = React.useState(false);

  React.useEffect(() => {
    if (session?.accessories_used && session.accessories_used.length > 0) {
      loadAccessories();
    }
  }, [session]);

  const loadAccessories = async () => {
    if (!session?.accessories_used || session.accessories_used.length === 0) return;
    
    setLoadingAccessories(true);
    try {
      const { Accessory } = await import('@/entities/all');
      const accessoryPromises = session.accessories_used.map(id => 
        Accessory.get(id).catch(() => null)
      );
      const fetchedAccessories = await Promise.all(accessoryPromises);
      setAccessories(fetchedAccessories.filter(Boolean));
    } catch (error) {
      console.error('Error loading accessories:', error);
    } finally {
      setLoadingAccessories(false);
    }
  };

  if (!session) return null;

  const CATEGORY_ICONS = {
    grinder: "⚙️",
    pipe: "🌿",
    bong: "💧",
    bubbler: "💨",
    rolling_papers: "📄",
    rolling_machine: "🎰",
    vaporizer_dry_herb: "💨",
    vaporizer_oil: "🔋",
    dab_rig: "🔥",
    torch: "🔥",
    lighter: "🔥",
    lighter_sleeve: "🎨",
    ashtray: "🗑️",
    storage_container: "📦",
    smell_proof_bag: "💼",
    travel_case: "🧳",
    cleaning_supplies: "🧼",
    odor_eliminator: "🌬️",
    extraction_machine: "⚗️",
    scales: "⚖️",
    room_decor: "🖼️",
    lighting: "💡",
    lava_lamp: "🌋",
    posters: "🖼️",
    furniture: "🪑",
    clothing: "👕",
    other: "✨"
  };

  const formatCategoryName = (category) => {
    return category.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  return (
    <Dialog open={true} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl glass-card border-white/40 max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="pb-4">
          <DialogTitle className="text-xl md:text-2xl font-bold text-gray-900">
            {product?.name || "Session Details"}
          </DialogTitle>
          <p className="text-gray-600 text-sm md:text-base">{format(new Date(session.date), "EEEE, MMMM d, yyyy 'at' h:mm a")}</p>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto p-1 pr-4 space-y-4 md:space-y-6">
          {session.session_image_url && (
            <div className="rounded-xl overflow-hidden shadow-lg">
              <img src={session.session_image_url} alt="Session capture" className="w-full object-cover max-h-64 md:max-h-80"/>
            </div>
          )}

          {/* Rating and Basic Info */}
          <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
            <div className="flex items-center gap-1">
              {[1,2,3,4,5].map(star => (
                <Star
                  key={star}
                  className={`w-5 h-5 md:w-6 md:h-6 transition-colors ${
                    star <= session.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                  }`}
                />
              ))}
            </div>
            <Badge variant="secondary" className="text-sm md:text-base glass-card border-white/40 px-3 py-1">
              {session.consumption_method}
            </Badge>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <DetailItem icon={Leaf} label="Amount" value={`${session.amount_consumed || 'N/A'} ${session.amount_unit}`} />
            <DetailItem icon={MapPin} label="Context" value={session.context || 'Not specified'} />
          </div>

          {/* Participants */}
          <ParticipantsSection session={session} />

          {/* Accessories Used */}
          {accessories.length > 0 && (
            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2 text-sm md:text-base">
                <Package className="w-4 h-4" />
                Accessories Used ({accessories.length})
              </h4>
              <div className="grid gap-2">
                {accessories.map((accessory) => (
                  <div key={accessory.id} className="flex items-center gap-3 p-3 glass-card border-white/40 rounded-lg bg-purple-50/80 border-purple-200/50">
                    <span className="text-2xl flex-shrink-0">{CATEGORY_ICONS[accessory.category]}</span>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm md:text-base truncate">{accessory.name}</p>
                      <p className="text-xs text-gray-600">
                        {formatCategoryName(accessory.category)}
                        {accessory.brand && ` • ${accessory.brand}`}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Wellness Trackers */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-4">
             <WellnessTracker label="Mood" before={session.mood_before} after={session.mood_after} icon={Heart} color="blue"/>
             <WellnessTracker label="Pain" before={session.pain_before} after={session.pain_after} icon={Zap} color="green"/>
             <WellnessTracker label="Anxiety" before={session.anxiety_before} after={session.anxiety_after} icon={Brain} color="purple"/>
          </div>

          {/* Effects and Activities */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            <div>
              <h4 className="font-semibold mb-3 text-sm md:text-base">Effects Experienced</h4>
              <div className="flex flex-wrap gap-1 md:gap-2">
                {session.effects_felt.length > 0 ? (
                  session.effects_felt.map(effect => (
                    <Badge key={effect} className="glass-card border-green-200/50 bg-green-50/80 text-green-800 text-xs md:text-sm">
                      {effect}
                    </Badge>
                  ))
                ) : (
                  <p className="text-sm text-gray-500">No effects recorded.</p>
                )}
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-3 text-sm md:text-base">Activities</h4>
              <div className="flex flex-wrap gap-1 md:gap-2">
                {session.activities.length > 0 ? (
                  session.activities.map(activity => (
                    <Badge key={activity} variant="outline" className="glass-card border-white/40 text-xs md:text-sm">
                      {activity}
                    </Badge>
                  ))
                ) : (
                  <p className="text-sm text-gray-500">No activities recorded.</p>
                )}
              </div>
            </div>
          </div>

          {/* Shared Media */}
          {session.shared_media && session.shared_media.length > 0 && (
            <MediaSection mediaList={session.shared_media} />
          )}
          
          {/* Notes */}
          {session.notes && (
            <div>
              <h4 className="font-semibold mb-3 text-sm md:text-base">Notes & Observations</h4>
              <div className="p-4 glass-card border-white/40 rounded-lg bg-gray-50/80">
                <p className="text-gray-700 whitespace-pre-wrap text-sm md:text-base leading-relaxed">
                  {session.notes}
                </p>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
