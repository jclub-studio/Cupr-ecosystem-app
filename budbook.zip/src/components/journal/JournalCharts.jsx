import React from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell, BarChart, Bar } from 'recharts';
import { format } from 'date-fns';
import { countBy, chain } from 'lodash';

const COLORS = ['#16a34a', '#22c55e', '#84cc16', '#4ade80', '#a3e635'];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="p-4 bg-white/90 backdrop-blur-sm border rounded-lg shadow-lg">
        <p className="label font-semibold">{`${format(new Date(label), 'MMM d, yyyy')}`}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color }}>
            {`${p.name}: ${p.value.toFixed(1)}`}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function JournalCharts({ sessions, products }) {
  // Wellness Trend Data
  const wellnessData = sessions
    .map(s => ({
      date: s.date,
      Mood: s.mood_after,
      'Pain Relief': s.pain_before - s.pain_after,
      'Anxiety Relief': s.anxiety_before - s.anxiety_after,
    }))
    .sort((a, b) => new Date(a.date) - new Date(b.date));

  // Consumption Method Data
  const methodCounts = countBy(sessions, 'consumption_method');
  const methodData = Object.keys(methodCounts).map(key => ({
    name: key.charAt(0).toUpperCase() + key.slice(1),
    value: methodCounts[key],
  }));
  
  // Top Products Data
  const productCounts = countBy(sessions, 'product_id');
  const topProductsData = chain(productCounts)
    .map((count, productId) => ({
      name: products.find(p => p.id === productId)?.name || 'Unknown',
      count: count,
    }))
    .orderBy('count', 'desc')
    .take(5)
    .value();


  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Wellness Trend */}
      <div className="lg:col-span-2 h-80">
        <h4 className="font-semibold text-center mb-4">Wellness Over Time</h4>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={wellnessData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" tickFormatter={(date) => format(new Date(date), 'MMM d')} />
            <YAxis />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Line type="monotone" dataKey="Mood" stroke="#8884d8" />
            <Line type="monotone" dataKey="Pain Relief" stroke="#82ca9d" />
            <Line type="monotone" dataKey="Anxiety Relief" stroke="#ffc658" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Consumption Methods */}
      <div className="h-80">
        <h4 className="font-semibold text-center mb-4">Consumption Methods</h4>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={methodData}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
              nameKey="name"
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
            >
              {methodData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </div>
      
       {/* Top Products Chart */}
       <div className="lg:col-span-3 h-80 mt-8">
        <h4 className="font-semibold text-center mb-4">Most Logged Products</h4>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={topProductsData} layout="vertical" margin={{ left: 100 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis type="number" />
            <YAxis type="category" dataKey="name" width={100} tick={{ fontSize: 12 }} />
            <Tooltip />
            <Bar dataKey="count" fill="#16a34a" name="Sessions" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}