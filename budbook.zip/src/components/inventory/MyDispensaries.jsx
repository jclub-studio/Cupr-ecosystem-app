import React, { useState, useEffect } from 'react';
import { Dispensary } from '@/entities/Dispensary';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Store, MapPin, Plus, Heart, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function MyDispensaries() {
  const [dispensaries, setDispensaries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDispensaries();
  }, []);

  const loadDispensaries = async () => {
    try {
      const data = await Dispensary.list('-created_date', 6);
      setDispensaries(data);
    } catch (error) {
      console.error('Error loading dispensaries:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleFavorite = async (dispensary) => {
    try {
      const updated = { ...dispensary, is_favorite: !dispensary.is_favorite };
      await Dispensary.update(dispensary.id, { is_favorite: updated.is_favorite });
      setDispensaries(prev => prev.map(d => d.id === dispensary.id ? updated : d));
    } catch (error) {
      console.error('Error updating favorite:', error);
    }
  };

  if (loading) {
    return (
      <Card className="glass-card border-white/40">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Store className="w-5 h-5 text-blue-600" />
            My Shops
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            {[1,2,3].map(i => (
              <div key={i} className="h-16 bg-gray-200/80 rounded-lg"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
      <CardHeader className="border-b border-white/20">
        <CardTitle className="flex items-center gap-3 text-lg md:text-xl font-semibold text-gray-800">
          <div className="p-2 bg-blue-100/80 rounded-lg">
            <Store className="w-5 h-5 text-blue-600" />
          </div>
          My Shops
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        {dispensaries.length > 0 ? (
          <div className="space-y-4">
            {dispensaries.map((dispensary) => (
              <div 
                key={dispensary.id} 
                className="flex items-center gap-4 p-4 rounded-xl bg-white/60 hover:bg-white/80 transition-all duration-200 border border-white/40 group"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform flex-shrink-0 shadow-lg">
                  <Store className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-gray-900 truncate text-sm md:text-base">{dispensary.name}</h4>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge 
                      className={`text-xs glass-card ${
                        dispensary.shop_type === 'dispensary' 
                          ? 'bg-green-100/80 text-green-800 border-green-200/50'
                          : 'bg-blue-100/80 text-blue-800 border-blue-200/50'
                      }`}
                    >
                      {dispensary.shop_type === 'dispensary' ? 'Dispensary' : 'Shop'}
                    </Badge>
                    {dispensary.is_favorite && (
                      <Heart className="w-3 h-3 text-red-500 fill-current" />
                    )}
                  </div>
                  {dispensary.address && (
                    <div className="flex items-center gap-1 text-xs text-gray-600 mt-1">
                      <MapPin className="w-3 h-3" />
                      <span className="truncate">{dispensary.address.split(',')[0]}</span>
                    </div>
                  )}
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleFavorite(dispensary)}
                    className={`transition-all min-h-[32px] min-w-[32px] ${
                      dispensary.is_favorite ? 'text-red-500 hover:text-red-600' : 'text-gray-400 hover:text-red-500'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${dispensary.is_favorite ? 'fill-current' : ''}`} />
                  </Button>
                  {dispensary.google_maps_url && (
                    <Button
                      variant="ghost"
                      size="sm"
                      asChild
                      className="text-gray-400 hover:text-blue-600 min-h-[32px] min-w-[32px]"
                    >
                      <a href={dispensary.google_maps_url} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </Button>
                  )}
                </div>
              </div>
            ))}
            
            <div className="pt-4 border-t border-white/30">
              <Link to={createPageUrl("Shops")}>
                <Button variant="outline" className="w-full glass-card border-white/40 hover:bg-white/60 min-h-[44px]">
                  View All Shops ({dispensaries.length})
                </Button>
              </Link>
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="w-12 h-12 bg-gray-100/80 rounded-full flex items-center justify-center mx-auto mb-4">
              <Store className="w-6 h-6 text-gray-400" />
            </div>
            <h3 className="text-base font-semibold text-gray-900 mb-2">No shops saved yet</h3>
            <p className="text-sm text-gray-600 mb-4">Discover and save your favorite dispensaries</p>
            <Link to={createPageUrl("FindDispensary")}>
              <Button className="bg-blue-600/90 hover:bg-blue-700/90 min-h-[44px] px-6 font-medium">
                <Plus className="w-4 h-4 mr-2" />
                Find Dispensaries
              </Button>
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
}