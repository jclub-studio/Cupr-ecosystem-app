import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Leaf, Droplet, Package } from 'lucide-react';

export default function ProductBriefCard({ product, inventoryItem, onClick, onBrandClick }) {
  const typeColors = {
    indica: "bg-purple-100/80 text-purple-800 border-purple-200/50",
    sativa: "bg-green-100/80 text-green-800 border-green-200/50",
    hybrid: "bg-blue-100/80 text-blue-800 border-blue-200/50",
  };

  const categoryColors = {
    flower: "bg-green-100/80 text-green-800 border-green-200/50",
    concentrate: "bg-amber-100/80 text-amber-800 border-amber-200/50",
    edible: "bg-red-100/80 text-red-800 border-red-200/50",
    vape: "bg-blue-100/80 text-blue-800 border-blue-200/50",
    tincture: "bg-purple-100/80 text-purple-800 border-purple-200/50",
    topical: "bg-pink-100/80 text-pink-800 border-pink-200/50",
    preroll: "bg-green-100/80 text-green-800 border-green-200/50",
    blunt: "bg-orange-100/80 text-orange-800 border-orange-200/50",
    cartridge: "bg-indigo-100/80 text-indigo-800 border-indigo-200/50",
    oil: "bg-yellow-100/80 text-yellow-800 border-yellow-200/50",
    capsule: "bg-teal-100/80 text-teal-800 border-teal-200/50",
    drink: "bg-cyan-100/80 text-cyan-800 border-cyan-200/50",
    other: "bg-gray-100/80 text-gray-800 border-gray-200/50"
  };

  const handleBrandClick = (e) => {
    e.stopPropagation();
    if (onBrandClick) {
      onBrandClick(product);
    }
  };

  return (
    <Card 
      onClick={onClick}
      className="glass-card border-white/40 hover:shadow-xl hover:scale-105 transition-all duration-300 cursor-pointer group"
    >
      <CardContent className="p-4">
        <div className="space-y-3">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <h3 className="text-base md:text-lg font-bold text-gray-900 mb-1 group-hover:text-green-600 transition-colors truncate">
                {product.name}
              </h3>
              {product.brand && (
                <button
                  onClick={handleBrandClick}
                  className="text-xs text-gray-500 truncate hover:text-green-600 hover:underline transition-colors text-left"
                >
                  {product.brand}
                </button>
              )}
            </div>
            <div className="p-2 bg-green-100/80 rounded-lg flex-shrink-0">
              <Leaf className="w-4 h-4 text-green-600" />
            </div>
          </div>

          {/* Type & Category Badges */}
          <div className="flex gap-2 flex-wrap">
            <Badge className={`text-xs glass-card ${typeColors[product.type] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>
              {product.type}
            </Badge>
            <Badge className={`text-xs glass-card ${categoryColors[product.category] || 'bg-gray-100/80 text-gray-800 border-gray-200/50'}`}>
              {product.category}
            </Badge>
          </div>

          {/* Quantity Display */}
          <div className="flex items-center justify-between p-2 bg-gray-50/80 rounded-lg glass-card border-white/40">
            <div className="flex items-center gap-2">
              <Package className="w-3 h-3 text-gray-500" />
              <span className="text-xs text-gray-600">Quantity</span>
            </div>
            <span className="text-sm font-bold text-green-600">
              {inventoryItem.quantity} {inventoryItem.unit}
            </span>
          </div>

          {/* Cannabinoid Quick View */}
          {(product.thc_percentage > 0 || product.cbd_percentage > 0) && (
            <div className="flex items-center gap-3 pt-2 border-t border-white/30">
              <Droplet className="w-3 h-3 text-gray-400 flex-shrink-0" />
              <div className="flex gap-3 text-xs">
                {product.thc_percentage > 0 && (
                  <span className="font-semibold text-red-600">THC {product.thc_percentage}%</span>
                )}
                {product.cbd_percentage > 0 && (
                  <span className="font-semibold text-green-600">CBD {product.cbd_percentage}%</span>
                )}
              </div>
            </div>
          )}

          {/* Hover Indicator */}
          <div className="text-xs text-gray-400 group-hover:text-green-600 transition-colors text-center pt-1">
            Click for details →
          </div>
        </div>
      </CardContent>
    </Card>
  );
}