import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { 
  Leaf, 
  Calendar, 
  DollarSign, 
  Store, 
  Package,
  Droplet,
  Sparkles,
  Archive,
  AlertCircle
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

function DetailItem({ icon: Icon, label, value, className }) {
  return (
    <div className={`flex items-start gap-3 ${className}`}>
      <Icon className="w-4 h-4 md:w-5 md:h-5 text-green-600 mt-1 flex-shrink-0" />
      <div>
        <p className="text-xs md:text-sm text-gray-600">{label}</p>
        <p className="font-medium text-sm md:text-base">{value}</p>
      </div>
    </div>
  );
}

export default function ProductDetailsModal({ inventoryItem, product, dispensary, onOpenChange }) {
  if (!inventoryItem || !product) return null;

  const typeColors = {
    indica: "bg-purple-100 text-purple-800 border-purple-200",
    sativa: "bg-green-100 text-green-800 border-green-200",
    hybrid: "bg-blue-100 text-blue-800 border-blue-200"
  };

  const categoryColors = {
    flower: "bg-green-100 text-green-800",
    concentrate: "bg-amber-100 text-amber-800",
    edible: "bg-red-100 text-red-800",
    vape: "bg-blue-100 text-blue-800",
    tincture: "bg-purple-100 text-purple-800",
    topical: "bg-pink-100 text-pink-800",
    preroll: "bg-green-100 text-green-800",
    blunt: "bg-orange-100 text-orange-800",
    cartridge: "bg-indigo-100 text-indigo-800",
    oil: "bg-yellow-100 text-yellow-800",
    capsule: "bg-teal-100 text-teal-800",
    drink: "bg-cyan-100 text-cyan-800",
    other: "bg-gray-100 text-gray-800"
  };

  return (
    <Dialog open={true} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl glass-card border-white/40 max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="pb-4">
          <DialogTitle className="text-xl md:text-2xl font-bold text-gray-900">
            {product.name}
          </DialogTitle>
          {product.brand && (
            <p className="text-gray-600 text-sm md:text-base">{product.brand}</p>
          )}
        </DialogHeader>

        <div className="flex-1 overflow-y-auto p-1 pr-4 space-y-4 md:space-y-6">
          {/* Type and Category Badges */}
          <div className="flex gap-2 flex-wrap">
            <Badge className={`${typeColors[product.type] || "bg-gray-100 text-gray-800"} text-sm font-medium`}>
              {product.type}
            </Badge>
            <Badge className={`${categoryColors[product.category] || "bg-gray-100 text-gray-800"} text-sm font-medium`}>
              {product.category}
            </Badge>
            {product.strain_name && product.strain_name !== product.name && (
              <Badge variant="outline" className="text-sm glass-card border-white/40">
                {product.strain_name}
              </Badge>
            )}
          </div>

          {/* Inventory Info */}
          <div className="p-4 bg-green-50/80 rounded-xl glass-card border-green-200/50">
            <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <Package className="w-4 h-4 text-green-600" />
              Inventory Details
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-gray-600">Quantity</p>
                <p className="text-lg font-bold text-green-600">
                  {inventoryItem.quantity} {inventoryItem.unit}
                </p>
              </div>
              {product.amount && (
                <div>
                  <p className="text-xs text-gray-600">Original Amount</p>
                  <p className="text-sm font-medium text-gray-900">{product.amount}</p>
                </div>
              )}
            </div>
          </div>

          {/* Cannabinoid Profile */}
          {(product.thc_percentage > 0 || product.cbd_percentage > 0 || product.thca_percentage > 0 || product.cbda_percentage > 0 || product.cbg_percentage > 0 || product.cbn_percentage > 0) && (
            <div>
              <h4 className="font-semibold mb-3 text-sm md:text-base flex items-center gap-2">
                <Droplet className="w-4 h-4 text-blue-600" />
                Cannabinoid Profile
              </h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {product.thc_percentage > 0 && (
                  <div className="text-center p-3 bg-red-50/80 rounded-lg glass-card border-red-200/50">
                    <p className="text-xs text-gray-600">THC</p>
                    <p className="font-bold text-red-600 text-base md:text-lg">{product.thc_percentage}%</p>
                  </div>
                )}
                {product.thca_percentage > 0 && (
                  <div className="text-center p-3 bg-orange-50/80 rounded-lg glass-card border-orange-200/50">
                    <p className="text-xs text-gray-600">THCa</p>
                    <p className="font-bold text-orange-600 text-base md:text-lg">{product.thca_percentage}%</p>
                  </div>
                )}
                {product.cbd_percentage > 0 && (
                  <div className="text-center p-3 bg-green-50/80 rounded-lg glass-card border-green-200/50">
                    <p className="text-xs text-gray-600">CBD</p>
                    <p className="font-bold text-green-600 text-base md:text-lg">{product.cbd_percentage}%</p>
                  </div>
                )}
                {product.cbda_percentage > 0 && (
                  <div className="text-center p-3 bg-teal-50/80 rounded-lg glass-card border-teal-200/50">
                    <p className="text-xs text-gray-600">CBDa</p>
                    <p className="font-bold text-teal-600 text-base md:text-lg">{product.cbda_percentage}%</p>
                  </div>
                )}
                {product.cbg_percentage > 0 && (
                  <div className="text-center p-3 bg-yellow-50/80 rounded-lg glass-card border-yellow-200/50">
                    <p className="text-xs text-gray-600">CBG</p>
                    <p className="font-bold text-yellow-600 text-base md:text-lg">{product.cbg_percentage}%</p>
                  </div>
                )}
                {product.cbn_percentage > 0 && (
                  <div className="text-center p-3 bg-purple-50/80 rounded-lg glass-card border-purple-200/50">
                    <p className="text-xs text-gray-600">CBN</p>
                    <p className="font-bold text-purple-600 text-base md:text-lg">{product.cbn_percentage}%</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Terpene Profile */}
          {product.terpene_profile && product.terpene_profile.length > 0 && (
            <div>
              <h4 className="font-semibold mb-3 text-sm md:text-base flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-600" />
                Terpene Profile ({product.terpene_profile.length})
              </h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {product.terpene_profile.map((terpene, index) => (
                  <div key={index} className="glass-card border-purple-200/50 p-2 rounded-lg bg-purple-50/80">
                    <p className="font-medium text-xs md:text-sm">{terpene.terpene_name}</p>
                    {terpene.percentage > 0 && (
                      <p className="text-purple-600 font-semibold text-xs">{terpene.percentage}%</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Purchase & Dates Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {inventoryItem.purchase_date && (
              <DetailItem 
                icon={Calendar} 
                label="Added to Stash" 
                value={format(new Date(inventoryItem.purchase_date), "MMM d, yyyy")} 
              />
            )}
            {inventoryItem.purchase_price > 0 && (
              <DetailItem 
                icon={DollarSign} 
                label="Purchase Price" 
                value={`$${inventoryItem.purchase_price.toFixed(2)}`} 
              />
            )}
            {product.packed_date && (
              <DetailItem 
                icon={Archive} 
                label="Packed Date" 
                value={format(new Date(product.packed_date), "MMM d, yyyy")} 
              />
            )}
            {product.expiration_date && (
              <DetailItem 
                icon={AlertCircle} 
                label="Expiration Date" 
                value={format(new Date(product.expiration_date), "MMM d, yyyy")} 
              />
            )}
          </div>

          {/* Dispensary Info */}
          {dispensary && (
            <div className="p-4 bg-blue-50/80 rounded-xl glass-card border-blue-200/50">
              <h4 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                <Store className="w-4 h-4 text-blue-600" />
                Purchased From
              </h4>
              <p className="text-sm font-medium text-gray-900">{dispensary.name}</p>
              {dispensary.city && dispensary.state && (
                <p className="text-xs text-gray-600 mt-1">
                  {dispensary.city}, {dispensary.state}
                </p>
              )}
            </div>
          )}

          {/* Notes */}
          {(inventoryItem.notes || product.notes) && (
            <div>
              <h4 className="font-semibold mb-3 text-sm md:text-base">Notes</h4>
              <div className="p-4 glass-card border-white/40 rounded-lg bg-gray-50/80">
                <p className="text-gray-700 whitespace-pre-wrap text-sm md:text-base leading-relaxed">
                  {inventoryItem.notes || product.notes}
                </p>
              </div>
            </div>
          )}

          {/* Action Button */}
          <Link to={createPageUrl("NewSession") + `?product=${product.id}`}>
            <Button className="w-full bg-green-600/90 hover:bg-green-700/90 shadow-lg min-h-[44px]">
              <Leaf className="w-4 h-4 mr-2" />
              Log Session with this Product
            </Button>
          </Link>
        </div>
      </DialogContent>
    </Dialog>
  );
}