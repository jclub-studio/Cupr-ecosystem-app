import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { 
  Plus, 
  Search, 
  Star, 
  Package, 
  Edit, 
  Trash2,
  Sparkles
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

const CATEGORY_ICONS = {
  grinder: "⚙️",
  pipe: "🌿",
  bong: "💧",
  bubbler: "💨",
  rolling_papers: "📄",
  rolling_machine: "🎰",
  vaporizer_dry_herb: "💨",
  vaporizer_oil: "🔋",
  dab_rig: "🔥",
  torch: "🔥",
  lighter: "🔥",
  lighter_sleeve: "🎨",
  ashtray: "🗑️",
  storage_container: "📦",
  smell_proof_bag: "💼",
  travel_case: "🧳",
  cleaning_supplies: "🧼",
  odor_eliminator: "🌬️",
  extraction_machine: "⚗️",
  scales: "⚖️",
  room_decor: "🖼️",
  lighting: "💡",
  lava_lamp: "🌋",
  posters: "🖼️",
  furniture: "🪑",
  clothing: "👕",
  other: "✨"
};

const CATEGORY_COLORS = {
  grinder: "bg-gray-100 text-gray-800",
  pipe: "bg-green-100 text-green-800",
  bong: "bg-blue-100 text-blue-800",
  bubbler: "bg-cyan-100 text-cyan-800",
  rolling_papers: "bg-amber-100 text-amber-800",
  rolling_machine: "bg-orange-100 text-orange-800",
  vaporizer_dry_herb: "bg-purple-100 text-purple-800",
  vaporizer_oil: "bg-indigo-100 text-indigo-800",
  dab_rig: "bg-red-100 text-red-800",
  torch: "bg-red-100 text-red-800",
  lighter: "bg-yellow-100 text-yellow-800",
  lighter_sleeve: "bg-pink-100 text-pink-800",
  ashtray: "bg-slate-100 text-slate-800",
  storage_container: "bg-teal-100 text-teal-800",
  smell_proof_bag: "bg-emerald-100 text-emerald-800",
  travel_case: "bg-sky-100 text-sky-800",
  cleaning_supplies: "bg-blue-100 text-blue-800",
  odor_eliminator: "bg-mint-100 text-mint-800",
  extraction_machine: "bg-violet-100 text-violet-800",
  scales: "bg-stone-100 text-stone-800",
  room_decor: "bg-rose-100 text-rose-800",
  lighting: "bg-yellow-100 text-yellow-800",
  lava_lamp: "bg-fuchsia-100 text-fuchsia-800",
  posters: "bg-lime-100 text-lime-800",
  furniture: "bg-brown-100 text-brown-800",
  clothing: "bg-purple-100 text-purple-800",
  other: "bg-gray-100 text-gray-800"
};

const formatCategoryName = (category) => {
  return category.split('_').map(word => 
    word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');
};

export default function AccessoriesTab() {
  const [accessories, setAccessories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterFavorites, setFilterFavorites] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingAccessory, setEditingAccessory] = useState(null);
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  
  const [formData, setFormData] = useState({
    name: "",
    category: "",
    brand: "",
    purchase_date: "",
    purchase_price: "",
    purchase_location: "",
    condition: "good",
    notes: "",
    is_favorite: false,
    image_url: ""
  });

  useEffect(() => {
    loadAccessories();
  }, []);

  const loadAccessories = async () => {
    try {
      const data = await base44.entities.Accessory.list("-created_date");
      setAccessories(data);
    } catch (error) {
      console.error("Error loading accessories:", error);
      toast.error("Failed to load accessories");
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      category: "",
      brand: "",
      purchase_date: "",
      purchase_price: "",
      purchase_location: "",
      condition: "good",
      notes: "",
      is_favorite: false,
      image_url: ""
    });
    setImageFile(null);
    setImagePreview(null);
    setEditingAccessory(null);
  };

  const handleSubmit = async () => {
    if (!formData.name || !formData.category) {
      toast.error("Please fill in name and category");
      return;
    }

    try {
      let imageUrl = formData.image_url;
      
      if (imageFile) {
        const { file_url } = await base44.integrations.Core.UploadFile({ 
          file: imageFile 
        });
        imageUrl = file_url;
      }

      const accessoryData = {
        ...formData,
        image_url: imageUrl,
        purchase_price: formData.purchase_price ? Number(formData.purchase_price) : null
      };

      if (editingAccessory) {
        await base44.entities.Accessory.update(editingAccessory.id, accessoryData);
        toast.success("Accessory updated successfully");
      } else {
        await base44.entities.Accessory.create(accessoryData);
        toast.success("Accessory added successfully");
      }

      setShowAddDialog(false);
      resetForm();
      loadAccessories();
    } catch (error) {
      console.error("Error saving accessory:", error);
      toast.error("Failed to save accessory");
    }
  };

  const handleEdit = (accessory) => {
    setEditingAccessory(accessory);
    setFormData({
      name: accessory.name,
      category: accessory.category,
      brand: accessory.brand || "",
      purchase_date: accessory.purchase_date || "",
      purchase_price: accessory.purchase_price || "",
      purchase_location: accessory.purchase_location || "",
      condition: accessory.condition || "good",
      notes: accessory.notes || "",
      is_favorite: accessory.is_favorite || false,
      image_url: accessory.image_url || ""
    });
    setImagePreview(accessory.image_url || null);
    setShowAddDialog(true);
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this accessory?")) return;
    
    try {
      await base44.entities.Accessory.delete(id);
      toast.success("Accessory deleted");
      loadAccessories();
    } catch (error) {
      console.error("Error deleting accessory:", error);
      toast.error("Failed to delete accessory");
    }
  };

  const toggleFavorite = async (accessory) => {
    try {
      await base44.entities.Accessory.update(accessory.id, {
        is_favorite: !accessory.is_favorite
      });
      loadAccessories();
    } catch (error) {
      console.error("Error updating favorite:", error);
      toast.error("Failed to update favorite");
    }
  };

  const filteredAccessories = accessories.filter(acc => {
    const matchesSearch = acc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         acc.brand?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === "all" || acc.category === filterCategory;
    const matchesFavorites = !filterFavorites || acc.is_favorite;
    
    return matchesSearch && matchesCategory && matchesFavorites;
  });

  const categories = [...new Set(accessories.map(a => a.category))].sort();

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header and Filters */}
      <Card className="bg-white/80 backdrop-blur-sm">
        <CardContent className="p-4 md:p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg md:text-xl font-bold text-gray-900">Accessories</h2>
            <Button 
              onClick={() => {
                resetForm();
                setShowAddDialog(true);
              }}
              className="bg-green-600 hover:bg-green-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Accessory
            </Button>
          </div>

          <div className="flex flex-col md:flex-row gap-3 md:gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search accessories..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 text-sm md:text-base"
              />
            </div>
            
            <div className="flex gap-2 md:gap-3">
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-36 md:w-40">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map(cat => (
                    <SelectItem key={cat} value={cat}>
                      {CATEGORY_ICONS[cat]} {formatCategoryName(cat)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button
                variant={filterFavorites ? "default" : "outline"}
                onClick={() => setFilterFavorites(!filterFavorites)}
                className="min-w-[100px]"
              >
                <Star className={`w-4 h-4 mr-2 ${filterFavorites ? 'fill-current' : ''}`} />
                Favorites
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Accessories Grid */}
      {filteredAccessories.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {filteredAccessories.map((accessory) => (
            <Card key={accessory.id} className="bg-white/90 backdrop-blur-sm hover:shadow-lg transition-all duration-300">
              <CardHeader className="pb-4">
                <div className="flex justify-between items-start">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-base md:text-lg mb-2 truncate flex items-center gap-2">
                      <span>{CATEGORY_ICONS[accessory.category]}</span>
                      {accessory.name}
                    </CardTitle>
                    {accessory.brand && (
                      <p className="text-xs md:text-sm text-gray-600 mb-3">{accessory.brand}</p>
                    )}
                    <Badge className={`text-xs ${CATEGORY_COLORS[accessory.category] || "bg-gray-100 text-gray-800"}`}>
                      {formatCategoryName(accessory.category)}
                    </Badge>
                  </div>
                  
                  <button
                    onClick={() => toggleFavorite(accessory)}
                    className="ml-2 flex-shrink-0"
                  >
                    <Star 
                      className={`w-5 h-5 transition-colors ${
                        accessory.is_favorite 
                          ? 'text-yellow-400 fill-current' 
                          : 'text-gray-300 hover:text-yellow-400'
                      }`}
                    />
                  </button>
                </div>
              </CardHeader>

              <CardContent>
                <div className="space-y-4">
                  {accessory.image_url && (
                    <div className="rounded-lg overflow-hidden bg-gray-100">
                      <img 
                        src={accessory.image_url} 
                        alt={accessory.name}
                        className="w-full h-48 object-cover"
                      />
                    </div>
                  )}

                  {accessory.condition && (
                    <div className="flex justify-between items-center p-2 bg-gray-50 rounded-lg">
                      <span className="text-xs md:text-sm text-gray-600">Condition</span>
                      <Badge variant="outline" className="text-xs">
                        {formatCategoryName(accessory.condition)}
                      </Badge>
                    </div>
                  )}

                  {accessory.purchase_date && (
                    <div className="flex justify-between items-center text-xs md:text-sm text-gray-600">
                      <span>Acquired</span>
                      <span>{format(new Date(accessory.purchase_date), "MMM d, yyyy")}</span>
                    </div>
                  )}

                  {accessory.purchase_price && (
                    <div className="flex justify-between items-center text-xs md:text-sm">
                      <span className="text-gray-600">Price</span>
                      <span className="font-semibold text-green-600">
                        ${accessory.purchase_price.toFixed(2)}
                      </span>
                    </div>
                  )}

                  {accessory.notes && (
                    <p className="text-xs md:text-sm text-gray-600 line-clamp-2">
                      {accessory.notes}
                    </p>
                  )}

                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(accessory)}
                      className="flex-1"
                    >
                      <Edit className="w-3 h-3 mr-1" />
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(accessory.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="bg-white/80 backdrop-blur-sm">
          <CardContent className="text-center py-12">
            <Package className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No Accessories Yet</h3>
            <p className="text-gray-600 mb-6">Start building your collection of cannabis accessories</p>
            <Button 
              onClick={() => {
                resetForm();
                setShowAddDialog(true);
              }}
              className="bg-green-600 hover:bg-green-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Your First Accessory
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto glass-card border-white/40">
          <DialogHeader>
            <DialogTitle className="text-xl">
              {editingAccessory ? 'Edit Accessory' : 'Add New Accessory'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="e.g., My favorite grinder"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="category">Category *</Label>
              <Select value={formData.category} onValueChange={(value) => handleInputChange('category', value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(CATEGORY_ICONS).map(cat => (
                    <SelectItem key={cat} value={cat}>
                      {CATEGORY_ICONS[cat]} {formatCategoryName(cat)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="brand">Brand</Label>
              <Input
                id="brand"
                value={formData.brand}
                onChange={(e) => handleInputChange('brand', e.target.value)}
                placeholder="e.g., Santa Cruz Shredder"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="image">Photo</Label>
              <div className="mt-1 space-y-2">
                <Input
                  id="image"
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                />
                {imagePreview && (
                  <div className="relative rounded-lg overflow-hidden bg-gray-100">
                    <img 
                      src={imagePreview} 
                      alt="Preview" 
                      className="w-full h-48 object-cover"
                    />
                  </div>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="purchase_date">Purchase Date</Label>
                <Input
                  id="purchase_date"
                  type="date"
                  value={formData.purchase_date}
                  onChange={(e) => handleInputChange('purchase_date', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="purchase_price">Purchase Price ($)</Label>
                <Input
                  id="purchase_price"
                  type="number"
                  step="0.01"
                  value={formData.purchase_price}
                  onChange={(e) => handleInputChange('purchase_price', e.target.value)}
                  placeholder="0.00"
                  className="mt-1"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="purchase_location">Purchase Location</Label>
              <Input
                id="purchase_location"
                value={formData.purchase_location}
                onChange={(e) => handleInputChange('purchase_location', e.target.value)}
                placeholder="e.g., Local smoke shop"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="condition">Condition</Label>
              <Select value={formData.condition} onValueChange={(value) => handleInputChange('condition', value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="like_new">Like New</SelectItem>
                  <SelectItem value="good">Good</SelectItem>
                  <SelectItem value="fair">Fair</SelectItem>
                  <SelectItem value="needs_repair">Needs Repair</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                placeholder="Any additional details about this accessory..."
                className="mt-1 min-h-[100px]"
              />
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="is_favorite"
                checked={formData.is_favorite}
                onChange={(e) => handleInputChange('is_favorite', e.target.checked)}
                className="rounded border-gray-300"
              />
              <Label htmlFor="is_favorite" className="cursor-pointer flex items-center gap-2">
                <Star className="w-4 h-4 text-yellow-400" />
                Mark as favorite
              </Label>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setShowAddDialog(false);
              resetForm();
            }}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700">
              <Sparkles className="w-4 h-4 mr-2" />
              {editingAccessory ? 'Update' : 'Add'} Accessory
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}