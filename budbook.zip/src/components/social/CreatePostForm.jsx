
import React, { useState, useEffect } from 'react';
import { Session, SocialPost, Product } from '@/entities/all';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Send } from 'lucide-react';
import { toast } from 'sonner';

export default function CreatePostForm({ circleId, currentUser, onPostCreated }) {
  const [content, setContent] = useState('');
  const [selectedSessionId, setSelectedSessionId] = useState('');
  const [recentSessions, setRecentSessions] = useState([]);
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    const fetchSessions = async () => {
      if (!currentUser) return;
      const sessions = await Session.filter({ created_by: currentUser.email }, "-date", 20);
      const products = await Product.list();
      
      const sessionsWithProducts = sessions.map(session => {
        const product = products.find(p => p.id === session.product_id);
        return {
          ...session,
          product_name: product?.name || 'Unknown Product'
        };
      });

      setRecentSessions(sessionsWithProducts);
    };

    fetchSessions();
  }, [currentUser]);

  const handlePost = async (e) => {
    e.preventDefault();
    if (!selectedSessionId) {
      toast.error("Please select a session to post about.");
      return;
    }
    if (!content.trim()) {
      toast.error("Please write something for your post.");
      return;
    }
    
    setPosting(true);
    try {
      await SocialPost.create({
        content: content.trim(),
        session_id: selectedSessionId,
        circle_id: circleId,
        author_name: currentUser.full_name,
        likes: [],
        visibility: 'public' // Visibility is controlled by circle privacy
      });

      toast.success("Posted to circle successfully!");
      setContent('');
      setSelectedSessionId('');
      if (onPostCreated) {
        onPostCreated();
      }
    } catch (error) {
      console.error("Failed to create post:", error);
      toast.error("Could not create post. Please try again.");
    } finally {
      setPosting(false);
    }
  };

  return (
    <Card className="glass-card mb-6">
      <CardHeader>
        <CardTitle className="text-lg">Create a New Post</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handlePost} className="space-y-4">
          <Select value={selectedSessionId} onValueChange={setSelectedSessionId}>
            <SelectTrigger className="glass-card border-white/40 min-h-[44px]">
              <SelectValue placeholder="Select a recent session to share..." />
            </SelectTrigger>
            <SelectContent className="glass-card">
              {recentSessions.map(session => (
                <SelectItem key={session.id} value={session.id}>
                  {session.session_name || `${session.product_name} on ${new Date(session.date).toLocaleDateString()}`}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Textarea
            placeholder="What's on your mind? Share your thoughts on this session..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[100px] glass-card border-white/40"
            rows={4}
          />
          
          <div className="flex justify-end">
            <Button type="submit" disabled={posting || !selectedSessionId || !content.trim()} className="bg-blue-600/90 hover:bg-blue-700/90 min-h-[44px] font-medium">
              {posting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Posting...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Post
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
