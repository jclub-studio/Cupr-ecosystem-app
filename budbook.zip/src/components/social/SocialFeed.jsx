
import React, { useState, useEffect, useCallback } from 'react';
import { SocialPost, User, Session, Product, UserInventory, SmokeCircle } from '@/entities/all';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PostCard from './PostCard';
import { Loader2, Search, Users, Globe, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';

export default function SocialFeed() {
  const [currentUser, setCurrentUser] = useState(null);
  const [allPosts, setAllPosts] = useState([]);
  const [filteredPosts, setFilteredPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('personalized');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Cache for sessions and products to avoid repeated fetches and prevent rate limits
  const [sessionsCache, setSessionsCache] = useState({});
  const [productsCache, setProductsCache] = useState({});

  const filterPostsForUser = useCallback(async (user, posts, tabType) => {
    if (!user) {
      setFilteredPosts([]);
      return;
    }

    try {
      // 1. Batch fetch all unique sessions needed for posts (if not already in cache)
      const uniqueSessionIdsFromPosts = [...new Set(posts.map(p => p.session_id).filter(Boolean))];
      const sessionIdsToFetch = uniqueSessionIdsFromPosts.filter(id => !sessionsCache[id]);
      
      let newlyFetchedSessionsMap = {};
      if (sessionIdsToFetch.length > 0) {
        console.log(`Fetching ${sessionIdsToFetch.length} sessions...`);
        const sessionPromises = sessionIdsToFetch.map(id => Session.get(id).catch(() => null));
        const fetchedSessionsArr = await Promise.all(sessionPromises);
        fetchedSessionsArr.forEach((session, idx) => {
          if (session) newlyFetchedSessionsMap[sessionIdsToFetch[idx]] = session;
        });
        setSessionsCache(prev => ({ ...prev, ...newlyFetchedSessionsMap }));
      }
      // Combine existing cached sessions with newly fetched ones for immediate use in this run
      const currentSessionsContext = { ...sessionsCache, ...newlyFetchedSessionsMap };

      // 2. Fetch user-specific data concurrently
      const [userCircles, userInventory, userSessions] = await Promise.all([
        SmokeCircle.filter({ members: user.email }),
        UserInventory.filter({ created_by: user.email, is_active: true }),
        Session.filter({ created_by: user.email })
      ]);

      // 3. Identify all unique product IDs that might be relevant
      const productIdsFromUserInventory = userInventory.map(i => i.product_id);
      const productIdsFromUserSessions = userSessions.map(s => s.product_id);
      const productIdsFromKnownSessions = Object.values(currentSessionsContext).map(s => s.product_id).filter(Boolean);

      const combinedUniqueProductIds = [...new Set([
        ...productIdsFromUserInventory,
        ...productIdsFromUserSessions,
        ...productIdsFromKnownSessions
      ])];

      // 4. Batch fetch unique products (if not already in cache)
      const productIdsToFetch = combinedUniqueProductIds.filter(id => !productsCache[id]);
      
      let newlyFetchedProductsMap = {};
      if (productIdsToFetch.length > 0) {
        const productPromises = productIdsToFetch.map(id => Product.get(id).catch(() => null));
        const fetchedProductsArr = await Promise.all(productPromises);
        fetchedProductsArr.forEach((product, idx) => {
          if (product) newlyFetchedProductsMap[productIdsToFetch[idx]] = product;
        });
        setProductsCache(prev => ({ ...prev, ...newlyFetchedProductsMap }));
      }
      // Combine existing cached products with newly fetched ones for immediate use in this run
      const currentProductsContext = { ...productsCache, ...newlyFetchedProductsMap };


      let relevantPosts = [];

      if (tabType === 'personalized') {
        // 1. Posts from circles user is member of
        const userCircleIds = userCircles.map(c => c.id);
        const circlePosts = posts.filter(post => 
          post.circle_id && userCircleIds.includes(post.circle_id)
        );

        // 2. Public posts from friends
        const friendPosts = posts.filter(post => 
          !post.circle_id && 
          post.visibility === 'public' && 
          user.friends && user.friends.includes(post.created_by)
        );

        // 3. Related posts based on user's inventory/sessions
        const userStrains = new Set();
        const userCategories = new Set();

        productIdsFromUserInventory.forEach(productId => {
          const product = currentProductsContext[productId];
          if (product) {
            if (product.strain_name) userStrains.add(product.strain_name.toLowerCase());
            if (product.category) userCategories.add(product.category);
          }
        });
        productIdsFromUserSessions.forEach(productId => {
          const product = currentProductsContext[productId];
          if (product) {
            if (product.strain_name) userStrains.add(product.strain_name.toLowerCase());
            if (product.category) userCategories.add(product.category);
          }
        });

        // Find posts with similar products
        const relatedPosts = [];
        for (const post of posts) {
          if (post.circle_id || post.created_by === user.email) continue;
          if (post.visibility !== 'public') continue;
          
          if (post.session_id && currentSessionsContext[post.session_id]) {
            const session = currentSessionsContext[post.session_id];
            const product = currentProductsContext[session.product_id];
            if (product) {
              const hasStrainMatch = product.strain_name && 
                userStrains.has(product.strain_name.toLowerCase());
              const hasCategoryMatch = product.category && 
                userCategories.has(product.category);
              
              if (hasStrainMatch || hasCategoryMatch) {
                relatedPosts.push({
                  ...post,
                  relevanceScore: hasStrainMatch ? 2 : 1
                });
              }
            }
          }
        }

        // Combine and sort by relevance and recency
        relevantPosts = [
          ...circlePosts.map(p => ({ ...p, source: 'circle', relevanceScore: 3 })),
          ...friendPosts.map(p => ({ ...p, source: 'friend', relevanceScore: 2 })),
          ...relatedPosts.map(p => ({ ...p, source: 'related' }))
        ].sort((a, b) => {
          if (a.relevanceScore !== b.relevanceScore) {
            return b.relevanceScore - a.relevanceScore;
          }
          return new Date(b.created_date) - new Date(a.created_date);
        });

      } else if (tabType === 'friends') {
        relevantPosts = posts.filter(post => 
          post.visibility === 'public' && 
          user.friends && user.friends.includes(post.created_by)
        );

      } else if (tabType === 'public') {
        const publicCircles = await SmokeCircle.filter({ circle_type: 'public' });
        const publicCircleIds = publicCircles.map(c => c.id);
        
        relevantPosts = posts.filter(post => 
          (post.visibility === 'public' && !post.circle_id) ||
          (post.circle_id && publicCircleIds.includes(post.circle_id))
        );

      } else if (tabType === 'circles') {
        const userCircleIds = userCircles.map(c => c.id);
        relevantPosts = posts.filter(post => 
          post.circle_id && userCircleIds.includes(post.circle_id)
        );
      }

      // Apply search filter if active
      if (searchTerm.trim()) {
        const searchLower = searchTerm.toLowerCase();
        relevantPosts = relevantPosts.filter(post =>
          post.content.toLowerCase().includes(searchLower) ||
          post.author_name.toLowerCase().includes(searchLower)
        );
      }

      setFilteredPosts(relevantPosts);
    } catch (error) {
      console.error('Error filtering posts:', error);
      toast.error('Failed to load posts');
      setFilteredPosts([]); 
    }
  }, [sessionsCache, productsCache, searchTerm, setSessionsCache, setProductsCache]); // Add setters to dependencies for functional updates

  const loadFeedData = useCallback(async () => {
    setLoading(true);
    try {
      const [userData, allPostsData] = await Promise.all([
        User.me(),
        SocialPost.list('-created_date')
      ]);
      
      setCurrentUser(userData);
      setAllPosts(allPostsData);
      
      // The actual filtering will be triggered by the useEffect below
    } catch (error) {
      console.error('Error loading social feed:', error);
      toast.error('Failed to load social feed');
      setCurrentUser(null);
      setAllPosts([]);
    } finally {
      setLoading(false);
    }
  }, []); // No external dependencies, runs once on mount

  useEffect(() => {
    loadFeedData();
  }, [loadFeedData]);

  // Effect to perform filtering whenever relevant state changes
  useEffect(() => {
    if (currentUser && allPosts.length > 0 && !loading) {
      filterPostsForUser(currentUser, allPosts, activeTab);
    } else if (currentUser && allPosts.length === 0 && !loading) {
      // If user is loaded but no posts and not loading, means no posts were found.
      setFilteredPosts([]);
    }
  }, [activeTab, searchTerm, currentUser, allPosts, filterPostsForUser, loading]); // All state and memoized functions are dependencies for robustness

  const handleTabChange = (newTab) => {
    setActiveTab(newTab);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-20">
        <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="glass-card border-white/40">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            Social Feed
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search posts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 glass-card border-white/40"
            />
          </div>

          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="grid w-full grid-cols-4 glass-card p-1">
              <TabsTrigger 
                value="personalized" 
                className="data-[state=active]:bg-white/90 data-[state=active]:shadow-md text-xs md:text-sm"
              >
                <TrendingUp className="w-4 h-4 mr-1 md:mr-2" />
                For You
              </TabsTrigger>
              <TabsTrigger 
                value="friends" 
                className="data-[state=active]:bg-white/90 data-[state=active]:shadow-md text-xs md:text-sm"
              >
                <Users className="w-4 h-4 mr-1 md:mr-2" />
                Friends
              </TabsTrigger>
              <TabsTrigger 
                value="public" 
                className="data-[state=active]:bg-white/90 data-[state=active]:shadow-md text-xs md:text-sm"
              >
                <Globe className="w-4 h-4 mr-1 md:mr-2" />
                Public
              </TabsTrigger>
              <TabsTrigger 
                value="circles" 
                className="data-[state=active]:bg-white/90 data-[state=active]:shadow-md text-xs md:text-sm"
              >
                <Users className="w-4 h-4 mr-1 md:mr-2" />
                Circles
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {filteredPosts.length > 0 ? (
          filteredPosts.map(post => (
            <div key={post.id} className="relative">
              <PostCard post={post} />
              {activeTab === 'personalized' && post.source && (
                <div className="absolute top-4 right-4">
                  {post.source === 'circle' && (
                    <div className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded-full">
                      Circle
                    </div>
                  )}
                  {post.source === 'friend' && (
                    <div className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full">
                      Friend
                    </div>
                  )}
                  {post.source === 'related' && (
                    <div className="bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded-full">
                      Similar Products
                    </div>
                  )}
                </div>
              )}
            </div>
          ))
        ) : (
          <Card className="glass-card border-white/40">
            <CardContent className="text-center py-12">
              <TrendingUp className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No posts found</h3>
              <p className="text-gray-600">
                {searchTerm ? 
                  'Try adjusting your search terms' : 
                  activeTab === 'friends' ? 
                    'Connect with friends to see their posts' :
                    activeTab === 'circles' ?
                      'Join some circles to see posts' :
                      'Check back later for new content'
                }
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
