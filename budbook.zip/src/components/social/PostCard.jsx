
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, MessageSquare, Share2, Leaf, Users } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

// API imports
import { SocialPost, User, Session, Product, SmokeCircle } from '@/entities/all';

// Component imports  
import SessionDetailsModal from '../journal/SessionDetailsModal';

const PostCard = ({ post }) => {
  const [author, setAuthor] = useState(null);
  const [session, setSession] = useState(null);
  const [product, setProduct] = useState(null);
  const [circle, setCircle] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likes?.length || 0);
  const [showSessionDetails, setShowSessionDetails] = useState(false);

  const fetchPostDetails = useCallback(async () => {
    try {
      const [authorData, currentUserData] = await Promise.all([
        User.filter({ email: post.created_by }).then(users => users[0]),
        User.me()
      ]);
      
      setAuthor(authorData);
      setCurrentUser(currentUserData);
      setLikeCount(post.likes?.length || 0);
      setIsLiked(post.likes?.includes(currentUserData?.email));

      // Load circle data if post belongs to a circle
      if (post.circle_id) {
        const circleData = await SmokeCircle.get(post.circle_id);
        setCircle(circleData);
      }

      // Load session and product data
      if (post.session_id) {
        const sessionData = await Session.get(post.session_id);
        setSession(sessionData);
        if (sessionData && sessionData.product_id) {
          const productData = await Product.get(sessionData.product_id);
          setProduct(productData);
        }
      }
    } catch (error) {
      console.error("Error fetching post details:", error);
      toast.error("Failed to load post details.");
    }
  }, [post.created_by, post.session_id, post.circle_id, post.likes]);

  useEffect(() => {
    fetchPostDetails();
  }, [fetchPostDetails]);

  const handleLike = async () => {
    if (!currentUser) {
      toast.error("You must be logged in to like posts.");
      return;
    }
    
    const newLikedState = !isLiked;
    const currentLikes = post.likes || [];
    const newLikes = newLikedState
      ? [...currentLikes, currentUser.email]
      : currentLikes.filter(email => email !== currentUser.email);

    // Optimistic update
    setIsLiked(newLikedState);
    setLikeCount(newLikes.length);
    post.likes = newLikes;

    try {
      await SocialPost.update(post.id, { likes: newLikes });
    } catch (error) {
      console.error("Failed to update like:", error);
      toast.error("Failed to like post.");
      // Revert optimistic update
      setIsLiked(!newLikedState);
      setLikeCount(currentLikes.length);
      post.likes = currentLikes;
    }
  };

  const formDataWithStrain = session && product ? {
    ...session,
    strain_name: product?.strain_name
  } : null;

  return (
    <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300 w-full">
      <CardHeader>
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10 border">
            <AvatarImage src={author?.profile_photo_url} alt={`@${author?.username}`} />
            <AvatarFallback>{author?.username?.[0]?.toUpperCase() || author?.full_name?.[0]?.toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <p className="font-semibold text-sm">{author?.full_name || 'Unknown User'}</p>
              {author?.username && (
                <p className="text-xs text-gray-500">@{author.username}</p>
              )}
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <span>
                {post.created_date ? formatDistanceToNow(new Date(post.created_date), { addSuffix: true }) : 'N/A'}
              </span>
              {circle && (
                <>
                  <span>•</span>
                  <div className="flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    <span className="truncate">{circle.name}</span>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <p className="text-gray-800 text-sm mb-4 whitespace-pre-wrap leading-relaxed">{post.content}</p>
        
        {session && product && (
          <button onClick={() => setShowSessionDetails(true)} className="w-full text-left">
            <div className="border rounded-2xl overflow-hidden glass-card p-4 hover:bg-gray-50/50 transition-colors">
               <div className="flex items-center gap-3">
                 <div className="w-12 h-12 rounded-lg flex-shrink-0 bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center">
                    <Leaf className="w-6 h-6 text-white"/>
                 </div>
                 <div className="text-left flex-1">
                    <p className="font-semibold text-sm truncate">{session.session_name || product.name}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-xs text-gray-500 truncate">{product.strain_name}</p>
                      <Badge variant="outline" className="text-xs">{product.type}</Badge>
                    </div>
                 </div>
               </div>
            </div>
          </button>
        )}
      </CardContent>

      <CardFooter className="flex items-center justify-between text-sm text-gray-600 pt-2">
        <Button variant="ghost" size="sm" onClick={handleLike} className="flex items-center gap-1.5 hover:text-red-500 transition-colors">
          <Heart className={cn("w-4 h-4", isLiked && "text-red-500 fill-red-500")} />
          <span className="text-xs font-medium">{likeCount} {likeCount === 1 ? 'Like' : 'Likes'}</span>
        </Button>
        <Button variant="ghost" size="sm" className="flex items-center gap-1.5 hover:text-blue-500 transition-colors">
          <MessageSquare className="w-4 h-4" />
          <span className="text-xs font-medium">Comment</span>
        </Button>
        <Button variant="ghost" size="sm" className="flex items-center gap-1.5 hover:text-green-500 transition-colors">
          <Share2 className="w-4 h-4" />
          <span className="text-xs font-medium">Share</span>
        </Button>
      </CardFooter>
      
      {session && formDataWithStrain && (
        <SessionDetailsModal 
          isOpen={showSessionDetails}
          onOpenChange={setShowSessionDetails}
          session={formDataWithStrain}
          product={product}
        />
      )}
    </Card>
  );
};

export default PostCard;
