import React, { useState, useRef, useCallback } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Camera, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const DualCameraCapture = ({ onCaptureComplete }) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [step, setStep] = useState('idle'); // idle, back, front, preview
  const [error, setError] = useState(null);
  const [image, setImage] = useState({ back: null, front: null, composite: null });
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);

  const stopStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  }, []);

  const startStream = useCallback(async (facingMode) => {
    stopStream();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      return true;
    } catch (err) {
      console.error(`Error starting ${facingMode} camera:`, err);
      setError(`Could not access ${facingMode} camera. Please check permissions and try again.`);
      setIsDialogOpen(false);
      return false;
    }
  }, [stopStream]);

  const handleInitialCapture = async () => {
    setError(null);
    setImage({ back: null, front: null, composite: null });
    setIsDialogOpen(true);
    setStep('back');
    await startStream('environment');
  };

  const captureFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const context = canvas.getContext('2d');
    context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
    return canvas.toDataURL('image/jpeg');
  }, []);

  const handleBackCapture = () => {
    const backImage = captureFrame();
    setImage(prev => ({ ...prev, back: backImage }));
    setStep('front');
    startStream('user');
  };

  const handleFrontCapture = () => {
    const frontImage = captureFrame();
    stopStream();
    createCompositeImage(image.back, frontImage);
    setStep('preview');
  };

  const createCompositeImage = (backDataUrl, frontDataUrl) => {
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    const backImg = new Image();
    backImg.onload = () => {
      canvas.width = backImg.width;
      canvas.height = backImg.height;
      context.drawImage(backImg, 0, 0);

      const frontImg = new Image();
      frontImg.onload = () => {
        const insetWidth = canvas.width * 0.3;
        const insetHeight = (insetWidth / frontImg.width) * frontImg.height;
        const margin = canvas.width * 0.02;
        
        context.save();
        context.shadowColor = 'rgba(0,0,0,0.4)';
        context.shadowBlur = 10;
        context.drawImage(frontImg, margin, margin, insetWidth, insetHeight);
        context.restore();

        context.strokeStyle = 'white';
        context.lineWidth = 4;
        context.strokeRect(margin, margin, insetWidth, insetHeight);

        const compositeDataUrl = canvas.toDataURL('image/jpeg');
        setImage(prev => ({ ...prev, front: frontDataUrl, composite: compositeDataUrl }));
        
        canvas.toBlob(blob => {
          onCaptureComplete(blob);
        }, 'image/jpeg', 0.9);
      };
      frontImg.src = frontDataUrl;
    };
    backImg.src = backDataUrl;
  };
  
  const handleClose = () => {
    stopStream();
    setIsDialogOpen(false);
    setStep('idle');
  }

  return (
    <>
      <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base md:text-lg">
            <Camera className="w-4 h-4 md:w-5 md:h-5 text-purple-600" />
            Capture the Vibe
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center">
            {image.composite ? (
                <div className="space-y-4">
                    <div className="relative overflow-hidden rounded-xl shadow-lg">
                        <img src={image.composite} alt="Session capture preview" className="w-full object-cover max-h-64 md:max-h-80" />
                    </div>
                    <Button onClick={handleInitialCapture} variant="outline" className="glass-card border-white/40 hover:bg-white/60 min-h-[44px] px-6">
                        <RefreshCw className="w-4 h-4 mr-2" /> Retake
                    </Button>
                </div>
            ) : (
                <div className="py-6 md:py-8">
                    <div className="w-16 h-16 md:w-20 md:h-20 bg-gradient-to-br from-purple-400 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                        <Camera className="w-8 h-8 md:w-10 md:h-10 text-white" />
                    </div>
                    <p className="text-gray-600 mb-4 text-sm md:text-base">Add a dual-camera photo to remember this moment.</p>
                    <Button onClick={handleInitialCapture} className="bg-purple-600/90 hover:bg-purple-700/90 min-h-[44px] px-6 shadow-lg">
                        <Camera className="w-4 h-4 mr-2" /> Capture Session Photo
                    </Button>
                </div>
            )}
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={handleClose}>
        <DialogContent className="max-w-3xl p-0 glass-card border-white/40" onInteractOutside={(e) => e.preventDefault()}>
          <div className="relative aspect-video bg-black rounded-t-xl overflow-hidden">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            {step === 'front' && (
              <div className="absolute top-4 left-4 text-white bg-black/60 px-3 py-2 rounded-lg text-sm backdrop-blur-sm">
                Now, capture your reaction!
              </div>
            )}
            {step === 'back' && (
              <div className="absolute top-4 left-4 text-white bg-black/60 px-3 py-2 rounded-lg text-sm backdrop-blur-sm">
                Capture the scene first
              </div>
            )}
          </div>
          <div className="p-4 flex justify-center glass-card rounded-b-xl">
            {step === 'back' && (
              <Button size="lg" onClick={handleBackCapture} className="rounded-full w-16 h-16 md:w-20 md:h-20 bg-white/90 hover:bg-white text-gray-800 shadow-xl">
                <Camera size={24} className="md:w-8 md:h-8"/>
              </Button>
            )}
            {step === 'front' && (
              <Button size="lg" onClick={handleFrontCapture} className="rounded-full w-16 h-16 md:w-20 md:h-20 bg-white/90 hover:bg-white text-gray-800 shadow-xl">
                <Camera size={24} className="md:w-8 md:h-8"/>
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>
      <canvas ref={canvasRef} className="hidden" />
    </>
  );
};

export default DualCameraCapture;