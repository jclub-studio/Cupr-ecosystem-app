import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Camera, Upload, X, CheckCircle2, AlertCircle } from 'lucide-react';

export default function SessionImageCapture({ onImageSelect, currentImage }) {
  const [isCapturing, setIsCapturing] = useState(false);
  const [previewImage, setPreviewImage] = useState(currentImage);
  const [error, setError] = useState(null);
  
  const fileInputRef = useRef(null);
  const cameraInputRef = useRef(null);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
      processImageFile(file);
    } else {
      setError('Please select a valid image file.');
    }
  };

  const processImageFile = (file) => {
    setError(null);
    setPreviewImage(file);
    onImageSelect(file);
  };

  const handleCameraCapture = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
      processImageFile(file);
    } else {
      setError('Failed to capture image. Please try again.');
    }
  };

  const clearImage = () => {
    setPreviewImage(null);
    onImageSelect(null);
    setError(null);
    // Clear file inputs
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  const getImageUrl = () => {
    if (!previewImage) return null;
    return typeof previewImage === 'string' ? previewImage : URL.createObjectURL(previewImage);
  };

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive" className="bg-red-50/80 border-red-200">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Image Preview */}
      {previewImage ? (
        <div className="space-y-4">
          <div className="relative overflow-hidden rounded-xl shadow-lg bg-gray-100">
            <img 
              src={getImageUrl()} 
              alt="Session preview" 
              className="w-full h-64 md:h-80 object-cover"
            />
            <div className="absolute top-3 right-3">
              <Button
                type="button"
                variant="destructive"
                size="sm"
                onClick={clearImage}
                className="bg-red-600/90 hover:bg-red-700/90 backdrop-blur-sm"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          <div className="flex items-center justify-center gap-2 text-green-600 bg-green-50/80 rounded-lg p-3">
            <CheckCircle2 className="w-5 h-5" />
            <span className="font-medium">Image set as session background</span>
          </div>

          {/* Retake Options */}
          <div className="grid grid-cols-2 gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => cameraInputRef.current?.click()}
              className="bg-white/80 border-gray-200 hover:bg-white min-h-[48px]"
            >
              <Camera className="w-4 h-4 mr-2" />
              Retake Photo
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              className="bg-white/80 border-gray-200 hover:bg-white min-h-[48px]"
            >
              <Upload className="w-4 h-4 mr-2" />
              Choose Different
            </Button>
          </div>
        </div>
      ) : (
        /* Initial Capture Options */
        <div className="space-y-6">
          <div className="text-center py-8">
            <div className="w-20 h-20 bg-red-100/80 rounded-full flex items-center justify-center mx-auto mb-4">
              <Camera className="w-10 h-10 text-red-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Add Session Photo</h3>
            <p className="text-gray-600 text-sm max-w-sm mx-auto">
              Capture the moment or upload a photo that represents your session. This will become your session's background.
            </p>
          </div>

          <div className="space-y-3">
            {/* Camera Capture */}
            <Button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              className="w-full bg-red-600/90 hover:bg-red-700/90 min-h-[52px] shadow-lg font-medium"
            >
              <Camera className="w-5 h-5 mr-2" />
              Take Photo
            </Button>

            {/* File Upload */}
            <Button
              type="button"
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              className="w-full bg-white/80 border-gray-200 hover:bg-white min-h-[52px] font-medium"
            >
              <Upload className="w-5 h-5 mr-2" />
              Upload from Library
            </Button>
          </div>

          <div className="text-center">
            <p className="text-xs text-gray-500">
              Supported formats: JPG, PNG, HEIC • Max size: 10MB
            </p>
          </div>
        </div>
      )}

      {/* Hidden File Inputs */}
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleCameraCapture}
        className="hidden"
      />
      
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileUpload}
        className="hidden"
      />
    </div>
  );
}