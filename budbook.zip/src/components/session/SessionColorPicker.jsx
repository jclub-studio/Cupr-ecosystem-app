import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

const COLORS = [
  { name: 'Dawn', gradient: 'linear-gradient(135deg, #FFDAB9 0%, #F5DEB3 100%)' }, // Peach Puff to Wheat
  { name: 'Dusk', gradient: 'linear-gradient(135deg, #483D8B 0%, #6A5ACD 100%)' }, // Dark Slate Blue to Slate Blue
  { name: 'Forest', gradient: 'linear-gradient(135deg, #006400 0%, #2E8B57 100%)' }, // Dark Green to Sea Green
  { name: 'Ocean', gradient: 'linear-gradient(135deg, #1E90FF 0%, #4682B4 100%)' }, // Dodger Blue to Steel Blue
  { name: 'Blaze', gradient: 'linear-gradient(135deg, #FF4500 0%, #FF8C00 100%)' }, // Orange Red to Dark Orange
  { name: 'Amethyst', gradient: 'linear-gradient(135deg, #8A2BE2 0%, #9932CC 100%)' }, // Blue Violet to Dark Orchid
  { name: 'Rose', gradient: 'linear-gradient(135deg, #FF69B4 0%, #FF1493 100%)' }, // Hot Pink to Deep Pink
  { name: 'Mint', gradient: 'linear-gradient(135deg, #98FB98 0%, #3CB371 100%)' }, // Pale Green to Medium Sea Green
  { name: 'Sky', gradient: 'linear-gradient(135deg, #87CEEB 0%, #ADD8E6 100%)' }, // Sky Blue to Light Blue
  { name: 'Earthy', gradient: 'linear-gradient(135deg, #D2B48C 0%, #8B4513 100%)' }, // Tan to Saddle Brown
  { name: 'Slate', gradient: 'linear-gradient(135deg, #708090 0%, #2F4F4F 100%)' }, // Slate Gray to Dark Slate Gray
  { name: 'Cosmic', gradient: 'linear-gradient(135deg, #191970 0%, #000080 100%)' }, // Midnight Blue to Navy
];

export default function SessionColorPicker({ open, onOpenChange, onColorSelect }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[95vw] max-w-md h-auto flex flex-col glass-card border-white/40 mx-auto">
        <DialogHeader className="pb-4 flex-shrink-0">
          <DialogTitle>Select Background Color</DialogTitle>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto px-1 pb-4">
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-4">
            {COLORS.map((color) => (
              <div key={color.name} className="flex flex-col items-center gap-2">
                <Button
                  variant="outline"
                  className="w-20 h-20 rounded-full p-0 border-2 border-white/50 shadow-lg transition-transform hover:scale-105"
                  style={{ background: color.gradient }}
                  onClick={() => onColorSelect(color.gradient)}
                >
                </Button>
                <span className="text-xs font-medium text-gray-700">{color.name}</span>
              </div>
            ))}
             <div className="flex flex-col items-center gap-2">
                <Button
                  variant="outline"
                  className="w-20 h-20 rounded-full p-0 border-2 border-dashed border-gray-300 bg-white/50 shadow-lg transition-transform hover:scale-105"
                  onClick={() => onColorSelect(null)}
                >
                  <span className="text-xs text-gray-500">None</span>
                </Button>
                <span className="text-xs font-medium text-gray-700">Clear</span>
              </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}