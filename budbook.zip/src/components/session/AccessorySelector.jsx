import React, { useState, useEffect } from 'react';
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Search, Check, Package, Plus } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { cn } from "@/lib/utils";

const CATEGORY_ICONS = {
  grinder: "⚙️",
  pipe: "🌿",
  bong: "💧",
  bubbler: "💨",
  rolling_papers: "📄",
  rolling_machine: "🎰",
  vaporizer_dry_herb: "💨",
  vaporizer_oil: "🔋",
  dab_rig: "🔥",
  torch: "🔥",
  lighter: "🔥",
  lighter_sleeve: "🎨",
  ashtray: "🗑️",
  storage_container: "📦",
  smell_proof_bag: "💼",
  travel_case: "🧳",
  cleaning_supplies: "🧼",
  odor_eliminator: "🌬️",
  extraction_machine: "⚗️",
  scales: "⚖️",
  room_decor: "🖼️",
  lighting: "💡",
  lava_lamp: "🌋",
  posters: "🖼️",
  furniture: "🪑",
  clothing: "👕",
  other: "✨"
};

const formatCategoryName = (category) => {
  return category.split('_').map(word => 
    word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');
};

export default function AccessorySelector({ selectedAccessoryIds = [], onAccessoriesChange }) {
  const [accessories, setAccessories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    loadAccessories();
  }, []);

  const loadAccessories = async () => {
    try {
      const data = await base44.entities.Accessory.list("-created_date");
      setAccessories(data);
    } catch (error) {
      console.error("Error loading accessories:", error);
    } finally {
      setLoading(false);
    }
  };

  const toggleAccessory = (accessoryId) => {
    const newSelection = selectedAccessoryIds.includes(accessoryId)
      ? selectedAccessoryIds.filter(id => id !== accessoryId)
      : [...selectedAccessoryIds, accessoryId];
    onAccessoriesChange(newSelection);
  };

  const filteredAccessories = accessories.filter(acc =>
    acc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    acc.brand?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedAccessories = accessories.filter(acc => 
    selectedAccessoryIds.includes(acc.id)
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
      </div>
    );
  }

  if (accessories.length === 0) {
    return (
      <Card className="bg-white/60 backdrop-blur-sm border-white/40">
        <CardContent className="text-center py-8">
          <Package className="w-12 h-12 mx-auto mb-3 text-gray-300" />
          <h3 className="text-base font-semibold text-gray-900 mb-2">No Accessories Yet</h3>
          <p className="text-sm text-gray-600 mb-4">Add accessories to your stash to track what you use</p>
          <Link to={createPageUrl("MyStash") + "?tab=accessories"}>
            <Button className="bg-green-600 hover:bg-green-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Accessories
            </Button>
          </Link>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Selected Accessories Display */}
      <div className="bg-white/60 backdrop-blur-sm rounded-xl border border-white/40 p-4 min-h-[80px]">
        <Label className="text-sm font-medium text-gray-800 mb-3 block">
          Selected Accessories ({selectedAccessories.length})
        </Label>
        {selectedAccessories.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            {selectedAccessories.map(accessory => (
              <Badge
                key={accessory.id}
                className="bg-green-600 hover:bg-green-700 text-white border-0 text-sm px-3 py-2 flex items-center gap-2 cursor-pointer transition-colors min-h-[40px]"
                onClick={() => toggleAccessory(accessory.id)}
              >
                <span>{CATEGORY_ICONS[accessory.category]}</span>
                <span>{accessory.name}</span>
                <Check className="w-3 h-3 flex-shrink-0" />
              </Badge>
            ))}
          </div>
        ) : (
          <p className="text-sm text-gray-500 py-2">Select accessories you used during this session</p>
        )}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Search your accessories..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 bg-white/60 backdrop-blur-sm border-white/40"
        />
      </div>

      {/* Accessories Grid */}
      <div className="grid grid-cols-1 gap-2 max-h-[400px] overflow-y-auto">
        {filteredAccessories.map(accessory => {
          const isSelected = selectedAccessoryIds.includes(accessory.id);
          return (
            <Button
              key={accessory.id}
              type="button"
              variant="outline"
              onClick={() => toggleAccessory(accessory.id)}
              className={cn(
                "justify-start text-left h-auto py-3 px-4 rounded-xl border transition-all",
                isSelected
                  ? 'bg-green-600 text-white border-green-600 hover:bg-green-700 shadow-md'
                  : 'bg-white/80 text-gray-700 border-gray-200 hover:bg-white hover:border-gray-300'
              )}
            >
              <div className="flex items-center gap-3 w-full">
                <div className="flex-shrink-0 text-2xl">
                  {CATEGORY_ICONS[accessory.category]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{accessory.name}</div>
                  <div className="text-xs opacity-80 flex items-center gap-2 mt-1">
                    <span>{formatCategoryName(accessory.category)}</span>
                    {accessory.brand && <span>• {accessory.brand}</span>}
                  </div>
                </div>
                {isSelected && (
                  <Check className="w-5 h-5 flex-shrink-0" />
                )}
              </div>
            </Button>
          );
        })}
      </div>
    </div>
  );
}