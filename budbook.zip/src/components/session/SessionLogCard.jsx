
import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import {
  Leaf,
  Zap,
  Camera,
  UserPlus,
  Headphones,
  HeartPulse,
  ClipboardEdit,
  Image as ImageIcon,
  Palette,
  Save,
  X,
  Loader2,
  Package // Added Package icon
} from 'lucide-react';

const SECTION_DEFINITIONS = {
  vertical: [
    { id: 'product', icon: Leaf, title: 'Product & Method', subtitle: 'Select what you consumed and how', color: 'bg-green-600' },
    { id: 'accessories', icon: Package, title: 'Accessories', subtitle: 'Track what accessories you used', color: 'bg-purple-600' }, // Added accessories section
    { id: 'details', icon: Zap, title: 'Activity', subtitle: 'Log activities, time, and context', color: 'bg-blue-600' },
    { id: 'notes', icon: ClipboardEdit, title: '+ Add Session Note', subtitle: 'Additional thoughts about this session', color: 'bg-gray-600' },
  ],
  horizontal: [
    { id: 'effects', icon: HeartPulse, title: 'Wellness', subtitle: 'Track mood, effects, and overall experience', color: 'bg-emerald-600' },
    { id: 'friends', icon: UserPlus, title: 'Social', subtitle: 'Invite friends who were part of this session', color: 'bg-purple-600' },
    { id: 'media', icon: Headphones, title: 'Media', subtitle: 'Add music, videos, or media you enjoyed', color: 'bg-indigo-600' },
  ]
};

const IconWithTooltip = ({ section, onSectionClick, hasContent, isVertical = false }) => {
  const Icon = section.icon;

  return (
    <div
      className="relative transform cursor-pointer group"
      onClick={() => onSectionClick(section.id)}
    >
      {/* Icon Container */}
      <div className={cn(
        "w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-300 shadow-lg backdrop-blur-md border border-white/30",
        "hover:scale-110 hover:shadow-xl group-hover:border-white/50",
        hasContent
          ? cn(section.color, "text-white shadow-xl")
          : "bg-white/30 text-gray-500 hover:bg-white/50"
      )}>
        <Icon className="w-6 h-6" />
      </div>

      {/* Tooltip - Different positioning for vertical vs horizontal icons */}
      <div className={cn(
        "absolute z-10 invisible group-hover:visible opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none w-max max-w-[calc(100vw-3rem)]",
        isVertical
          ? "right-full top-1/2 -translate-y-1/2 mr-2"
          : "bottom-full left-1/2 -translate-x-1/2 mb-2 flex justify-center"
      )}>
        <div className="bg-black/90 text-white text-sm rounded-lg px-3 py-2 shadow-xl backdrop-blur-sm">
          <div className="font-medium text-center">{section.title}</div>
          <div className="text-xs text-gray-300 text-center">{section.subtitle}</div>
        </div>
      </div>

      {/* Progress Indicator */}
      {hasContent && (
        <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full flex items-center justify-center border-2 border-white shadow-sm">
          <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
        </div>
      )}
    </div>
  );
};

const SummaryMessage = ({ type, data, products }) => {
  const getProductById = (productId) => {
    return products?.find(p => p.id === productId);
  };

  const renderSummary = () => {
    switch (type) {
      case 'product':
        if (!data.product_id) return null;
        const product = getProductById(data.product_id);
        if (!product) return null;
        const productDisplay = `${product.strain_name || product.name} ${product.category} - ${product.brand || 'Unknown Brand'}`;
        return (
          <div className="flex items-center gap-2 p-2 bg-green-50/80 rounded-lg border border-green-200/50">
            <Leaf className="w-4 h-4 text-green-600 flex-shrink-0" />
            <span className="text-xs font-medium text-green-800 truncate">{productDisplay}</span>
          </div>
        );

      case 'accessories': // Added accessories case
        if (!data.accessories_used?.length) return null;
        const accessoriesDisplay = `${data.accessories_used.length} accessory${data.accessories_used.length > 1 ? 's' : ''} used`;
        return (
          <div className="flex items-center gap-2 p-2 bg-purple-50/80 rounded-lg border border-purple-200/50">
            <Package className="w-4 h-4 text-purple-600 flex-shrink-0" />
            <span className="text-xs font-medium text-purple-800">{accessoriesDisplay}</span>
          </div>
        );

      case 'details':
        if (!data.date || !data.activities?.length) return null;
        const activityDisplay = `${new Date(data.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${data.activities.slice(0, 2).join(', ')}${data.activities.length > 2 ? '...' : ''}`;
        return (
          <div className="flex items-center gap-2 p-2 bg-blue-50/80 rounded-lg border border-blue-200/50">
            <Zap className="w-4 h-4 text-blue-600 flex-shrink-0" />
            <span className="text-xs font-medium text-blue-800 truncate">{activityDisplay}</span>
          </div>
        );

      case 'notes':
        if (!data.notes) return null;
        const notePreview = data.notes.length > 30 ? `${data.notes.substring(0, 30)}...` : data.notes;
        return (
          <div className="flex items-center gap-2 p-2 bg-gray-50/80 rounded-lg border border-gray-200/50">
            <ClipboardEdit className="w-4 h-4 text-gray-600 flex-shrink-0" />
            <span className="text-xs font-medium text-gray-800 truncate">{notePreview}</span>
          </div>
        );

      case 'camera':
        if (!data.sessionImage && !data.session_image_url) return null;
        return (
          <div className="flex items-center gap-2 p-2 bg-red-50/80 rounded-lg border border-red-200/50">
            <Camera className="w-4 h-4 text-red-600 flex-shrink-0" />
            <span className="text-xs font-medium text-red-800">Image Attached</span>
          </div>
        );

      case 'effects':
        const hasWellnessData = data.effects_felt?.length > 0 || data.mood_before !== 5 || data.mood_after !== 5 || data.pain_before !== 0 || data.pain_after !== 0 || data.anxiety_before !== 0 || data.anxiety_after !== 0 || data.rating !== 3;
        if (!hasWellnessData) return null;
        const effectsDisplay = data.effects_felt?.length > 0 ? data.effects_felt.slice(0, 2).join(', ') : 'Mood & wellness tracked';
        return (
          <div className="flex items-center gap-2 p-2 bg-emerald-50/80 rounded-lg border border-emerald-200/50">
            <HeartPulse className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span className="text-xs font-medium text-emerald-800 truncate">{effectsDisplay}</span>
          </div>
        );

      case 'friends':
        if (!data.tagged_friends?.length) return null;
        const friendsDisplay = `${data.tagged_friends.length} friend${data.tagged_friends.length > 1 ? 's' : ''} tagged`;
        return (
          <div className="flex items-center gap-2 p-2 bg-purple-50/80 rounded-lg border border-purple-200/50">
            <UserPlus className="w-4 h-4 text-purple-600 flex-shrink-0" />
            <span className="text-xs font-medium text-purple-800">{friendsDisplay}</span>
          </div>
        );

      case 'media':
        if (!data.shared_media?.length) return null;
        const mediaDisplay = `${data.shared_media.length} media link${data.shared_media.length > 1 ? 's' : ''} added`;
        return (
          <div className="flex items-center gap-2 p-2 bg-indigo-50/80 rounded-lg border border-indigo-200/50">
            <Headphones className="w-4 h-4 text-indigo-600 flex-shrink-0" />
            <span className="text-xs font-medium text-indigo-800">{mediaDisplay}</span>
          </div>
        );

      default:
        return null;
    }
  };

  return renderSummary();
};

export default function SessionLogCard({
  sessionImage,
  sessionBackgroundColor,
  onSectionClick,
  onColorPickerClick,
  children,
  formData,
  onSessionNameChange,
  products = [],
  onSave,
  onCancel,
  isSavingDisabled,
  saving,
  layoutMode = 'default' // Add new prop for layout control
}) {
  const hasContentCheck = (sectionId) => {
    switch (sectionId) {
      case 'product': return !!formData?.product_id;
      case 'accessories': return formData?.accessories_used?.length > 0; // Added accessories check
      case 'details': return !!(formData?.date && formData?.activities?.length > 0);
      case 'friends': return formData?.tagged_friends?.length > 0;
      case 'media': return formData?.shared_media?.length > 0;
      case 'effects': return formData?.effects_felt?.length > 0 ||
                            formData?.mood_before !== 5 || formData?.mood_after !== 5 ||
                            formData?.pain_before !== 0 || formData?.pain_after !== 0 ||
                            formData?.anxiety_before !== 0 || formData?.anxiety_after !== 0 ||
                            formData?.rating !== 3;
      case 'notes': return !!formData?.notes;
      case 'camera': return !!sessionImage || !!formData?.session_image_url;
      default: return false;
    }
  };

  const getImageUrl = () => {
    if (typeof sessionImage === 'string') return sessionImage;
    if (sessionImage instanceof File) return URL.createObjectURL(sessionImage);
    return null;
  };

  const summaryData = {
    ...formData,
    sessionImage
  };

  return (
    <div className="relative w-full h-[80vh] max-w-6xl mx-auto">
      {/* Main Session Card */}
      <div className="relative w-full h-full rounded-3xl overflow-hidden shadow-2xl bg-white/10 backdrop-blur-xl border border-white/20">

        {/* Background */}
        <div className="absolute inset-0 transition-all duration-500" style={{ background: sessionBackgroundColor || 'transparent' }}>
          {getImageUrl() ? (
            <img
              src={getImageUrl()}
              alt="Session background"
              className="w-full h-full object-cover"
            />
          ) : !sessionBackgroundColor && (
            <div className="w-full h-full bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center">
              <div className="text-center text-gray-400 px-8">
                <ImageIcon className="w-16 h-16 mx-auto mb-4 opacity-40" />
                <p className="text-lg font-light">Attach photo from your session to fill Session Log background</p>
                <p className="text-sm mt-2 opacity-70">Click the camera icon to get started</p>
              </div>
            </div>
          )}
          {/* Overlay for better text readability */}
          <div className="absolute inset-0 bg-black/20 backdrop-blur-[1px]"></div>
        </div>

        {/* Editable Session Name - Renders conditionally */}
        {layoutMode === 'default' && (
          <div className="absolute top-6 left-6 max-w-xs">
            <Input
              value={formData?.session_name || ''}
              onChange={(e) => onSessionNameChange?.(e.target.value)}
              placeholder="Add Session Title..."
              className="bg-black/40 backdrop-blur-md border-white/30 text-white placeholder:text-white/70 text-lg font-medium shadow-xl focus:bg-black/50 focus:border-white/50 min-h-[48px]"
            />
          </div>
        )}

        {/* Summary Messages - Only shown in fullscreen mode */}
        {layoutMode === 'fullscreen' && (
          <div className="absolute top-20 left-6 max-w-sm space-y-2">
            {['product', 'accessories', 'details', 'notes', 'camera', 'effects', 'friends', 'media'].map((type) => ( // Added 'accessories' to the list
              <SummaryMessage
                key={type}
                type={type}
                data={summaryData}
                products={products}
              />
            ))}
          </div>
        )}

        {/* Conditional rendering for default layout icons */}
        {layoutMode === 'default' && (
          <>
            {/* Top Right Action Icons */}
            <div className="absolute top-6 right-5 flex flex-col space-y-3">
              {/* Camera Icon */}
              <div
                className="relative transform cursor-pointer group"
                onClick={() => onSectionClick('camera')}
              >
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-300 shadow-lg backdrop-blur-md border border-white/30",
                  "hover:scale-110 hover:shadow-xl group-hover:border-white/50",
                  "bg-black/20 text-white hover:bg-black/40"
                )}>
                  <Camera className="w-6 h-6" />
                </div>
              </div>
              {/* Color Picker Icon */}
              <div
                className="relative transform cursor-pointer group"
                onClick={onColorPickerClick}
              >
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-300 shadow-lg backdrop-blur-md border border-white/30 p-1",
                  "hover:scale-110 hover:shadow-xl group-hover:border-white/50",
                  "bg-black/20 text-white hover:bg-black/40"
                )}>
                  <div
                    className="w-full h-full rounded-[10px] border border-black/10"
                    style={{ background: sessionBackgroundColor || 'transparent' }}
                  />
                  <Palette className={cn("w-6 h-6 absolute transition-opacity", sessionBackgroundColor ? "opacity-0" : "opacity-100")} />
                </div>
              </div>
            </div>

            {/* Vertical Icon Group - Centered Right */}
            <div className="absolute top-1/2 -translate-y-1/2 right-5 flex flex-col space-y-3">
              {SECTION_DEFINITIONS.vertical.map((section) => (
                <IconWithTooltip
                  key={section.id}
                  section={section}
                  onSectionClick={onSectionClick}
                  hasContent={hasContentCheck(section.id)}
                  isVertical={true}
                />
              ))}
            </div>

            {/* Horizontal Icon Group - Bottom Center */}
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-end space-x-3">
              {SECTION_DEFINITIONS.horizontal.map((section) => (
                <IconWithTooltip
                  key={section.id}
                  section={section}
                  onSectionClick={onSectionClick}
                  hasContent={hasContentCheck(section.id)}
                  isVertical={false}
                />
              ))}
            </div>

            {/* Bottom Left Cancel Action */}
            {onCancel && (
              <div className="absolute bottom-6 left-5">
                <div className="relative group">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={onCancel}
                    className="w-12 h-12 rounded-2xl bg-black/20 hover:bg-black/40 backdrop-blur-md text-white transition-all"
                  >
                    <X className="w-6 h-6" />
                  </Button>
                  <div className="absolute z-10 invisible group-hover:visible opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none bottom-full left-1/2 -translate-x-1/2 mb-2 w-max">
                    <div className="bg-black/90 text-white text-xs rounded-md px-2 py-1 shadow-xl">Cancel</div>
                  </div>
                </div>
              </div>
            )}

            {/* Bottom Right Save Action */}
            {onSave && (
              <div className="absolute bottom-6 right-5">
                <div className="relative group">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={onSave}
                    disabled={isSavingDisabled}
                    className="w-12 h-12 rounded-2xl bg-green-600/80 hover:bg-green-600 backdrop-blur-md text-white transition-all disabled:bg-gray-500/50 disabled:cursor-not-allowed"
                  >
                    {saving ? <Loader2 className="w-6 h-6 animate-spin" /> : <Save className="w-6 h-6" />}
                  </Button>
                  <div className="absolute z-10 invisible group-hover:visible opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none bottom-full left-1/2 -translate-x-1/2 mb-2 w-max">
                    <div className="bg-black/90 text-white text-xs rounded-md px-2 py-1 shadow-xl">Save Session</div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Modal Content */}
      {children}
    </div>
  );
}
