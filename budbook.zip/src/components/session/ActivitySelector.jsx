
import React, { useState } from 'react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dumbbell,
  Paintbrush,
  Brain,
  Users,
  Heart,
  Gamepad2,
  ChefHat,
  Compass,
  BookOpen,
  Home,
  X,
  CheckCircle2
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Label } from '@/components/ui/label';

const ACTIVITY_CATEGORIES = [
  { 
    name: 'Exercise & Movement', 
    icon: Dumbbell, 
    tags: ["Yoga", "Gym", "Running", "Hiking", "Biking", "Sports", "Swimming", "Cycling", "Rock Climbing", "Martial Arts"] 
  },
  { 
    name: 'Creativity & Arts', 
    icon: Paintbrush, 
    tags: ["Drawing", "Writing", "Music Creation", "Art Appreciation", "Music Listening", "Photography", "Crafting", "Dancing"] 
  },
  { 
    name: 'Meditation & Mindfulness', 
    icon: Brain, 
    tags: ["Meditation", "Breathing Exercises", "Spiritual Practice", "Reflection", "Prayer", "Mindful Walking", "Journaling"] 
  },
  { 
    name: 'Social & Party', 
    icon: Users, 
    tags: ["Socializing", "Party", "Networking", "Family Gathering", "Group Session", "Concert", "Festival", "Date Night"] 
  },
  { 
    name: 'Relaxation & Self-Care', 
    icon: Heart, 
    tags: ["Lounging", "Spa", "Bath", "Skincare", "Massage", "Casual Downtime", "Napping", "Stretching"] 
  },
  { 
    name: 'Gaming & Entertainment', 
    icon: Gamepad2, 
    tags: ["Video Games", "Board Games", "Puzzles", "Movies", "TV Shows", "Streaming", "Comedy", "Theater"] 
  },
  { 
    name: 'Cooking & Food', 
    icon: ChefHat, 
    tags: ["Cooking", "Baking", "Meal Prep", "Edible Experience", "Food Tasting", "Recipe Testing", "Grilling"] 
  },
  { 
    name: 'Travel & Exploration', 
    icon: Compass, 
    tags: ["Trip", "Sightseeing", "Road Trip", "Exploring", "Adventure", "Beach Day", "Camping", "Nature Walk"] 
  },
  { 
    name: 'Study & Focus', 
    icon: BookOpen, 
    tags: ["Work", "Learning", "Studying", "Focused Tasks", "Reading", "Research", "Planning", "Problem Solving"] 
  },
  { 
    name: 'Home & Daily Life', 
    icon: Home, 
    tags: ["Gardening", "Plant Care", "Chores", "Home Activities", "Organizing", "Cleaning", "Pet Care", "DIY Projects"] 
  }
];

export default function ActivitySelector({ selectedActivities, onToggleActivity }) {
  const [activeCategory, setActiveCategory] = useState(ACTIVITY_CATEGORIES[0]);

  return (
    <div className="space-y-4">
      {/* Selected Activities Display */}
      <div className="bg-white/60 backdrop-blur-sm rounded-xl border border-white/40 p-4 min-h-[80px]">
        <Label className="text-sm font-medium text-gray-800 mb-3 block">Selected Activities</Label>
        {selectedActivities.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            {selectedActivities.map(activity => (
              <Badge
                key={activity}
                className="bg-blue-600 hover:bg-blue-700 text-white border-0 text-sm px-3 py-2 flex items-center gap-2 cursor-pointer transition-colors min-h-[40px]"
                onClick={() => onToggleActivity(activity)}
              >
                <span>{activity}</span>
                <X className="w-3 h-3 flex-shrink-0" />
              </Badge>
            ))}
          </div>
        ) : (
          <p className="text-sm text-gray-500 py-2">Select activities from the categories below</p>
        )}
      </div>

      {/* Category Navigation - Mobile Scrollable */}
      <div className="overflow-x-auto pb-2">
        <div className="flex space-x-2 min-w-max">
          {ACTIVITY_CATEGORIES.map(category => (
            <Button
              key={category.name}
              type="button"
              variant="outline"
              onClick={() => setActiveCategory(category)}
              className={cn(
                "flex-shrink-0 flex items-center gap-2 px-4 py-3 rounded-xl border text-xs font-medium transition-all min-h-[52px] whitespace-nowrap",
                activeCategory.name === category.name 
                  ? "bg-blue-600 text-white border-blue-600 shadow-md" 
                  : "bg-white/60 text-gray-700 border-gray-200 hover:bg-white/80"
              )}
            >
              <category.icon className="w-4 h-4 flex-shrink-0" />
              <span className="text-xs font-medium">{category.name}</span>
            </Button>
          ))}
        </div>
      </div>
      
      {/* Activity Tags - Mobile Optimized Grid */}
      <div className="bg-white/60 backdrop-blur-sm rounded-xl border border-white/40 p-4">
        <Label className="text-sm font-medium text-gray-800 mb-4 block">
          {activeCategory.name} Activities
        </Label>
        <div className="grid grid-cols-1 gap-2">
          {activeCategory.tags.map(tag => (
            <Button
              key={tag}
              type="button"
              variant="outline"
              onClick={() => onToggleActivity(tag)}
              className={cn(
                "justify-start text-sm font-normal rounded-xl border transition-all min-h-[52px] px-4 py-3 text-base",
                selectedActivities.includes(tag)
                  ? 'bg-green-600 text-white border-green-600 hover:bg-green-700 shadow-md'
                  : 'bg-white/80 text-gray-700 border-gray-200 hover:bg-white hover:border-gray-300'
              )}
            >
              <div className="flex items-center gap-3 w-full">
                {selectedActivities.includes(tag) && <CheckCircle2 className="w-4 h-4 flex-shrink-0" />}
                <span className="text-left font-medium">{tag}</span>
              </div>
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}
