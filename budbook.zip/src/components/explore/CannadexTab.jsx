import React, { useState, useEffect } from "react";
import { Terpene, Cannabinoid, Product, Session, UserInventory, User } from "@/entities/all";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Leaf, TestTube2, Loader2, Pill } from "lucide-react";
import TerpeneCatalog from "../library/TerpeneCatalog";
import CannabinoidCatalog from "../library/CannabinoidCatalog";
import StrainCatalog from "../library/StrainCatalog";

export default function CannadexTab() {
  const [data, setData] = useState({
    terpenes: [],
    cannabinoids: [],
    products: [],
    sessions: [],
    inventory: [],
    user: null,
    loading: true,
  });

  useEffect(() => {
    const loadAllData = async () => {
      try {
        const [terpenes, cannabinoids, products, sessions, inventory, user] = await Promise.all([
          Terpene.list(),
          Cannabinoid.list(),
          Product.list(),
          Session.list(),
          UserInventory.list(),
          User.me(),
        ]);
        setData({ terpenes, cannabinoids, products, sessions, inventory, user, loading: false });
      } catch (error) {
        console.error("Failed to load library data:", error);
        setData(prev => ({ ...prev, loading: false }));
      }
    };
    loadAllData();
  }, []);

  if (data.loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 text-green-600 animate-spin" />
          <p className="text-gray-600">Cultivating the Cannadex...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Cannadex</h1>
        <p className="text-gray-600">Explore the world of cannabis compounds and strains</p>
      </div>

      <Tabs defaultValue="cannabinoids" className="w-full">
        <TabsList className="grid w-full grid-cols-3 md:w-auto">
          <TabsTrigger value="cannabinoids" className="flex items-center gap-2">
            <Pill className="w-4 h-4" />
            Cannabinoids
          </TabsTrigger>
          <TabsTrigger value="terpenes" className="flex items-center gap-2">
            <TestTube2 className="w-4 h-4" />
            Terpenes
          </TabsTrigger>
          <TabsTrigger value="strains" className="flex items-center gap-2">
            <Leaf className="w-4 h-4" />
            Strains
          </TabsTrigger>
        </TabsList>
        <TabsContent value="cannabinoids">
          <CannabinoidCatalog cannabinoids={data.cannabinoids} />
        </TabsContent>
        <TabsContent value="terpenes">
          <TerpeneCatalog
            terpenes={data.terpenes}
            products={data.products}
            sessions={data.sessions}
            user={data.user}
          />
        </TabsContent>
        <TabsContent value="strains">
          <StrainCatalog
            products={data.products}
            sessions={data.sessions}
            inventory={data.inventory}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}