import React, { useState, useEffect } from "react";
import { Course, EBook, ResearchStudy, Recipe } from "@/entities/all";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { 
  GraduationCap, 
  BookOpen, 
  FlaskConical, 
  ChefHat,
  Loader2
} from "lucide-react";
import CourseSection from "../learn/CourseSection";
import EBookSection from "../learn/EBookSection";
import ResearchSection from "../learn/ResearchSection";
import RecipeSection from "../learn/RecipeSection";

export default function LearnTab() {
  const [data, setData] = useState({
    courses: [],
    ebooks: [],
    research: [],
    recipes: [],
    loading: true,
  });

  useEffect(() => {
    const loadAllData = async () => {
      try {
        const [courses, ebooks, research, recipes] = await Promise.all([
          Course.list("-created_date"),
          EBook.list("-created_date"),
          ResearchStudy.list("-publication_date"),
          Recipe.list("-created_date"),
        ]);
        
        setData({ 
          courses, 
          ebooks, 
          research, 
          recipes, 
          loading: false 
        });
      } catch (error) {
        console.error("Failed to load discovery content:", error);
        setData(prev => ({ ...prev, loading: false }));
      }
    };
    
    loadAllData();
  }, []);

  if (data.loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 text-green-600 animate-spin" />
          <p className="text-gray-600">Loading learning materials...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Learn & Grow</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Expand your knowledge from cultivation to consumption.
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-white/80 backdrop-blur-sm text-center">
            <CardContent className="p-4">
              <GraduationCap className="w-8 h-8 mx-auto mb-2 text-blue-600" />
              <p className="text-2xl font-bold">{data.courses.length}</p>
              <p className="text-sm text-gray-600">Courses</p>
            </CardContent>
          </Card>
          <Card className="bg-white/80 backdrop-blur-sm text-center">
            <CardContent className="p-4">
              <BookOpen className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <p className="text-2xl font-bold">{data.ebooks.length}</p>
              <p className="text-sm text-gray-600">E-Books</p>
            </CardContent>
          </Card>
          <Card className="bg-white/80 backdrop-blur-sm text-center">
            <CardContent className="p-4">
              <FlaskConical className="w-8 h-8 mx-auto mb-2 text-purple-600" />
              <p className="text-2xl font-bold">{data.research.length}</p>
              <p className="text-sm text-gray-600">Studies</p>
            </CardContent>
          </Card>
          <Card className="bg-white/80 backdrop-blur-sm text-center">
            <CardContent className="p-4">
              <ChefHat className="w-8 h-8 mx-auto mb-2 text-orange-600" />
              <p className="text-2xl font-bold">{data.recipes.length}</p>
              <p className="text-sm text-gray-600">Recipes</p>
            </CardContent>
          </Card>
      </div>

      {/* Content Tabs */}
      <Tabs defaultValue="courses" className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
          <TabsTrigger value="courses" className="flex items-center gap-2">
            <GraduationCap className="w-4 h-4" />
            <span className="hidden sm:inline">Courses</span>
          </TabsTrigger>
          <TabsTrigger value="ebooks" className="flex items-center gap-2">
            <BookOpen className="w-4 h-4" />
            <span className="hidden sm:inline">E-Books</span>
          </TabsTrigger>
          <TabsTrigger value="research" className="flex items-center gap-2">
            <FlaskConical className="w-4 h-4" />
            <span className="hidden sm:inline">Research</span>
          </TabsTrigger>
          <TabsTrigger value="recipes" className="flex items-center gap-2">
            <ChefHat className="w-4 h-4" />
            <span className="hidden sm:inline">Recipes</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="courses">
          <CourseSection courses={data.courses} />
        </TabsContent>
        
        <TabsContent value="ebooks">
          <EBookSection ebooks={data.ebooks} />
        </TabsContent>
        
        <TabsContent value="research">
          <ResearchSection studies={data.research} />
        </TabsContent>
        
        <TabsContent value="recipes">
          <RecipeSection recipes={data.recipes} />
        </TabsContent>
      </Tabs>
    </div>
  );
}