import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Store, Sparkles } from "lucide-react";
import { toast } from "sonner";

export default function AddDispensaryForm({ onSuccess, onCancel, suggestedData = null }) {
  const [saving, setSaving] = useState(false);
  
  const [formData, setFormData] = useState({
    name: suggestedData?.name || "",
    shop_type: "dispensary",
    address: suggestedData?.address || "",
    city: suggestedData?.city || "",
    state: suggestedData?.state || "",
    zip_code: suggestedData?.zip_code || "",
    phone: suggestedData?.phone || "",
    website: suggestedData?.website || "",
    license_type: "both",
    hours: suggestedData?.hours || "",
    notes: suggestedData?.notes || ""
  });

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    if (!formData.name) {
      toast.error("Please enter a shop name");
      return;
    }

    setSaving(true);
    try {
      await base44.entities.Dispensary.create(formData);
      toast.success("Shop added to your stash!");
      
      if (onSuccess) onSuccess();
    } catch (error) {
      console.error("Error saving shop:", error);
      toast.error("Failed to save shop");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg md:text-xl">
          <Store className="w-5 h-5 text-blue-600" />
          Add Shop
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {suggestedData && (
          <div className="p-4 bg-blue-50/80 rounded-lg glass-card border-blue-200/50 mb-4">
            <p className="text-sm text-gray-700">
              We found this shop from your product label. You can edit the details below.
            </p>
          </div>
        )}

        <div>
          <Label htmlFor="name">Shop Name *</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => handleInputChange('name', e.target.value)}
            placeholder="e.g., Green Valley Dispensary"
            className="mt-1 glass-card border-white/40"
          />
        </div>

        <div>
          <Label htmlFor="shop_type">Shop Type</Label>
          <Select value={formData.shop_type} onValueChange={(value) => handleInputChange('shop_type', value)}>
            <SelectTrigger className="mt-1 glass-card border-white/40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="glass-card border-white/40">
              <SelectItem value="dispensary">Dispensary</SelectItem>
              <SelectItem value="smoke_accessory_shop">Smoke/Accessory Shop</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {formData.shop_type === 'dispensary' && (
          <div>
            <Label htmlFor="license_type">License Type</Label>
            <Select value={formData.license_type} onValueChange={(value) => handleInputChange('license_type', value)}>
              <SelectTrigger className="mt-1 glass-card border-white/40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="glass-card border-white/40">
                <SelectItem value="medical">Medical Only</SelectItem>
                <SelectItem value="recreational">Recreational Only</SelectItem>
                <SelectItem value="both">Both</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}

        <div>
          <Label htmlFor="address">Address</Label>
          <Input
            id="address"
            value={formData.address}
            onChange={(e) => handleInputChange('address', e.target.value)}
            placeholder="123 Main Street"
            className="mt-1 glass-card border-white/40"
          />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <div>
            <Label htmlFor="city">City</Label>
            <Input
              id="city"
              value={formData.city}
              onChange={(e) => handleInputChange('city', e.target.value)}
              placeholder="Seattle"
              className="mt-1 glass-card border-white/40"
            />
          </div>
          <div>
            <Label htmlFor="state">State</Label>
            <Input
              id="state"
              value={formData.state}
              onChange={(e) => handleInputChange('state', e.target.value)}
              placeholder="WA"
              className="mt-1 glass-card border-white/40"
            />
          </div>
          <div>
            <Label htmlFor="zip_code">ZIP Code</Label>
            <Input
              id="zip_code"
              value={formData.zip_code}
              onChange={(e) => handleInputChange('zip_code', e.target.value)}
              placeholder="98101"
              className="mt-1 glass-card border-white/40"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="phone">Phone</Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={(e) => handleInputChange('phone', e.target.value)}
              placeholder="(555) 123-4567"
              className="mt-1 glass-card border-white/40"
            />
          </div>
          <div>
            <Label htmlFor="website">Website</Label>
            <Input
              id="website"
              value={formData.website}
              onChange={(e) => handleInputChange('website', e.target.value)}
              placeholder="https://..."
              className="mt-1 glass-card border-white/40"
            />
          </div>
        </div>

        <div>
          <Label htmlFor="hours">Hours</Label>
          <Textarea
            id="hours"
            value={formData.hours}
            onChange={(e) => handleInputChange('hours', e.target.value)}
            placeholder="Mon-Fri: 9am-9pm&#10;Sat-Sun: 10am-8pm"
            className="mt-1 min-h-[80px] glass-card border-white/40"
          />
        </div>

        <div>
          <Label htmlFor="notes">Notes</Label>
          <Textarea
            id="notes"
            value={formData.notes}
            onChange={(e) => handleInputChange('notes', e.target.value)}
            placeholder="Personal notes about this shop..."
            className="mt-1 min-h-[100px] glass-card border-white/40"
          />
        </div>

        <div className="flex gap-3 pt-4">
          <Button
            onClick={handleSubmit}
            disabled={saving}
            className="flex-1 bg-blue-600 hover:bg-blue-700 min-h-[48px]"
          >
            {saving ? (
              <>
                <span className="animate-spin mr-2">⏳</span>
                Adding...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Add to Stash
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}