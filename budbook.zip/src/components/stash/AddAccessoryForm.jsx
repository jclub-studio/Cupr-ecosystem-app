import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Package, Sparkles } from "lucide-react";
import { toast } from "sonner";

const CATEGORY_ICONS = {
  grinder: "⚙️",
  pipe: "🌿",
  bong: "💧",
  bubbler: "💨",
  rolling_papers: "📄",
  rolling_machine: "🎰",
  vaporizer_dry_herb: "💨",
  vaporizer_oil: "🔋",
  dab_rig: "🔥",
  torch: "🔥",
  lighter: "🔥",
  lighter_sleeve: "🎨",
  ashtray: "🗑️",
  storage_container: "📦",
  smell_proof_bag: "💼",
  travel_case: "🧳",
  cleaning_supplies: "🧼",
  odor_eliminator: "🌬️",
  extraction_machine: "⚗️",
  scales: "⚖️",
  room_decor: "🖼️",
  lighting: "💡",
  lava_lamp: "🌋",
  posters: "🖼️",
  furniture: "🪑",
  clothing: "👕",
  other: "✨"
};

const formatCategoryName = (category) => {
  return category.split('_').map(word => 
    word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');
};

export default function AddAccessoryForm({ onSuccess, onCancel }) {
  const [saving, setSaving] = useState(false);
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  
  const [formData, setFormData] = useState({
    name: "",
    category: "",
    brand: "",
    purchase_date: "",
    purchase_price: "",
    purchase_location: "",
    condition: "good",
    notes: "",
    is_favorite: false,
    image_url: ""
  });

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async () => {
    if (!formData.name || !formData.category) {
      toast.error("Please fill in name and category");
      return;
    }

    setSaving(true);
    try {
      let imageUrl = formData.image_url;
      
      if (imageFile) {
        const { file_url } = await base44.integrations.Core.UploadFile({ 
          file: imageFile 
        });
        imageUrl = file_url;
      }

      const accessoryData = {
        ...formData,
        image_url: imageUrl,
        purchase_price: formData.purchase_price ? Number(formData.purchase_price) : null
      };

      await base44.entities.Accessory.create(accessoryData);
      toast.success("Accessory added to your stash!");
      
      if (onSuccess) onSuccess();
    } catch (error) {
      console.error("Error saving accessory:", error);
      toast.error("Failed to save accessory");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg md:text-xl">
          <Package className="w-5 h-5 text-purple-600" />
          Add Accessory
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="name">Name *</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => handleInputChange('name', e.target.value)}
            placeholder="e.g., My favorite grinder"
            className="mt-1 glass-card border-white/40"
          />
        </div>

        <div>
          <Label htmlFor="category">Category *</Label>
          <Select value={formData.category} onValueChange={(value) => handleInputChange('category', value)}>
            <SelectTrigger className="mt-1 glass-card border-white/40">
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent className="glass-card border-white/40">
              {Object.keys(CATEGORY_ICONS).map(cat => (
                <SelectItem key={cat} value={cat}>
                  {CATEGORY_ICONS[cat]} {formatCategoryName(cat)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="brand">Brand</Label>
          <Input
            id="brand"
            value={formData.brand}
            onChange={(e) => handleInputChange('brand', e.target.value)}
            placeholder="e.g., Santa Cruz Shredder"
            className="mt-1 glass-card border-white/40"
          />
        </div>

        <div>
          <Label htmlFor="image">Photo</Label>
          <div className="mt-1 space-y-2">
            <Input
              id="image"
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="glass-card border-white/40"
            />
            {imagePreview && (
              <div className="relative rounded-lg overflow-hidden bg-gray-100">
                <img 
                  src={imagePreview} 
                  alt="Preview" 
                  className="w-full h-48 object-cover"
                />
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="purchase_date">Purchase Date</Label>
            <Input
              id="purchase_date"
              type="date"
              value={formData.purchase_date}
              onChange={(e) => handleInputChange('purchase_date', e.target.value)}
              className="mt-1 glass-card border-white/40"
            />
          </div>

          <div>
            <Label htmlFor="purchase_price">Purchase Price ($)</Label>
            <Input
              id="purchase_price"
              type="number"
              step="0.01"
              value={formData.purchase_price}
              onChange={(e) => handleInputChange('purchase_price', e.target.value)}
              placeholder="0.00"
              className="mt-1 glass-card border-white/40"
            />
          </div>
        </div>

        <div>
          <Label htmlFor="purchase_location">Purchase Location</Label>
          <Input
            id="purchase_location"
            value={formData.purchase_location}
            onChange={(e) => handleInputChange('purchase_location', e.target.value)}
            placeholder="e.g., Local smoke shop"
            className="mt-1 glass-card border-white/40"
          />
        </div>

        <div>
          <Label htmlFor="condition">Condition</Label>
          <Select value={formData.condition} onValueChange={(value) => handleInputChange('condition', value)}>
            <SelectTrigger className="mt-1 glass-card border-white/40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="glass-card border-white/40">
              <SelectItem value="new">New</SelectItem>
              <SelectItem value="like_new">Like New</SelectItem>
              <SelectItem value="good">Good</SelectItem>
              <SelectItem value="fair">Fair</SelectItem>
              <SelectItem value="needs_repair">Needs Repair</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="notes">Notes</Label>
          <Textarea
            id="notes"
            value={formData.notes}
            onChange={(e) => handleInputChange('notes', e.target.value)}
            placeholder="Any additional details about this accessory..."
            className="mt-1 min-h-[100px] glass-card border-white/40"
          />
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="is_favorite"
            checked={formData.is_favorite}
            onChange={(e) => handleInputChange('is_favorite', e.target.checked)}
            className="rounded border-gray-300"
          />
          <Label htmlFor="is_favorite" className="cursor-pointer">
            Mark as favorite
          </Label>
        </div>

        <div className="flex gap-3 pt-4">
          <Button
            onClick={handleSubmit}
            disabled={saving}
            className="flex-1 bg-purple-600 hover:bg-purple-700 min-h-[48px]"
          >
            {saving ? (
              <>
                <span className="animate-spin mr-2">⏳</span>
                Adding...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Add to Stash
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}