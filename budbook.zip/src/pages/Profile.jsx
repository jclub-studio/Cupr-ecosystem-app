
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Mail, 
  Calendar, 
  Shield, 
  Camera, 
  Loader2,
  AtSign,
  Leaf,
  Package,
  Store,
  Sparkles,
  ExternalLink,
  Droplet,
  MapPin,
  Phone,
  Globe
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Profile() {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  
  // Lists for favorites
  const [products, setProducts] = useState([]);
  const [accessories, setAccessories] = useState([]);
  const [dispensaries, setDispensaries] = useState([]);

  // Modal states for viewing favorites
  const [viewingFavorite, setViewingFavorite] = useState(null); // 'strain', 'accessory', 'dispensary'
  const [selectedItem, setSelectedItem] = useState(null);

  const [profileData, setProfileData] = useState({
    username: "",
    bio: "",
    profile_photo_url: "",
    favorite_strain_id: "",
    favorite_accessory_id: "",
    favorite_dispensary_id: ""
  });

  useEffect(() => {
    loadUserProfile();
  }, []);

  const loadUserProfile = async () => {
    try {
      const user = await base44.auth.me();
      setCurrentUser(user);

      // Load user's products, accessories, and dispensaries for favorites selection
      const [productsData, accessoriesData, dispensariesData] = await Promise.all([
        base44.entities.Product.list("-created_date"),
        base44.entities.Accessory.list("-created_date"),
        base44.entities.Dispensary.list("-created_date")
      ]);

      setProducts(productsData);
      setAccessories(accessoriesData);
      setDispensaries(dispensariesData);

      setProfileData({
        username: user.username || "",
        bio: user.bio || "",
        profile_photo_url: user.profile_photo_url || "",
        favorite_strain_id: user.favorite_strain_id || "",
        favorite_accessory_id: user.favorite_accessory_id || "",
        favorite_dispensary_id: user.favorite_dispensary_id || ""
      });
    } catch (error) {
      console.error("Error loading profile:", error);
      toast.error("Failed to load profile");
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field, value) => {
    setProfileData(prev => ({ ...prev, [field]: value }));
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setProfileData(prev => ({ ...prev, profile_photo_url: file_url }));
      toast.success("Photo uploaded successfully");
    } catch (error) {
      console.error("Error uploading photo:", error);
      toast.error("Failed to upload photo");
    } finally {
      setUploading(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!profileData.username.trim()) {
      toast.error("Username is required");
      return;
    }

    setSaving(true);
    try {
      await base44.auth.updateMe({
        username: profileData.username,
        bio: profileData.bio,
        profile_photo_url: profileData.profile_photo_url,
        favorite_strain_id: profileData.favorite_strain_id || null,
        favorite_accessory_id: profileData.favorite_accessory_id || null,
        favorite_dispensary_id: profileData.favorite_dispensary_id || null
      });

      toast.success("Profile updated successfully");
      await loadUserProfile();
    } catch (error) {
      console.error("Error saving profile:", error);
      toast.error(error.message || "Failed to save profile");
    } finally {
      setSaving(false);
    }
  };

  const handleLogout = () => {
    base44.auth.logout();
  };

  // Helper functions to get full objects
  const getFavoriteStrain = () => {
    if (!profileData.favorite_strain_id) return null;
    return products.find(p => p.id === profileData.favorite_strain_id);
  };

  const getFavoriteAccessory = () => {
    if (!profileData.favorite_accessory_id) return null;
    return accessories.find(a => a.id === profileData.favorite_accessory_id);
  };

  const getFavoriteDispensary = () => {
    if (!profileData.favorite_dispensary_id) return null;
    return dispensaries.find(d => d.id === profileData.favorite_dispensary_id);
  };

  // Handle clicking on favorites
  const handleViewFavorite = (type) => {
    let item = null;
    if (type === 'strain') {
      item = getFavoriteStrain();
    } else if (type === 'accessory') {
      item = getFavoriteAccessory();
    } else if (type === 'dispensary') {
      item = getFavoriteDispensary();
    }

    if (item) {
      setSelectedItem(item);
      setViewingFavorite(type);
    }
  };

  const typeColors = {
    indica: "bg-purple-100 text-purple-800",
    sativa: "bg-green-100 text-green-800",
    hybrid: "bg-blue-100 text-blue-800"
  };

  const categoryColors = {
    flower: "bg-green-100 text-green-800",
    concentrate: "bg-amber-100 text-amber-800",
    edible: "bg-red-100 text-red-800",
    vape: "bg-blue-100 text-blue-800",
    other: "bg-gray-100 text-gray-800"
  };

  if (loading) {
    return (
      <div className="min-h-screen p-6 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-green-600" />
      </div>
    );
  }

  const favoriteStrain = getFavoriteStrain();
  const favoriteAccessory = getFavoriteAccessory();
  const favoriteDispensary = getFavoriteDispensary();

  return (
    <div className="min-h-screen p-3 md:p-6 pb-24 md:pb-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Profile Header */}
        <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
          <CardContent className="p-6 md:p-8">
            <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
              {/* Avatar */}
              <Avatar className="w-24 h-24 md:w-32 md:h-32 ring-4 ring-green-100 shadow-lg">
                <AvatarImage src={profileData.profile_photo_url} alt={currentUser?.full_name} />
                <AvatarFallback className="bg-gradient-to-br from-green-400 to-green-600 text-white text-2xl md:text-3xl font-bold">
                  {currentUser?.full_name?.charAt(0) || currentUser?.email?.charAt(0)}
                </AvatarFallback>
              </Avatar>

              {/* User Info */}
              <div className="flex-1 text-center md:text-left space-y-4">
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-1">
                    {currentUser?.full_name}
                  </h1>
                  {profileData.username && (
                    <p className="text-gray-600 flex items-center justify-center md:justify-start gap-2">
                      <AtSign className="w-4 h-4" />
                      {profileData.username}
                    </p>
                  )}
                </div>

                {profileData.bio && (
                  <p className="text-gray-700 leading-relaxed">{profileData.bio}</p>
                )}

                <div className="flex flex-wrap gap-3 justify-center md:justify-start">
                  <Badge variant="outline" className="glass-card border-white/40 gap-2 px-3 py-1.5">
                    <Mail className="w-3 h-3" />
                    {currentUser?.email}
                  </Badge>
                  <Badge variant="outline" className="glass-card border-white/40 gap-2 px-3 py-1.5">
                    <Shield className="w-3 h-3" />
                    {currentUser?.role === 'admin' ? 'Admin' : 'User'}
                  </Badge>
                  <Badge variant="outline" className="glass-card border-white/40 gap-2 px-3 py-1.5">
                    <Calendar className="w-3 h-3" />
                    Since {format(new Date(currentUser?.created_date), 'MMM yyyy')}
                  </Badge>
                </div>

                {/* Favorite Highlights */}
                <div className="space-y-2 pt-4 border-t border-white/30">
                  <h3 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-yellow-500" />
                    Profile Highlights
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {favoriteStrain && (
                      <button
                        onClick={() => handleViewFavorite('strain')}
                        className="glass-card border-green-200/50 bg-green-50/50 rounded-lg p-3 hover:shadow-md hover:scale-105 transition-all duration-200 cursor-pointer text-left"
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <Leaf className="w-3 h-3 text-green-600" />
                          <span className="text-xs text-gray-600">Favorite Strain</span>
                        </div>
                        <p className="text-sm font-semibold text-gray-900 truncate">{favoriteStrain.name}</p>
                      </button>
                    )}
                    {favoriteAccessory && (
                      <button
                        onClick={() => handleViewFavorite('accessory')}
                        className="glass-card border-purple-200/50 bg-purple-50/50 rounded-lg p-3 hover:shadow-md hover:scale-105 transition-all duration-200 cursor-pointer text-left"
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <Package className="w-3 h-3 text-purple-600" />
                          <span className="text-xs text-gray-600">Favorite Accessory</span>
                        </div>
                        <p className="text-sm font-semibold text-gray-900 truncate">{favoriteAccessory.name}</p>
                      </button>
                    )}
                    {favoriteDispensary && (
                      <button
                        onClick={() => handleViewFavorite('dispensary')}
                        className="glass-card border-blue-200/50 bg-blue-50/50 rounded-lg p-3 hover:shadow-md hover:scale-105 transition-all duration-200 cursor-pointer text-left"
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <Store className="w-3 h-3 text-blue-600" />
                          <span className="text-xs text-gray-600">Favorite Shop</span>
                        </div>
                        <p className="text-sm font-semibold text-gray-900 truncate">{favoriteDispensary.name}</p>
                      </button>
                    )}
                  </div>
                  {!favoriteStrain && !favoriteAccessory && !favoriteDispensary && (
                    <p className="text-sm text-gray-500 italic">No favorites set yet - add them in edit mode!</p>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Profile Tabs */}
        <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
          <CardHeader>
            <CardTitle>Profile Settings</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="profile" className="w-full">
              <TabsList className="grid w-full grid-cols-2 glass-card p-1">
                <TabsTrigger value="profile">Edit Profile</TabsTrigger>
                <TabsTrigger value="account">Account</TabsTrigger>
              </TabsList>

              <TabsContent value="profile" className="space-y-6 pt-6">
                {/* Profile Photo */}
                <div className="space-y-3">
                  <Label htmlFor="photo" className="text-sm font-medium">Profile Photo</Label>
                  <div className="flex items-center gap-4">
                    <Avatar className="w-20 h-20 ring-2 ring-gray-200">
                      <AvatarImage src={profileData.profile_photo_url} />
                      <AvatarFallback className="bg-gradient-to-br from-green-400 to-green-600 text-white text-xl font-bold">
                        {currentUser?.full_name?.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <input
                        type="file"
                        id="photo"
                        accept="image/*"
                        onChange={handlePhotoUpload}
                        className="hidden"
                      />
                      <Button
                        variant="outline"
                        onClick={() => document.getElementById('photo').click()}
                        disabled={uploading}
                        className="glass-card border-white/40"
                      >
                        {uploading ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Uploading...
                          </>
                        ) : (
                          <>
                            <Camera className="w-4 h-4 mr-2" />
                            Change Photo
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Username */}
                <div className="space-y-3">
                  <Label htmlFor="username" className="text-sm font-medium">Username *</Label>
                  <Input
                    id="username"
                    value={profileData.username}
                    onChange={(e) => handleInputChange('username', e.target.value)}
                    placeholder="your_username"
                    className="glass-card border-white/40"
                  />
                  <p className="text-xs text-gray-500">Your unique username for friend discovery</p>
                </div>

                {/* Bio */}
                <div className="space-y-3">
                  <Label htmlFor="bio" className="text-sm font-medium">Bio</Label>
                  <Textarea
                    id="bio"
                    value={profileData.bio}
                    onChange={(e) => handleInputChange('bio', e.target.value)}
                    placeholder="Tell us about yourself..."
                    rows={4}
                    className="glass-card border-white/40"
                  />
                </div>

                {/* Favorite Highlights */}
                <div className="space-y-4 pt-4 border-t border-white/30">
                  <h3 className="text-base font-semibold text-gray-900 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-yellow-500" />
                    Profile Highlights
                  </h3>

                  {/* Favorite Strain */}
                  <div className="space-y-2">
                    <Label htmlFor="favorite_strain" className="text-sm font-medium flex items-center gap-2">
                      <Leaf className="w-4 h-4 text-green-600" />
                      Favorite Strain
                    </Label>
                    <Select 
                      value={profileData.favorite_strain_id} 
                      onValueChange={(value) => handleInputChange('favorite_strain_id', value)}
                    >
                      <SelectTrigger id="favorite_strain" className="glass-card border-white/40">
                        <SelectValue placeholder="Select your favorite strain" />
                      </SelectTrigger>
                      <SelectContent className="glass-card border-white/40">
                        <SelectItem value="null">None</SelectItem>
                        {products.map(product => (
                          <SelectItem key={product.id} value={product.id}>
                            {product.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Favorite Accessory */}
                  <div className="space-y-2">
                    <Label htmlFor="favorite_accessory" className="text-sm font-medium flex items-center gap-2">
                      <Package className="w-4 h-4 text-purple-600" />
                      Favorite Accessory
                    </Label>
                    <Select 
                      value={profileData.favorite_accessory_id} 
                      onValueChange={(value) => handleInputChange('favorite_accessory_id', value)}
                    >
                      <SelectTrigger id="favorite_accessory" className="glass-card border-white/40">
                        <SelectValue placeholder="Select your favorite accessory" />
                      </SelectTrigger>
                      <SelectContent className="glass-card border-white/40">
                        <SelectItem value="null">None</SelectItem>
                        {accessories.map(accessory => (
                          <SelectItem key={accessory.id} value={accessory.id}>
                            {accessory.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Favorite Shop */}
                  <div className="space-y-2">
                    <Label htmlFor="favorite_dispensary" className="text-sm font-medium flex items-center gap-2">
                      <Store className="w-4 h-4 text-blue-600" />
                      Favorite Shop
                    </Label>
                    <Select 
                      value={profileData.favorite_dispensary_id} 
                      onValueChange={(value) => handleInputChange('favorite_dispensary_id', value)}
                    >
                      <SelectTrigger id="favorite_dispensary" className="glass-card border-white/40">
                        <SelectValue placeholder="Select your favorite shop" />
                      </SelectTrigger>
                      <SelectContent className="glass-card border-white/40">
                        <SelectItem value="null">None</SelectItem>
                        {dispensaries.map(dispensary => (
                          <SelectItem key={dispensary.id} value={dispensary.id}>
                            {dispensary.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button 
                  onClick={handleSaveProfile} 
                  disabled={saving}
                  className="w-full bg-green-600/90 hover:bg-green-700/90 shadow-lg min-h-[44px]"
                >
                  {saving ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    'Save Profile'
                  )}
                </Button>
              </TabsContent>

              <TabsContent value="account" className="space-y-6 pt-6">
                {/* Account Info - Read Only */}
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Email Address</Label>
                    <p className="mt-1 text-gray-900">{currentUser?.email}</p>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-700">Account Role</Label>
                    <p className="mt-1 text-gray-900">{currentUser?.role === 'admin' ? 'Administrator' : 'User'}</p>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-700">Member Since</Label>
                    <p className="mt-1 text-gray-900">
                      {format(new Date(currentUser?.created_date), 'MMMM d, yyyy')}
                    </p>
                  </div>
                </div>

                <div className="pt-6 border-t border-white/30">
                  <Button 
                    onClick={handleLogout}
                    variant="destructive"
                    className="w-full min-h-[44px]"
                  >
                    Log Out
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Favorite Strain Brief Modal */}
        <Dialog open={viewingFavorite === 'strain'} onOpenChange={(open) => !open && setViewingFavorite(null)}>
          <DialogContent className="glass-card border-white/40 max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-xl">
                <Leaf className="w-5 h-5 text-green-600" />
                {selectedItem?.name}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              {selectedItem?.brand && (
                <p className="text-gray-600">{selectedItem.brand}</p>
              )}
              <div className="flex gap-2 flex-wrap">
                {selectedItem?.type && (
                  <Badge className={typeColors[selectedItem.type.toLowerCase()] || "bg-gray-100 text-gray-800"}>
                    {selectedItem.type}
                  </Badge>
                )}
                {selectedItem?.category && (
                  <Badge className={categoryColors[selectedItem.category.toLowerCase()] || "bg-gray-100 text-gray-800"}>
                    {selectedItem.category}
                  </Badge>
                )}
              </div>
              {(selectedItem?.thc_percentage > 0 || selectedItem?.cbd_percentage > 0) && (
                <div className="flex items-center gap-3 pt-2 border-t border-white/30">
                  <Droplet className="w-4 h-4 text-gray-400" />
                  <div className="flex gap-3">
                    {selectedItem.thc_percentage > 0 && (
                      <span className="text-sm font-semibold text-red-600">THC {selectedItem.thc_percentage}%</span>
                    )}
                    {selectedItem.cbd_percentage > 0 && (
                      <span className="text-sm font-semibold text-green-600">CBD {selectedItem.cbd_percentage}%</span>
                    )}
                  </div>
                </div>
              )}
              <Link to={createPageUrl("MyStash")}>
                <Button className="w-full bg-green-600 hover:bg-green-700 gap-2 mt-4">
                  <ExternalLink className="w-4 h-4" />
                  View in My Stash
                </Button>
              </Link>
            </div>
          </DialogContent>
        </Dialog>

        {/* Favorite Accessory Brief Modal */}
        <Dialog open={viewingFavorite === 'accessory'} onOpenChange={(open) => !open && setViewingFavorite(null)}>
          <DialogContent className="glass-card border-white/40 max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-xl">
                <Package className="w-5 h-5 text-purple-600" />
                {selectedItem?.name}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              {selectedItem?.brand && (
                <p className="text-gray-600">{selectedItem.brand}</p>
              )}
              {selectedItem?.category && (
                <Badge className="bg-purple-100 text-purple-800">
                  {selectedItem.category.split('_').map(word => 
                    word.charAt(0).toUpperCase() + word.slice(1)
                  ).join(' ')}
                </Badge>
              )}
              {selectedItem?.condition && (
                <div className="pt-2 border-t border-white/30">
                  <p className="text-sm text-gray-600">Condition: <span className="font-medium text-gray-900">{selectedItem.condition}</span></p>
                </div>
              )}
              <Link to={createPageUrl("MyStash") + "?tab=accessories"}>
                <Button className="w-full bg-purple-600 hover:bg-purple-700 gap-2 mt-4">
                  <ExternalLink className="w-4 h-4" />
                  View in Accessories
                </Button>
              </Link>
            </div>
          </DialogContent>
        </Dialog>

        {/* Favorite Dispensary Brief Modal */}
        <Dialog open={viewingFavorite === 'dispensary'} onOpenChange={(open) => !open && setViewingFavorite(null)}>
          <DialogContent className="glass-card border-white/40 max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-xl">
                <Store className="w-5 h-5 text-blue-600" />
                {selectedItem?.name}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              {selectedItem?.address && (
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-gray-400 mt-1" />
                  <p className="text-sm text-gray-600">{selectedItem.address}</p>
                </div>
              )}
              {(selectedItem?.city || selectedItem?.state) && (
                <p className="text-sm text-gray-600 ml-6">
                  {[selectedItem.city, selectedItem.state].filter(Boolean).join(', ')}
                </p>
              )}
              {selectedItem?.phone && (
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-gray-400" />
                  <p className="text-sm text-gray-600">{selectedItem.phone}</p>
                </div>
              )}
              {selectedItem?.website && (
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-gray-400" />
                  <a href={selectedItem.website} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-600 hover:underline">
                    Visit Website
                  </a>
                </div>
              )}
              <Link to={createPageUrl("MyStash") + "?tab=shops"}>
                <Button className="w-full bg-blue-600 hover:bg-blue-700 gap-2 mt-4">
                  <ExternalLink className="w-4 h-4" />
                  View in My Shops
                </Button>
              </Link>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
