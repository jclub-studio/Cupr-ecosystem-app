import React, { useState, useEffect } from "react";
import { User, Session, SocialPost } from "@/entities/all";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Send } from "lucide-react";

export default function NewPost() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [content, setContent] = useState("");
  const [isPublic, setIsPublic] = useState(true);
  const [linkedSessionId, setLinkedSessionId] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [userData, sessionData] = await Promise.all([
          User.me(),
          Session.list("-date"),
        ]);
        setCurrentUser(userData);
        setSessions(sessionData);
      } catch (err) {
        setError("You must be logged in to create a post.");
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!content.trim()) {
      setError("Post content cannot be empty.");
      return;
    }
    if (!currentUser) {
      setError("Could not identify user. Please log in again.");
      return;
    }

    setSaving(true);
    setError(null);

    try {
      await SocialPost.create({
        content,
        visibility: isPublic ? "public" : "private",
        session_id: linkedSessionId || null,
        author_name: currentUser.full_name,
      });
      navigate(createPageUrl("Discover"));
    } catch (err) {
      setError(err.message || "Failed to create post.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50/30 to-blue-50/30 p-6">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Create a New Post</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}
              
              <div>
                <Label htmlFor="content">What's on your mind?</Label>
                <Textarea
                  id="content"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Share your experience, ask a question, or post an update..."
                  className="mt-2 min-h-32"
                />
              </div>

              <div>
                <Label htmlFor="session">Link a Session (Optional)</Label>
                <Select value={linkedSessionId} onValueChange={setLinkedSessionId}>
                  <SelectTrigger id="session" className="mt-2">
                    <SelectValue placeholder="Select a past session to share" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>None</SelectItem>
                    {sessions.map(s => (
                      <SelectItem key={s.id} value={s.id}>
                        {new Date(s.date).toLocaleString()} - Rating: {s.rating}/5
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="visibility-switch" className="flex flex-col gap-1">
                  <span>Post Visibility</span>
                  <span className="text-xs font-normal text-gray-500">
                    {isPublic ? "Visible to everyone." : "Visible to friends only."}
                  </span>
                </Label>
                <Switch
                  id="visibility-switch"
                  checked={isPublic}
                  onCheckedChange={setIsPublic}
                />
              </div>

              <div className="flex justify-end">
                <Button type="submit" disabled={saving}>
                  {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
                  {saving ? "Posting..." : "Post"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}