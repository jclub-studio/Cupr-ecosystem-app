
import React, { useState, useRef } from "react";
import { Product, UserInventory, Dispensary, Terpene, Brand } from "@/entities/all"; // Added Brand entity
import { InvokeLLM, UploadFile } from "@/integrations/Core";
import { ProductIdentification } from "@/functions/ProductIdentification";
import { getStrainTerpenes } from "@/functions/getStrainTerpenes";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  QrCode,
  Camera,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Plus,
  Upload,
  Edit3,
  Store,
  Box,
  Calendar,
  Archive,
  Leaf,
  Package,
  ArrowRight,
  ArrowLeft
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import AddAccessoryForm from "@/components/stash/AddAccessoryForm";
import AddDispensaryForm from "@/components/stash/AddDispensaryForm";

const PRODUCT_CATEGORIES = [
  { value: "flower", label: "Flower" },
  { value: "preroll", label: "Pre-roll" },
  { value: "blunt", label: "Blunt" },
  { value: "edible", label: "Edible" },
  { value: "vape", label: "Vape" },
  { value: "cartridge", label: "Cartridge" },
  { value: "tincture", label: "Tincture" },
  { value: "topical", label: "Topical" },
  { value: "oil", label: "Oil" },
  { value: "concentrate", label: "Concentrate" },
  { value: "capsule", label: "Capsule" },
  { value: "drink", label: "Drink" },
  { value: "other", label: "Other" }
];

// A local wrapper for the existing imports to match the 'base44' API pattern from the outline
// In a real application, 'base44' would typically be imported as a global object or context provider.
const base44 = {
  entities: {
    Product: Product,
    UserInventory: UserInventory,
    Dispensary: Dispensary,
    Terpene: Terpene,
    Brand: Brand,
  },
  integrations: {
    Core: {
      InvokeLLM: InvokeLLM,
      UploadFile: UploadFile,
    },
  },
  functions: {
    invoke: async (name, args) => {
      if (name === 'ProductIdentification') {
        return ProductIdentification(args);
      }
      if (name === 'getStrainTerpenes') {
        return getStrainTerpenes(args);
      }
      throw new Error(`base44.functions.invoke: Unknown function name: ${name}`);
    },
  },
};

export default function Scanner() {
  const navigate = useNavigate();

  // Initial selection state
  const [itemType, setItemType] = useState(null); // 'cannabis', 'accessory', 'dispensary'

  // Cannabis product states
  const [activeMethod, setActiveMethod] = useState("photo");
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState(null);
  const [manualUrl, setManualUrl] = useState("");
  const [extractedData, setExtractedData] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const videoRef = useRef(null);
  const streamRef = useRef(null);

  const [selectedFile, setSelectedFile] = useState(null);
  const [processingPhoto, setProcessingPhoto] = useState(false);
  const [processingTerpenes, setProcessingTerpenes] = useState(false);
  const [isLabAnalysisSource, setIsLabAnalysisSource] = useState(false);

  const [manualData, setManualData] = useState({
    strain_name: "",
    brand: "",
    brand_id: "", // New field for brand ID
    type: "hybrid",
    category: "flower",
    amount: "",
    thc_percentage: 0,
    thca_percentage: 0,
    cbd_percentage: 0,
    cbda_percentage: 0,
    cbg_percentage: 0,
    cbn_percentage: 0,
    purchase_price: 0,
    dispensary_id: "",
    packed_date: "",
    expiration_date: "",
    notes: ""
  });

  const [dispensaries, setDispensaries] = useState([]);
  const [brands, setBrands] = useState([]); // New state for brands
  const [terpenes, setTerpenes] = useState([]);
  const [terpeneSearch, setTerpeneSearch] = useState("");
  const [selectedTerpenes, setSelectedTerpenes] = useState([]);

  const captureInputRef = useRef(null);
  const fileInputRef = useRef(null);

  const [showDispensaryModal, setShowDispensaryModal] = useState(false);
  const [showBrandModal, setShowBrandModal] = useState(false); // New state for brand modal
  const [suggestedDispensary, setSuggestedDispensary] = useState(null);
  const [suggestedBrand, setSuggestedBrand] = useState(null); // New state for suggested brand
  const [dispensaryFormData, setDispensaryFormData] = useState({
    name: "",
    shop_type: "dispensary",
    address: "",
    city: "",
    state: "",
    zip_code: "",
    phone: "",
    website: "",
    license_type: "both",
    hours: "",
    notes: ""
  });

  const [brandFormData, setBrandFormData] = useState({ // New state for brand form
    name: "",
    primary_categories: [],
    description: "",
    market_tier: "mid-tier",
    website: ""
  });

  React.useEffect(() => {
    if (itemType === 'cannabis') {
      loadDispensariesBrandsAndTerpenes(); // Renamed function
    }
  }, [itemType]);

  // Renamed to include Brands
  const loadDispensariesBrandsAndTerpenes = async () => {
    try {
      const [dispensariesData, brandsData, terpenesData] = await Promise.all([
        base44.entities.Dispensary.list(),
        base44.entities.Brand.list("-popularity_score"), // Fetch brands
        base44.entities.Terpene.list()
      ]);

      // The original line `setManualData(prev => ({ ...prev, terpene_profile: [] }));`
      // is removed as `manualData` does not directly manage `terpene_profile`, `selectedTerpenes` does.

      setDispensaries(dispensariesData);
      setBrands(brandsData); // Set brands state
      setTerpenes(terpenesData);
    } catch (error) {
      console.error("Error loading data:", error);
    }
  };

  const startCamera = async () => {
    try {
      setIsScanning(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      setError("Unable to access camera. Please check permissions.");
      setIsScanning(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsScanning(false);
  };

  const processQRData = async (qrData) => {
    setIsProcessing(true);
    setError(null);
    setExtractedData(null);
    setIsLabAnalysisSource(false);

    try {
      // Changed to use base44.integrations.Core.InvokeLLM
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Extract cannabis product information from this QR code data or lab analysis URL: "${qrData}".

        If this appears to be a URL to lab analysis, indicate that. If it contains direct product data, extract it.
        Focus on: product name, brand, type (indica/sativa/hybrid), THC %, CBD %, terpene profile, test dates, batch numbers.

        Return in this exact JSON format:`,
        response_json_schema: {
          type: "object",
          properties: {
            is_lab_url: { type: "boolean" },
            product_name: { type: "string" },
            brand: { type: "string" },
            type: { type: "string", enum: ["indica", "sativa", "hybrid"] },
            category: { type: "string", enum: PRODUCT_CATEGORIES.map(c => c.value) },
            thc_percentage: { type: "number" },
            thca_percentage: { type: "number" },
            cbd_percentage: { type: "number" },
            cbda_percentage: { type: "number" },
            cbg_percentage: { type: "number" },
            cbn_percentage: { type: "number" },
            terpene_profile: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  terpene_name: { type: "string" },
                  percentage: { type: "number" }
                }
              }
            },
            test_date: { type: "string" },
            harvest_date: { type: "string" },
            batch_number: { type: "string" },
            lab_analysis_url: { type: "string" }
          }
        }
      });

      setExtractedData({
        ...result,
        qr_data: qrData
      });

      if (result && (result.is_lab_url || result.lab_analysis_url)) {
        setIsLabAnalysisSource(true);
      }

    } catch (err) {
      setError("Failed to process QR code data. Please try again or enter details manually.");
      console.error("Error processing QR data:", err);
    }

    setIsProcessing(false);
  };

  const handleManualEntry = () => {
    if (!manualUrl.trim()) {
      setError("Please enter a valid URL");
      return;
    }
    processQRData(manualUrl);
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
      setSelectedFile(file);
      setError(null);
      processPhotoLabel(file);
    } else {
      setError("Please select a valid image file.");
      setSelectedFile(null);
    }
  };

  const processPhotoLabel = async (fileToProcess) => {
    if (!fileToProcess) {
      setError("No image selected for processing.");
      return;
    }

    setProcessingPhoto(true);
    setError(null);
    setIsLabAnalysisSource(false);
    console.log('Starting photo processing...');

    try {
      // Changed to use base44.integrations.Core.UploadFile
      const uploadResponse = await base44.integrations.Core.UploadFile({ file: fileToProcess });
      console.log('Upload response:', uploadResponse);

      if (!uploadResponse.file_url) {
        throw new Error('Failed to upload file - no URL returned');
      }

      console.log('Calling ProductIdentification with URL:', uploadResponse.file_url);
      // Changed to use base44.functions.invoke
      const extractResponse = await base44.functions.invoke('ProductIdentification', { image_url: uploadResponse.file_url });
      console.log('Extract response:', extractResponse);

      // Adjusted error handling for base44 invoke structure
      if (extractResponse.status !== 200) {
        const errorText = extractResponse.data?.error || JSON.stringify(extractResponse);
        console.error('Extract API error:', errorText);
        throw new Error(`API Error: ${extractResponse.status} - ${errorText}`);
      }

      const { data } = extractResponse; // `data` is now directly from `extractResponse`
      console.log('Extraction data:', data);

      if (data.error) {
        throw new Error(data.error);
      }

      if (data.structured_data) {
        const sd = data.structured_data;
        const extractedManualData = {
          strain_name: sd.strain_name || "",
          brand: sd.brand || "",
          brand_id: sd.brand_id || "", // Populate brand_id from structured data
          type: sd.type || "hybrid",
          category: sd.category || "flower",
          amount: sd.amount || "",
          thc_percentage: sd.thc_percentage || 0,
          thca_percentage: sd.thca_percentage || 0,
          cbd_percentage: sd.cbd_percentage || 0,
          cbda_percentage: sd.cbda_percentage || 0,
          cbg_percentage: sd.cbg_percentage || 0,
          cbn_percentage: sd.cbn_percentage || 0,
          packed_date: sd.packed_date ? sd.packed_date.split('T')[0] : "",
          expiration_date: sd.expiration_date ? sd.expiration_date.split('T')[0] : "",
          purchase_price: 0,
          dispensary_id: sd.dispensary_id || "",
          notes: `Extracted from label via Vision AI. Raw text: ${data.raw_text ? data.raw_text.substring(0, 200) + (data.raw_text.length > 200 ? '...' : '') : ''}`
        };

        setManualData(extractedManualData);

        setSelectedTerpenes([]);

        setActiveMethod('manual');
        setError(null);

        // Handle brand suggestion logic
        if (sd.brand && !sd.brand_matched && !sd.brand_id) {
          setSuggestedBrand({
            name: sd.brand,
            original_name: sd.brand
          });
          setBrandFormData(prev => ({
            ...prev,
            name: sd.brand,
            primary_categories: [sd.category] || [] // Pre-fill category if available
          }));
          setShowBrandModal(true);
        }

        if (sd.is_new_dispensary && sd.suggested_dispensary_name) {
          setSuggestedDispensary({
            name: sd.suggested_dispensary_name,
            original_name: sd.suggested_dispensary_name
          });
          setDispensaryFormData(prev => ({
            ...prev,
            name: sd.suggested_dispensary_name
          }));
          setShowDispensaryModal(true);
        }

        console.log('Successfully extracted data, switching to manual entry tab');

        if (extractedManualData.strain_name && extractedManualData.strain_name.trim().length > 2) {
          console.log(`🧬 Starting async terpene search for: "${extractedManualData.strain_name}"`);
          setProcessingTerpenes(true);

          try {
            // Changed to use base44.functions.invoke
            const terpeneResponse = await base44.functions.invoke('getStrainTerpenes', { strain_name: extractedManualData.strain_name });
            console.log('Terpene response:', terpeneResponse);

            if (terpeneResponse.status === 200 && terpeneResponse.data) {
              const { terpenes } = terpeneResponse.data;
              if (terpenes && Array.isArray(terpenes) && terpenes.length > 0) {
                console.log(`✅ Found ${terpenes.length} terpenes:`, terpenes.map(t => t.terpene_name).join(', '));
                setSelectedTerpenes(terpenes);
              } else {
                console.log(`ℹ️ No terpenes found for strain "${extractedManualData.strain_name}"`);
              }
            } else {
              console.log(`⚠️ Terpene search returned non-success status: ${terpeneResponse.status}`);
            }
          } catch (terpeneError) {
            console.error(`❌ Async terpene search failed: ${terpeneError.message}`);
          } finally {
            setProcessingTerpenes(false);
          }
        } else {
          console.log(`ℹ️ Skipping terpene search - strain name too short or empty: "${extractedManualData.strain_name}"`);
        }

      } else {
        throw new Error("Could not extract product information from the image. Please try a clearer photo or enter details manually.");
      }

    } catch (err) {
      console.error("Photo processing error:", err);
      setError(err.message || "Failed to process photo. Please try again with a clearer image.");
    } finally {
      setProcessingPhoto(false);
      setSelectedFile(null);
      if (captureInputRef.current) captureInputRef.current.value = null;
      if (fileInputRef.current) fileInputRef.current.value = null;
    }
  };

  const handleManualDataChange = (field, value) => {
    setManualData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addTerpene = (terpene) => {
    if (!selectedTerpenes.find(t => t.terpene_name === terpene.name)) {
      setSelectedTerpenes(prev => [...prev, { terpene_name: terpene.name, percentage: 0 }]);
    }
    setTerpeneSearch("");
  };

  const updateTerpenePercentage = (terpName, percentage) => {
    setSelectedTerpenes(prev => prev.map(t =>
      t.terpene_name === terpName ? { ...t, percentage: parseFloat(percentage) || 0 } : t
    ));
  };

  const removeTerpene = (terpName) => {
    setSelectedTerpenes(prev => prev.filter(t => t.terpene_name !== terpName));
  };

  const handleDispensaryFormChange = (field, value) => {
    setDispensaryFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleAddNewDispensary = async () => {
    try {
      if (!dispensaryFormData.name.trim()) {
        setError("Dispensary name is required");
        return;
      }

      const newDispensary = await base44.entities.Dispensary.create(dispensaryFormData); // Changed to base44.entities.Dispensary

      setDispensaries(prev => [newDispensary, ...prev]);
      setManualData(prev => ({
        ...prev,
        dispensary_id: newDispensary.id
      }));

      setShowDispensaryModal(false);
      setSuggestedDispensary(null);
      setDispensaryFormData({
        name: "",
        shop_type: "dispensary",
        address: "",
        city: "",
        state: "",
        zip_code: "",
        phone: "",
        website: "",
        license_type: "both",
        hours: "",
        notes: ""
      });

      setError(null);
      console.log(`Added ${newDispensary.name} to your dispensaries!`);
    } catch (err) {
      console.error("Error adding dispensary:", err);
      setError("Failed to add dispensary. Please try again.");
    }
  };

  const handleDeclineDispensary = () => {
    setShowDispensaryModal(false);
    setSuggestedDispensary(null);
  };

  // New functions for brand management
  const handleBrandFormChange = (field, value) => {
    setBrandFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleAddNewBrand = async () => {
    try {
      if (!brandFormData.name.trim()) {
        setError("Brand name is required");
        return;
      }

      if (!brandFormData.primary_categories || brandFormData.primary_categories.length === 0) {
        setError("At least one product category is required");
        return;
      }

      const newBrand = await base44.entities.Brand.create(brandFormData); // Changed to base44.entities.Brand

      setBrands(prev => [newBrand, ...prev]);
      setManualData(prev => ({
        ...prev,
        brand_id: newBrand.id,
        brand: newBrand.name
      }));

      setShowBrandModal(false);
      setSuggestedBrand(null);
      setBrandFormData({
        name: "",
        primary_categories: [],
        description: "",
        market_tier: "mid-tier",
        website: ""
      });

      setError(null);
      // The outline suggested `toast.success`, but `toast` is not imported. Using console.log instead.
      console.log(`Added ${newBrand.name} to brands!`);
    } catch (err) {
      console.error("Error adding brand:", err);
      setError("Failed to add brand. Please try again.");
    }
  };

  const handleDeclineBrand = () => {
    setShowBrandModal(false);
    setSuggestedBrand(null);
  };


  const saveProduct = async (productInfo, type = "scanner") => {
    try {
      if (!productInfo.strain_name) {
        setError("Strain Name is required");
        return;
      }

      if (!productInfo.amount || productInfo.amount.trim() === "") {
        setError("Amount is required to save the product to your stash. Please specify how much product you have (e.g., 1g, 1/8 oz, 500mg).");
        return;
      }

      const generatedName = [productInfo.brand, productInfo.strain_name, productInfo.category].filter(Boolean).join(' - ');

      const finalProductData = {
        name: generatedName,
        strain_name: productInfo.strain_name || "",
        brand: productInfo.brand || "",
        brand_id: productInfo.brand_id || null, // Include brand_id in final product data
        type: productInfo.type || "hybrid",
        category: productInfo.category || "flower",
        amount: productInfo.amount || "",
        thc_percentage: productInfo.thc_percentage || 0,
        thca_percentage: productInfo.thca_percentage || 0,
        cbd_percentage: productInfo.cbd_percentage || 0,
        cbda_percentage: productInfo.cbda_percentage || 0,
        cbg_percentage: productInfo.cbg_percentage || 0,
        cbn_percentage: productInfo.cbn_percentage || 0,
        terpene_profile: selectedTerpenes.length > 0 ? selectedTerpenes : productInfo.terpene_profile || [],
        lab_analysis_url: productInfo.lab_analysis_url || null,
        qr_data: productInfo.qr_data || null,
        harvest_date: productInfo.harvest_date || null,
        packed_date: productInfo.packed_date || null,
        expiration_date: productInfo.expiration_date || null,
        test_date: productInfo.test_date || null,
        batch_number: productInfo.batch_number || "",
        purchase_price: productInfo.purchase_price || 0,
        dispensary_id: productInfo.dispensary_id || null
      };

      const product = await base44.entities.Product.create(finalProductData); // Changed to base44.entities.Product

      await base44.entities.UserInventory.create({ // Changed to base44.entities.UserInventory
        product_id: product.id,
        quantity: 1,
        unit: "grams",
        purchase_date: new Date().toISOString().split('T')[0],
        notes: productInfo.notes || `Added via ${type} scanner`
      });

      navigate(createPageUrl("MyStash"));

    } catch (err) {
      setError("Failed to save product. " + (err.message || "Please try again."));
      console.error("Error saving product:", err);
    }
  };

  const saveQRProduct = () => {
    saveProduct({
      name: extractedData.product_name,
      brand: extractedData.brand,
      brand_id: extractedData.brand_id || null, // Include brand_id from extracted data if available
      type: extractedData.type,
      category: extractedData.category,
      thc_percentage: extractedData.thc_percentage,
      thca_percentage: extractedData.thca_percentage,
      cbd_percentage: extractedData.cbd_percentage,
      cbda_percentage: extractedData.cbda_percentage,
      cbg_percentage: extractedData.cbg_percentage,
      cbn_percentage: extractedData.cbn_percentage,
      terpene_profile: extractedData.terpene_profile,
      lab_analysis_url: extractedData.lab_analysis_url,
      qr_data: extractedData.qr_data,
      harvest_date: extractedData.harvest_date,
      test_date: extractedData.test_date,
      batch_number: extractedData.batch_number,
      notes: extractedData.notes || "Added via QR scanner"
    }, "QR");
  };

  const saveManualProduct = () => {
    saveProduct({
      ...manualData
    }, "manual");
  };

  const filteredTerpenes = terpenes.filter(t =>
    t.name.toLowerCase().includes(terpeneSearch.toLowerCase()) &&
    !selectedTerpenes.some(st => st.terpene_name === t.name)
  );

  const shouldHighlightAmount = !manualData.amount || manualData.amount.trim() === "";
  const shouldHighlightDispensary = !manualData.dispensary_id || manualData.dispensary_id.trim() === "";

  // If no item type selected, show selection screen
  if (!itemType) {
    return (
      <div className="min-h-screen p-3 md:p-6 pb-24 md:pb-6">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="text-center">
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">Add to Stash</h1>
            <p className="text-gray-600 text-sm md:text-base">What would you like to add?</p>
          </div>

          {error && (
            <Alert variant="destructive" className="glass-card border-red-200/50">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
            <Card
              className="glass-card border-white/40 hover:shadow-2xl hover:scale-105 transition-all duration-300 cursor-pointer group"
              onClick={() => { setItemType('cannabis'); setError(null); }}
            >
              <CardContent className="flex flex-col items-center justify-center p-8 md:p-12 text-center">
                <div className="w-20 h-20 md:w-24 md:h-24 rounded-2xl bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-lg">
                  <Leaf className="w-10 h-10 md:w-12 md:h-12 text-white" />
                </div>
                <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-2">Cannabis Product</h3>
                <p className="text-sm text-gray-600">Flower, pre-rolls, edibles, concentrates, and more</p>
                <Button className="mt-4 bg-green-600 hover:bg-green-700 group-hover:shadow-lg">
                  Select <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>

            <Card
              className="glass-card border-white/40 hover:shadow-2xl hover:scale-105 transition-all duration-300 cursor-pointer group"
              onClick={() => { setItemType('accessory'); setError(null); }}
            >
              <CardContent className="flex flex-col items-center justify-center p-8 md:p-12 text-center">
                <div className="w-20 h-20 md:w-24 md:h-24 rounded-2xl bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-lg">
                  <Package className="w-10 h-10 md:w-12 md:h-12 text-white" />
                </div>
                <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-2">Accessory</h3>
                <p className="text-sm text-gray-600">Grinders, pipes, vaporizers, storage, and tools</p>
                <Button className="mt-4 bg-purple-600 hover:bg-purple-700 group-hover:shadow-lg">
                  Select <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>

            <Card
              className="glass-card border-white/40 hover:shadow-2xl hover:scale-105 transition-all duration-300 cursor-pointer group"
              onClick={() => { setItemType('dispensary'); setError(null); }}
            >
              <CardContent className="flex flex-col items-center justify-center p-8 md:p-12 text-center">
                <div className="w-20 h-20 md:w-24 md:h-24 rounded-2xl bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-lg">
                  <Store className="w-10 h-10 md:w-12 md:h-12 text-white" />
                </div>
                <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-2">Shop</h3>
                <p className="text-sm text-gray-600">Dispensaries and smoke shops you visit</p>
                <Button className="mt-4 bg-blue-600 hover:bg-blue-700 group-hover:shadow-lg">
                  Select <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // Show Accessory Form
  if (itemType === 'accessory') {
    return (
      <div className="min-h-screen p-3 md:p-6 pb-24 md:pb-6">
        <div className="max-w-4xl mx-auto space-y-6 md:space-y-8">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={() => { setItemType(null); setError(null); }}
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
          </div>

          {error && (
            <Alert variant="destructive" className="glass-card border-red-200/50">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <AddAccessoryForm
            onSuccess={() => navigate(createPageUrl("MyStash") + "?tab=accessories")}
            onCancel={() => setItemType(null)}
          />
        </div>
      </div>
    );
  }

  // Show Dispensary Form
  if (itemType === 'dispensary') {
    return (
      <div className="min-h-screen p-3 md:p-6 pb-24 md:pb-6">
        <div className="max-w-4xl mx-auto space-y-6 md:space-y-8">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={() => { setItemType(null); setError(null); }}
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
          </div>

          {error && (
            <Alert variant="destructive" className="glass-card border-red-200/50">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <AddDispensaryForm
            onSuccess={() => navigate(createPageUrl("MyStash") + "?tab=shops")}
            onCancel={() => setItemType(null)}
          />
        </div>
      </div>
    );
  }

  // Show Cannabis Product Form (existing functionality)
  return (
    <div className="min-h-screen p-3 md:p-6 pb-24 md:pb-6">
      <div className="max-w-4xl mx-auto space-y-6 md:space-y-8">
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={() => { setItemType(null); setError(null); }}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
        </div>

        <div className="text-center">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">Add Cannabis Product</h1>
          <p className="text-gray-600 text-sm md:text-base">Scan or manually enter product details</p>
        </div>

        {error && (
          <Alert variant="destructive" className="glass-card border-red-200/50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Tabs value={activeMethod} onValueChange={setActiveMethod} className="w-full">
          <TabsList className="grid w-full grid-cols-3 glass-card p-1">
            <TabsTrigger value="qr" className="data-[state=active]:bg-white/90 data-[state=active]:shadow-md">Scan QR Code</TabsTrigger>
            <TabsTrigger value="photo" className="data-[state=active]:bg-white/90 data-[state=active]:shadow-md">Product Label</TabsTrigger>
            <TabsTrigger value="manual" className="data-[state=active]:bg-white/90 data-[state=active]:shadow-md">Manual Entry</TabsTrigger>
          </TabsList>

          <TabsContent value="qr" className="space-y-4">
            <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base md:text-lg">
                  <QrCode className="w-4 h-4 md:w-5 md:h-5 text-blue-600" />
                  QR Code Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                {!isScanning ? (
                  <div className="space-y-4">
                    <div className="text-center py-8">
                      <Button onClick={startCamera} className="bg-blue-600/90 hover:bg-blue-700/90 min-h-[44px] px-6 font-medium shadow-lg">
                        <Camera className="w-4 h-4 mr-2" />
                        Start QR Scan
                      </Button>
                      <p className="text-gray-500 mt-3 text-sm">Use camera to scan QR code on product packaging or lab analysis.</p>
                    </div>
                    <div className="text-center text-gray-500 font-medium">OR</div>
                    <div className="space-y-3">
                      <Label htmlFor="manual-qr-url" className="text-sm font-medium">Enter Lab Analysis URL manually</Label>
                      <div className="flex gap-2">
                        <Input
                          id="manual-qr-url"
                          placeholder="https://example-lab.com/analysis/..."
                          value={manualUrl}
                          onChange={(e) => setManualUrl(e.target.value)}
                          className="flex-1 glass-card border-white/40"
                        />
                        <Button onClick={handleManualEntry} disabled={isProcessing} className="min-h-[44px] px-4">
                          {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : "Process"}
                        </Button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full aspect-square object-cover rounded-lg bg-black"
                    />
                    <Button onClick={stopCamera} variant="outline" className="w-full min-h-[44px]">
                      Stop Camera
                    </Button>
                    <p className="text-center text-sm text-gray-500">Scanning for QR code... (actual scan logic not implemented)</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="photo" className="space-y-4">
            <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base md:text-lg">
                  <Upload className="w-4 h-4 md:w-5 md:h-5 text-green-600" />
                  Scan Product Label
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 text-sm mb-4">Take a clear photo of your product label to automatically extract information.</p>

                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  ref={captureInputRef}
                  onChange={handleFileChange}
                  className="hidden"
                />
                <input
                  type="file"
                  accept="image/*"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  className="hidden"
                />

                <Button
                  onClick={() => captureInputRef.current?.click()}
                  className="w-full mb-3 bg-green-600/90 hover:bg-green-700/90 min-h-[44px] shadow-lg"
                  disabled={processingPhoto}
                >
                  <Camera className="w-4 h-4 mr-2" />
                  Take Photo
                </Button>

                <Button
                  onClick={() => fileInputRef.current?.click()}
                  variant="outline"
                  className="w-full glass-card border-white/40 min-h-[44px]"
                  disabled={processingPhoto}
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Upload from Library
                </Button>

                {processingPhoto && (
                  <div className="flex items-center justify-center p-6 glass-card border-blue-200/50">
                    <Loader2 className="w-5 h-5 mr-3 animate-spin text-blue-600" />
                    <span className="text-gray-700 font-medium">Reading Label...</span>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="manual" className="space-y-4">
            <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base md:text-lg">
                  <Edit3 className="w-4 h-4 md:w-5 md:h-5 text-purple-600" />
                  Manual Entry
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="manual-category" className="text-sm font-medium">Product Form *</Label>
                    <Select value={manualData.category} onValueChange={(value) => handleManualDataChange('category', value)}>
                      <SelectTrigger id="manual-category" className="glass-card border-white/40 mt-1">
                        <SelectValue placeholder="Select form" />
                      </SelectTrigger>
                      <SelectContent className="glass-card border-white/40">
                        {PRODUCT_CATEGORIES.map(cat => (
                          <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="manual-strain-name" className="text-sm font-medium">Strain Name *</Label>
                    <Input
                      id="manual-strain-name"
                      value={manualData.strain_name}
                      onChange={(e) => handleManualDataChange('strain_name', e.target.value)}
                      placeholder="e.g., Blue Dream"
                      className="glass-card border-white/40 mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="manual-brand" className="text-sm font-medium">Brand</Label>
                    <Select value={manualData.brand_id} onValueChange={(value) => {
                      const selectedBrand = brands.find(b => b.id === value);
                      handleManualDataChange('brand_id', value);
                      handleManualDataChange('brand', selectedBrand?.name || "");
                    }}>
                      <SelectTrigger id="manual-brand" className="glass-card border-white/40 mt-1">
                        <SelectValue placeholder="Select brand" />
                      </SelectTrigger>
                      <SelectContent className="glass-card border-white/40">
                        {brands.map(brand => (
                          <SelectItem key={brand.id} value={brand.id}>
                            {brand.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="manual-amount" className="text-sm font-medium flex items-center gap-1.5">
                      <Box className="w-3.5 h-3.5" />
                      Amount *
                    </Label>
                    <Input
                      id="manual-amount"
                      value={manualData.amount}
                      onChange={(e) => handleManualDataChange('amount', e.target.value)}
                      placeholder="e.g., 7g, 1/8 oz, 500mg"
                      className={cn(
                        "glass-card mt-1",
                        shouldHighlightAmount
                          ? "border-green-500 ring-2 ring-green-400/50 !border-green-500"
                          : "border-white/40"
                      )}
                    />
                  </div>
                  <div>
                    <Label htmlFor="manual-type" className="text-sm font-medium">Strain Type</Label>
                    <Select value={manualData.type} onValueChange={(value) => handleManualDataChange('type', value)}>
                      <SelectTrigger id="manual-type" className="glass-card border-white/40 mt-1">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent className="glass-card border-white/40">
                        <SelectItem value="indica">Indica</SelectItem>
                        <SelectItem value="sativa">Sativa</SelectItem>
                        <SelectItem value="hybrid">Hybrid</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label className="text-base font-medium mb-3 block">Packaging Dates</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="manual-packed-date" className="text-sm flex items-center gap-1.5"><Archive className="w-3.5 h-3.5" /> Packed</Label>
                      <Input
                        id="manual-packed-date"
                        type="date"
                        value={manualData.packed_date}
                        onChange={(e) => handleManualDataChange('packed_date', e.target.value)}
                        className="text-sm glass-card border-white/40 mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="manual-expiration-date" className="text-sm flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" /> Expires</Label>
                      <Input
                        id="manual-expiration-date"
                        type="date"
                        value={manualData.expiration_date}
                        onChange={(e) => handleManualDataChange('expiration_date', e.target.value)}
                        className="text-sm glass-card border-white/40 mt-1"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-base font-medium mb-3 block">Cannabinoids (%)</Label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {[
                      { key: 'thc_percentage', label: 'THC %' },
                      { key: 'thca_percentage', label: 'THCa %' },
                      { key: 'cbd_percentage', label: 'CBD %' },
                      { key: 'cbda_percentage', label: 'CBDa %' },
                      { key: 'cbg_percentage', label: 'CBG %' },
                      { key: 'cbn_percentage', label: 'CBN %' }
                    ].map(cannabinoid => (
                      <div key={cannabinoid.key}>
                        <Label htmlFor={`manual-${cannabinoid.key}`} className="text-sm">{cannabinoid.label}</Label>
                        <Input
                          id={`manual-${cannabinoid.key}`}
                          type="number"
                          step="0.1"
                          min="0"
                          max="100"
                          value={manualData[cannabinoid.key]}
                          onChange={(e) => handleManualDataChange(cannabinoid.key, parseFloat(e.target.value) || 0)}
                          className="text-sm glass-card border-white/40 mt-1"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-base font-medium mb-3 block">Terpene Data</Label>
                  <div className="space-y-3">
                    <div className="relative">
                      <Input
                        placeholder="Search and select terpenes..."
                        value={terpeneSearch}
                        onChange={(e) => setTerpeneSearch(e.target.value)}
                        className="glass-card border-white/40"
                      />
                      {terpeneSearch && filteredTerpenes.length > 0 && (
                        <div className="absolute z-10 w-full mt-1 glass-card border-white/40 rounded-md shadow-lg max-h-48 overflow-y-auto">
                          {filteredTerpenes.slice(0, 10).map(terpene => (
                            <button
                              key={terpene.id}
                              type="button"
                              className="w-full px-3 py-2 text-left hover:bg-white/50 text-sm transition-colors"
                              onClick={() => addTerpene(terpene)}
                            >
                              {terpene.name}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {processingTerpenes && (
                      <div className="flex items-center justify-center p-4 glass-card border-blue-200/50 bg-blue-50/80 rounded-lg">
                        <div className="w-4 h-4 mr-3 animate-spin rounded-full border-2 border-blue-600 border-t-transparent"></div>
                        <span className="text-blue-700 font-medium text-sm">Searching for terpenes...</span>
                      </div>
                    )}

                    {selectedTerpenes.length > 0 && (
                      <div className="space-y-2 mt-3">
                        {selectedTerpenes.map(terpene => (
                          <div key={terpene.terpene_name} className="flex items-center gap-2 p-3 glass-card border-white/40 rounded-lg">
                            <span className="flex-1 text-sm font-medium">{terpene.terpene_name}</span>
                            {isLabAnalysisSource && (
                              <Input
                                type="number"
                                step="0.01"
                                min="0"
                                placeholder="%"
                                value={terpene.percentage}
                                onChange={(e) => updateTerpenePercentage(terpene.terpene_name, e.target.value)}
                                className="w-20 text-xs glass-card border-white/40"
                              />
                            )}
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => removeTerpene(terpene.terpene_name)}
                              className="text-red-500 hover:text-red-700 hover:bg-red-50/50"
                            >
                              ×
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="manual-price" className="text-sm font-medium">Cost (USD)</Label>
                    <Input
                      id="manual-price"
                      type="number"
                      step="0.01"
                      min="0"
                      value={manualData.purchase_price}
                      onChange={(e) => handleManualDataChange('purchase_price', parseFloat(e.target.value) || 0)}
                      placeholder="29.99"
                      className="glass-card border-white/40 mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="manual-dispensary" className="text-sm font-medium">Purchased From</Label>
                    <Select value={manualData.dispensary_id} onValueChange={(value) => handleManualDataChange('dispensary_id', value)}>
                      <SelectTrigger id="manual-dispensary" className={cn(
                        "glass-card mt-1",
                        shouldHighlightDispensary
                          ? "border-green-500 ring-2 ring-green-400/50 !border-green-500"
                          : "border-white/40"
                      )}>
                        <SelectValue placeholder="Select dispensary" />
                      </SelectTrigger>
                      <SelectContent className="glass-card border-white/40">
                        {dispensaries.map(dispensary => (
                          <SelectItem key={dispensary.id} value={dispensary.id}>
                            <div className="flex items-center gap-2">
                              <Store className="w-4 h-4" />
                              {dispensary.name}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="manual-notes" className="text-sm font-medium">Notes</Label>
                  <Textarea
                    id="manual-notes"
                    value={manualData.notes}
                    onChange={(e) => handleManualDataChange('notes', e.target.value)}
                    placeholder="Additional notes about this product..."
                    rows={3}
                    className="glass-card border-white/40 mt-1"
                  />
                </div>

                <Button onClick={saveManualProduct} className="w-full bg-green-600/90 hover:bg-green-700/90 min-h-[44px] shadow-lg font-medium">
                  <Plus className="w-4 h-4 mr-2" />
                  Add to Stash
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Dialog open={showDispensaryModal} onOpenChange={setShowDispensaryModal}>
          <DialogContent className="glass-card border-white/40 sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Dispensary</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="p-4 bg-blue-50/80 rounded-lg glass-card border-blue-200/50">
                <p className="text-sm text-gray-700 mb-2">
                  We found a potential dispensary from your product label:
                </p>
                <p className="font-semibold text-blue-800">"{suggestedDispensary?.name}"</p>
                <p className="text-xs text-gray-600 mt-1">
                  Would you like to add this to your saved dispensaries?
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <Label htmlFor="dispensary-name" className="text-sm font-medium">Dispensary Name</Label>
                  <Input
                    id="dispensary-name"
                    value={dispensaryFormData.name}
                    onChange={(e) => handleDispensaryFormChange('name', e.target.value)}
                    className="glass-card border-white/40 mt-1"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="dispensary-city" className="text-sm font-medium">City</Label>
                    <Input
                      id="dispensary-city"
                      value={dispensaryFormData.city}
                      onChange={(e) => handleDispensaryFormChange('city', e.target.value)}
                      placeholder="Seattle"
                      className="glass-card border-white/40 mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="dispensary-state" className="text-sm font-medium">State</Label>
                    <Input
                      id="dispensary-state"
                      value={dispensaryFormData.state}
                      onChange={(e) => handleDispensaryFormChange('state', e.target.value)}
                      placeholder="WA"
                      className="glass-card border-white/40 mt-1"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="dispensary-address" className="text-sm font-medium">Address (Optional)</Label>
                  <Input
                    id="dispensary-address"
                    value={dispensaryFormData.address}
                    onChange={(e) => handleDispensaryFormChange('address', e.target.value)}
                    placeholder="123 Main Street"
                    className="glass-card border-white/40 mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="dispensary-notes" className="text-sm font-medium">Notes (Optional)</Label>
                  <Textarea
                    id="dispensary-notes"
                    value={dispensaryFormData.notes}
                    onChange={(e) => handleDispensaryFormChange('notes', e.target.value)}
                    placeholder="Personal notes about this dispensary..."
                    rows={2}
                    className="glass-card border-white/40 mt-1"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-white/30">
                <Button
                  variant="outline"
                  onClick={handleDeclineDispensary}
                  className="glass-card border-white/40 hover:bg-white/60"
                >
                  No, Select Existing
                </Button>
                <Button
                  onClick={handleAddNewDispensary}
                  className="bg-blue-600/90 hover:bg-blue-700/90"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Dispensary
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* New Brand Modal */}
        <Dialog open={showBrandModal} onOpenChange={setShowBrandModal}>
          <DialogContent className="glass-card border-white/40 sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Brand</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="p-4 bg-blue-50/80 rounded-lg glass-card border-blue-200/50">
                <p className="text-sm text-gray-700 mb-2">
                  We found a potential brand from your product label:
                </p>
                <p className="font-semibold text-blue-800">"{suggestedBrand?.name}"</p>
                <p className="text-xs text-gray-600 mt-1">
                  Would you like to add this to the brand catalog?
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <Label htmlFor="brand-name" className="text-sm font-medium">Brand Name</Label>
                  <Input
                    id="brand-name"
                    value={brandFormData.name}
                    onChange={(e) => handleBrandFormChange('name', e.target.value)}
                    className="glass-card border-white/40 mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="brand-description" className="text-sm font-medium">Description (Optional)</Label>
                  <Textarea
                    id="brand-description"
                    value={brandFormData.description}
                    onChange={(e) => handleBrandFormChange('description', e.target.value)}
                    placeholder="Brief description of the brand..."
                    rows={2}
                    className="glass-card border-white/40 mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="brand-category" className="text-sm font-medium">Primary Category</Label>
                  <Select
                    value={brandFormData.primary_categories[0] || ""}
                    onValueChange={(value) => handleBrandFormChange('primary_categories', [value])}
                  >
                    <SelectTrigger id="brand-category" className="glass-card border-white/40 mt-1">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {PRODUCT_CATEGORIES.map(cat => (
                        <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-white/30">
                <Button
                  variant="outline"
                  onClick={handleDeclineBrand}
                  className="glass-card border-white/40 hover:bg-white/60"
                >
                  Skip for Now
                </Button>
                <Button
                  onClick={handleAddNewBrand}
                  className="bg-blue-600/90 hover:bg-blue-700/90"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Brand
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>


        {extractedData && (
          <Card className="glass-card border-green-200/50 hover:shadow-xl transition-all duration-300">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base md:text-lg">
                <CheckCircle2 className="w-4 h-4 md:w-5 md:h-5 text-green-600" />
                QR Data Extracted
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 md:space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                  <h3 className="font-semibold text-base md:text-lg mb-2">
                    {[extractedData.brand, extractedData.product_name || extractedData.strain_name, extractedData.category]
                      .filter(Boolean)
                      .join(' - ')}
                  </h3>
                  <div className="space-y-2">
                    {extractedData.brand && (
                      <p className="text-gray-600 text-sm md:text-base"><span className="font-medium">Brand:</span> {extractedData.brand}</p>
                    )}
                    {extractedData.strain_name && (
                      <p className="text-gray-600 text-sm md:text-base"><span className="font-medium">Strain Name:</span> {extractedData.strain_name}</p>
                    )}
                    <p className="text-gray-600 text-sm md:text-base">
                      <span className="font-medium">Type:</span>
                      <Badge className="ml-2 text-xs md:text-sm glass-card border-white/40">{extractedData.type}</Badge>
                    </p>
                    <p className="text-gray-600 text-sm md:text-base">
                      <span className="font-medium">Category:</span>
                      <Badge variant="outline" className="ml-2 text-xs md:text-sm glass-card border-white/40">{extractedData.category}</Badge>
                    </p>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2 text-sm md:text-base">Cannabinoid Profile</h4>
                  <div className="space-y-1">
                    {extractedData.thc_percentage > 0 && (
                      <div className="flex justify-between text-sm md:text-base">
                        <span>THC</span>
                        <span className="font-medium">{extractedData.thc_percentage}%</span>
                      </div>
                    )}
                    {extractedData.thca_percentage > 0 && (
                      <div className="flex justify-between text-sm md:text-base">
                        <span>THCa</span>
                        <span className="font-medium">{extractedData.thca_percentage}%</span>
                      </div>
                    )}
                    {extractedData.cbd_percentage > 0 && (
                      <div className="flex justify-between text-sm md:text-base">
                        <span>CBD</span>
                        <span className="font-medium">{extractedData.cbd_percentage}%</span>
                      </div>
                    )}
                    {extractedData.cbda_percentage > 0 && (
                      <div className="flex justify-between text-sm md:text-base">
                        <span>CBDa</span>
                        <span className="font-medium">{extractedData.cbda_percentage}%</span>
                      </div>
                    )}
                    {extractedData.cbg_percentage > 0 && (
                      <div className="flex justify-between text-sm md:text-base">
                        <span>CBG</span>
                        <span className="font-medium">{extractedData.cbg_percentage}%</span>
                      </div>
                    )}
                    {extractedData.cbn_percentage > 0 && (
                      <div className="flex justify-between text-sm md:text-base">
                        <span>CBN</span>
                        <span className="font-medium">{extractedData.cbn_percentage}%</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {extractedData.terpene_profile && extractedData.terpene_profile.length > 0 && (
                <div>
                  <h4 className="font-medium mb-3 text-sm md:text-base">Terpene Profile</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 md:gap-3">
                    {extractedData.terpene_profile.map((terpene, index) => (
                      <div key={index} className="glass-card border-green-200/50 p-2 md:p-3 rounded-lg">
                        <p className="font-medium text-xs md:text-sm">{terpene.terpene_name}</p>
                        <p className="text-green-600 font-semibold text-xs md:text-sm">{terpene.percentage}%</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex flex-col md:flex-row gap-3 pt-4">
                <Button onClick={saveQRProduct} className="bg-green-600/90 hover:bg-green-700/90 flex-1 md:flex-none min-h-[44px] shadow-lg">
                  <Plus className="w-4 h-4 mr-2" />
                  Add to Stash
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setExtractedData(null);
                    setManualUrl("");
                    setIsLabAnalysisSource(false);
                  }}
                  className="flex-1 md:flex-none glass-card border-white/40 min-h-[44px]"
                >
                  Clear
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
