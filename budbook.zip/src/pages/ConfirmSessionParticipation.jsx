import React, { useState, useEffect } from 'react';
import { Session, Product, User } from '@/entities/all';
import { confirmSessionParticipation } from '@/functions/confirmSessionParticipation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle2, UserCheck, Loader2, Calendar, Leaf } from 'lucide-react';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

export default function ConfirmSessionParticipation() {
  const navigate = useNavigate();
  const [session, setSession] = useState(null);
  const [product, setProduct] = useState(null);
  const [inviter, setInviter] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [confirming, setConfirming] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadSessionData = async () => {
      try {
        const urlParams = new URLSearchParams(window.location.search);
        const sessionId = urlParams.get('session_id');
        const inviterEmail = urlParams.get('inviter_email');

        if (!sessionId || !inviterEmail) {
          setError('Invalid invitation link. Please check the URL and try again.');
          setLoading(false);
          return;
        }

        const [user, sessionData] = await Promise.all([
          User.me(),
          Session.get(sessionId)
        ]);

        setCurrentUser(user);

        if (!sessionData) {
          setError('This session could not be found or is no longer available.');
          setLoading(false);
          return;
        }

        // Check if user is already confirmed
        if (sessionData.confirmed_friends?.includes(user.email)) {
          setConfirmed(true);
        }

        // Check if user was actually invited
        if (!sessionData.tagged_friends?.includes(user.email)) {
          setError('You were not invited to this session or the invitation has expired.');
          setLoading(false);
          return;
        }

        setSession(sessionData);

        // Load product data
        if (sessionData.product_id) {
          const productData = await Product.get(sessionData.product_id);
          setProduct(productData);
        }

        setInviter({ email: inviterEmail });
      } catch (err) {
        console.error('Error loading session data:', err);
        setError('An error occurred while loading the session. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    loadSessionData();
  }, []);

  const handleConfirmParticipation = async () => {
    if (!session || !currentUser) return;

    setConfirming(true);
    try {
      const { data } = await confirmSessionParticipation({
        session_id: session.id,
        user_email: currentUser.email
      });

      if (data.success) {
        setConfirmed(true);
        toast.success('Session participation confirmed! This session now appears in your journal.');
      } else {
        throw new Error(data.message || 'Failed to confirm participation');
      }
    } catch (err) {
      console.error('Error confirming participation:', err);
      toast.error('Could not confirm participation. Please try again.');
    } finally {
      setConfirming(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50/30 to-blue-50/30 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 text-green-600 animate-spin" />
          <p className="text-gray-600">Loading session invitation...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50/30 to-blue-50/30 p-6">
        <div className="max-w-2xl mx-auto pt-20">
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
          <div className="mt-6 text-center">
            <Link to={createPageUrl('Personal')}>
              <Button>Go to Dashboard</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (confirmed) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50/30 to-blue-50/30 p-6">
        <div className="max-w-2xl mx-auto pt-20">
          <Card className="bg-white/90 backdrop-blur-sm text-center">
            <CardContent className="p-8">
              <CheckCircle2 className="w-16 h-16 mx-auto mb-4 text-green-600" />
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Participation Confirmed!</h2>
              <p className="text-gray-600 mb-6">
                This session has been added to your journal and you can view it anytime.
              </p>
              <div className="flex gap-3 justify-center">
                <Link to={createPageUrl('Journal')}>
                  <Button className="bg-green-600 hover:bg-green-700">
                    View My Journal
                  </Button>
                </Link>
                <Link to={createPageUrl('Personal')}>
                  <Button variant="outline">Go to Dashboard</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50/30 to-blue-50/30 p-6">
      <div className="max-w-2xl mx-auto pt-20">
        <Card className="bg-white/90 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2 text-2xl">
              <UserCheck className="w-6 h-6 text-blue-600" />
              Session Participation Confirmation
            </CardTitle>
            <p className="text-gray-600">
              You've been invited to confirm your participation in a session
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-gray-700 mb-2">
                <span className="font-medium">{inviter?.email}</span> has tagged you in their session:
              </p>
              
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-gray-500" />
                  <span className="text-sm">
                    {format(new Date(session.date), 'EEEE, MMMM d, yyyy \'at\' h:mm a')}
                  </span>
                </div>
                
                {product && (
                  <div className="flex items-center gap-2">
                    <Leaf className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-medium">{product.name}</span>
                    <Badge variant="outline" className="text-xs">{product.type}</Badge>
                  </div>
                )}
                
                {session.context && (
                  <div className="text-sm">
                    <span className="text-gray-500">Context: </span>
                    <span>{session.context}</span>
                  </div>
                )}
                
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-500">Method: </span>
                  <Badge variant="secondary" className="text-xs">
                    {session.consumption_method}
                  </Badge>
                </div>
              </div>
            </div>

            <div className="p-4 bg-yellow-50 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">What happens when you confirm?</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• This session will appear in your personal journal</li>
                <li>• You'll be able to view and reference this session anytime</li>
                <li>• The session will show that you were a participant</li>
                <li>• Your participation helps create a shared memory</li>
              </ul>
            </div>

            <div className="flex gap-3 justify-center pt-4">
              <Button
                onClick={handleConfirmParticipation}
                disabled={confirming}
                className="bg-green-600 hover:bg-green-700"
              >
                {confirming ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Confirming...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Yes, I was part of this session
                  </>
                )}
              </Button>
              <Link to={createPageUrl('Personal')}>
                <Button variant="outline">
                  Not my session
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}