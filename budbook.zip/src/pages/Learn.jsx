import React, { useState, useEffect } from "react";
import { Course, EBook, ResearchStudy, Recipe, LegislativeUpdate } from "@/entities/all";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import CourseSection from "../components/learn/CourseSection";
import EBookSection from "../components/learn/EBookSection";
import ResearchSection from "../components/learn/ResearchSection";
import RecipeSection from "../components/learn/RecipeSection";

export default function Learn() {
  const [searchTerm, setSearchTerm] = useState("");
  const [data, setData] = useState({
    courses: [],
    ebooks: [],
    studies: [],
    recipes: [],
    updates: [],
    loading: true
  });

  useEffect(() => {
    const loadAllData = async () => {
      try {
        const [courses, ebooks, studies, recipes, updates] = await Promise.all([
          Course.list("-created_date"),
          EBook.list("-publication_date"),
          ResearchStudy.list("-publication_date"),
          Recipe.list("-created_date"),
          LegislativeUpdate.list("-date")
        ]);
        setData({ courses, ebooks, studies, recipes, updates, loading: false });
      } catch (error) {
        console.error("Failed to load learning data:", error);
        setData(prev => ({ ...prev, loading: false }));
      }
    };
    loadAllData();
  }, []);

  return (
    <div className="p-3 md:p-6 pb-24 md:pb-6">
      <div className="max-w-6xl mx-auto space-y-6 md:space-y-8">
        <div className="text-center">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">Learn & Grow</h1>
          <p className="text-gray-600 text-sm md:text-base">Expand your cannabis knowledge with courses, research, and recipes</p>
        </div>

        <div className="relative max-w-md mx-auto">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search courses, books, studies..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 glass-card border-white/40 min-h-[44px]"
          />
        </div>

        <Tabs defaultValue="courses" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 glass-card p-1">
            <TabsTrigger value="courses" className="text-xs md:text-sm data-[state=active]:bg-white/90 data-[state=active]:shadow-md">Courses</TabsTrigger>
            <TabsTrigger value="books" className="text-xs md:text-sm data-[state=active]:bg-white/90 data-[state=active]:shadow-md">E-Books</TabsTrigger>
            <TabsTrigger value="research" className="text-xs md:text-sm data-[state=active]:bg-white/90 data-[state=active]:shadow-md">Research</TabsTrigger>
            <TabsTrigger value="recipes" className="text-xs md:text-sm data-[state=active]:bg-white/90 data-[state=active]:shadow-md">Recipes</TabsTrigger>
          </TabsList>
          
          <TabsContent value="courses" className="pt-6">
            <CourseSection courses={data.courses} searchTerm={searchTerm} loading={data.loading} />
          </TabsContent>
          
          <TabsContent value="books" className="pt-6">
            <EBookSection ebooks={data.ebooks} searchTerm={searchTerm} loading={data.loading} />
          </TabsContent>
          
          <TabsContent value="research" className="pt-6">
            <ResearchSection studies={data.studies} searchTerm={searchTerm} loading={data.loading} />
          </TabsContent>
          
          <TabsContent value="recipes" className="pt-6">
            <RecipeSection recipes={data.recipes} searchTerm={searchTerm} loading={data.loading} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}