import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MonitorPlay, Youtube, Music, Instagram, PlayCircle } from 'lucide-react';

export default function Media() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50/30 to-pink-50/30 p-3 md:p-6">
      <div className="max-w-6xl mx-auto space-y-6 md:space-y-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">Media Feed</h1>
          <p className="text-gray-600">Cannabis content from YouTube, Instagram, TikTok, and more</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-white/80 backdrop-blur-sm">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Youtube className="w-4 h-4 text-red-600" />
                YouTube
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-gray-600">Educational videos and reviews</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Music className="w-4 h-4 text-green-600" />
                Spotify
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-gray-600">Cannabis culture playlists</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Instagram className="w-4 h-4 text-pink-600" />
                Instagram
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-gray-600">Community photos and stories</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <PlayCircle className="w-4 h-4 text-black" />
                TikTok
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-gray-600">Quick tips and trends</p>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm">
          <CardContent className="text-center py-12">
            <MonitorPlay className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Curated Media Feed Coming Soon</h3>
            <p className="text-gray-600 mb-4">
              We're building an aggregated feed of cannabis-related content from across social media platforms.
            </p>
            <div className="text-sm text-gray-500">
              <p>✓ Personalized content recommendations</p>
              <p>✓ Geographic relevance</p>
              <p>✓ Product and strain-related content</p>
              <p>✓ Educational and entertainment content</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}