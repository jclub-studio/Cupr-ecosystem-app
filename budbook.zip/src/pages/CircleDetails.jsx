import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Lock,
  Globe,
  Crown,
  UserPlus,
  UserMinus,
  Settings,
  ArrowLeft,
  Loader2,
  CheckCircle2,
  X,
  Search
} from "lucide-react";
import { toast } from "sonner";
import PostCard from "../components/social/PostCard";
import { createPageUrl } from "@/utils";

export default function CircleDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const [circle, setCircle] = useState(null);
  const [posts, setPosts] = useState([]);
  const [members, setMembers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isOwner, setIsOwner] = useState(false);
  
  // Add members state
  const [showAddMemberDialog, setShowAddMemberDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [friendsList, setFriendsList] = useState([]);
  const [membersToAdd, setMembersToAdd] = useState([]);
  const [addingMembers, setAddingMembers] = useState(false);

  // Edit mode state
  const [editMode, setEditMode] = useState(false);
  const [editData, setEditData] = useState({
    name: "",
    description: "",
    circle_type: "private"
  });

  useEffect(() => {
    loadCircleData();
  }, [id]);

  const loadCircleData = async () => {
    try {
      const [circleData, user] = await Promise.all([
        base44.entities.SmokeCircle.get(id),
        base44.auth.me()
      ]);

      if (!circleData) {
        toast.error("Circle not found");
        navigate(createPageUrl("MyCircles"));
        return;
      }

      setCircle(circleData);
      setCurrentUser(user);
      setIsOwner(circleData.owner_email === user.email);

      setEditData({
        name: circleData.name,
        description: circleData.description || "",
        circle_type: circleData.circle_type || "private"
      });

      // Load posts for this circle
      const circlePosts = await base44.entities.SocialPost.filter({ circle_id: id }, "-created_date");
      setPosts(circlePosts);

      // Load member details
      const memberPromises = circleData.members.map(async (email) => {
        const users = await base44.asServiceRole.entities.User.filter({ email });
        return users[0] || { email, full_name: email, username: email };
      });
      const memberDetails = await Promise.all(memberPromises);
      setMembers(memberDetails);

      // Load friends list for adding members
      if (user.friends && user.friends.length > 0) {
        const friendPromises = user.friends.map(async (friendEmail) => {
          const users = await base44.asServiceRole.entities.User.filter({ email: friendEmail });
          return users[0] || null;
        });
        const friendDetails = (await Promise.all(friendPromises)).filter(f => f !== null);
        setFriendsList(friendDetails);
      }

    } catch (error) {
      console.error("Error loading circle:", error);
      toast.error("Failed to load circle");
    } finally {
      setLoading(false);
    }
  };

  const handleSearchUsers = async (query) => {
    if (!query || query.trim().length < 2) {
      setSearchResults([]);
      return;
    }

    setSearching(true);
    try {
      const response = await base44.functions.invoke('searchUsers', {
        search_query: query
      });

      if (response.data.success) {
        // Filter out users who are already members or already in membersToAdd
        const currentMemberEmails = circle.members || [];
        const membersToAddEmails = membersToAdd.map(m => m.email);
        
        const filteredResults = response.data.users.filter(user => 
          !currentMemberEmails.includes(user.email) && 
          !membersToAddEmails.includes(user.email) &&
          user.email !== currentUser.email
        );
        
        setSearchResults(filteredResults);
      }
    } catch (error) {
      console.error("Error searching users:", error);
      toast.error("Failed to search users");
    } finally {
      setSearching(false);
    }
  };

  const handleAddToTempList = (user) => {
    if (!membersToAdd.find(m => m.email === user.email)) {
      setMembersToAdd([...membersToAdd, user]);
      setSearchQuery("");
      setSearchResults([]);
    }
  };

  const handleRemoveFromTempList = (email) => {
    setMembersToAdd(membersToAdd.filter(m => m.email !== email));
  };

  const handleAddMembersToCircle = async () => {
    if (membersToAdd.length === 0) {
      toast.error("Please select at least one member to add");
      return;
    }

    setAddingMembers(true);
    try {
      const response = await base44.functions.invoke('addMembersToCircle', {
        circle_id: id,
        user_emails: membersToAdd.map(m => m.email)
      });

      if (response.data.success) {
        toast.success(response.data.message);
        setMembersToAdd([]);
        setShowAddMemberDialog(false);
        await loadCircleData();
      } else {
        toast.error(response.data.message || "Failed to add members");
      }
    } catch (error) {
      console.error("Error adding members:", error);
      toast.error("Failed to add members to circle");
    } finally {
      setAddingMembers(false);
    }
  };

  const handleRemoveMember = async (memberEmail) => {
    if (memberEmail === circle.owner_email) {
      toast.error("Cannot remove the circle owner");
      return;
    }

    try {
      const updatedMembers = circle.members.filter(email => email !== memberEmail);
      await base44.entities.SmokeCircle.update(id, {
        members: updatedMembers
      });
      toast.success("Member removed from circle");
      await loadCircleData();
    } catch (error) {
      console.error("Error removing member:", error);
      toast.error("Failed to remove member");
    }
  };

  const handleSaveEdit = async () => {
    try {
      await base44.entities.SmokeCircle.update(id, {
        name: editData.name,
        description: editData.description,
        circle_type: editData.circle_type
      });
      toast.success("Circle updated successfully");
      setEditMode(false);
      await loadCircleData();
    } catch (error) {
      console.error("Error updating circle:", error);
      toast.error("Failed to update circle");
    }
  };

  const handleLeaveCircle = async () => {
    if (isOwner) {
      toast.error("Circle owner cannot leave. Delete the circle instead.");
      return;
    }

    try {
      const updatedMembers = circle.members.filter(email => email !== currentUser.email);
      await base44.entities.SmokeCircle.update(id, {
        members: updatedMembers
      });
      toast.success("Left circle successfully");
      navigate(createPageUrl("MyCircles"));
    } catch (error) {
      console.error("Error leaving circle:", error);
      toast.error("Failed to leave circle");
    }
  };

  const handleDeleteCircle = async () => {
    if (!isOwner) {
      toast.error("Only the owner can delete the circle");
      return;
    }

    if (window.confirm("Are you sure you want to delete this circle? This action cannot be undone.")) {
      try {
        await base44.entities.SmokeCircle.delete(id);
        toast.success("Circle deleted successfully");
        navigate(createPageUrl("MyCircles"));
      } catch (error) {
        console.error("Error deleting circle:", error);
        toast.error("Failed to delete circle");
      }
    }
  };

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchQuery.trim().length >= 2) {
        handleSearchUsers(searchQuery);
      } else {
        setSearchResults([]);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchQuery]);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
      </div>
    );
  }

  if (!circle) {
    return null;
  }

  const circleTypeIcons = {
    private: <Lock className="w-4 h-4" />,
    public: <Globe className="w-4 h-4" />,
    exclusive: <Crown className="w-4 h-4" />
  };

  const circleTypeColors = {
    private: "bg-gray-100 text-gray-800",
    public: "bg-green-100 text-green-800",
    exclusive: "bg-purple-100 text-purple-800"
  };

  // Filter friends that aren't already members
  const availableFriends = friendsList.filter(friend => 
    !circle.members.includes(friend.email) && 
    !membersToAdd.find(m => m.email === friend.email)
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50/30 to-purple-50/30 p-3 md:p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(createPageUrl("MyCircles"))}
            className="glass-card"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900">{circle.name}</h1>
              <Badge className={`${circleTypeColors[circle.circle_type]} flex items-center gap-1`}>
                {circleTypeIcons[circle.circle_type]}
                {circle.circle_type}
              </Badge>
            </div>
            {circle.description && (
              <p className="text-gray-600 mt-1">{circle.description}</p>
            )}
          </div>
          {isOwner && (
            <Button
              variant="outline"
              size="icon"
              onClick={() => setEditMode(!editMode)}
              className="glass-card"
            >
              <Settings className="w-5 h-5" />
            </Button>
          )}
        </div>

        {/* Edit Mode */}
        {editMode && (
          <Card className="glass-card border-white/40">
            <CardHeader>
              <CardTitle>Edit Circle</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Circle Name</Label>
                <Input
                  value={editData.name}
                  onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                  className="glass-card border-white/40"
                />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea
                  value={editData.description}
                  onChange={(e) => setEditData({ ...editData, description: e.target.value })}
                  className="glass-card border-white/40"
                />
              </div>
              <div>
                <Label>Circle Type</Label>
                <Select
                  value={editData.circle_type}
                  onValueChange={(value) => setEditData({ ...editData, circle_type: value })}
                >
                  <SelectTrigger className="glass-card border-white/40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="glass-card">
                    <SelectItem value="private">Private - Only members can see and post</SelectItem>
                    <SelectItem value="public">Public - Anyone can see, members can post</SelectItem>
                    <SelectItem value="exclusive">Exclusive - Anyone can see, only verified can post</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setEditMode(false)} className="glass-card">
                  Cancel
                </Button>
                <Button onClick={handleSaveEdit} className="bg-blue-600 hover:bg-blue-700">
                  Save Changes
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tabs */}
        <Tabs defaultValue="posts" className="w-full">
          <TabsList className="grid w-full grid-cols-2 glass-card">
            <TabsTrigger value="posts">Posts ({posts.length})</TabsTrigger>
            <TabsTrigger value="members">Members ({members.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="posts" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Circle Posts</h3>
              <Link to={`${createPageUrl("NewPost")}?circle_id=${id}`}>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <UserPlus className="w-4 h-4 mr-2" />
                  New Post
                </Button>
              </Link>
            </div>
            
            {posts.length === 0 ? (
              <Card className="glass-card border-white/40">
                <CardContent className="text-center py-12">
                  <p className="text-gray-600">No posts in this circle yet</p>
                </CardContent>
              </Card>
            ) : (
              posts.map(post => <PostCard key={post.id} post={post} />)
            )}
          </TabsContent>

          <TabsContent value="members" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Circle Members</h3>
              {isOwner && (
                <Button 
                  onClick={() => setShowAddMemberDialog(true)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Add Members
                </Button>
              )}
            </div>

            <div className="grid gap-3">
              {members.map((member) => (
                <Card key={member.email} className="glass-card border-white/40">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={member.profile_photo_url} />
                        <AvatarFallback className="bg-blue-100 text-blue-700">
                          {member.full_name?.charAt(0) || member.email?.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{member.full_name || member.email}</p>
                        {member.username && (
                          <p className="text-sm text-gray-600">@{member.username}</p>
                        )}
                      </div>
                      {member.email === circle.owner_email && (
                        <Badge variant="outline" className="ml-2">
                          <Crown className="w-3 h-3 mr-1" />
                          Owner
                        </Badge>
                      )}
                    </div>
                    {isOwner && member.email !== circle.owner_email && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveMember(member.email)}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      >
                        <UserMinus className="w-4 h-4" />
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Leave/Delete Circle Actions */}
            <div className="pt-6 border-t border-white/30 space-y-3">
              {!isOwner && (
                <Button
                  variant="outline"
                  onClick={handleLeaveCircle}
                  className="w-full border-red-200 text-red-600 hover:bg-red-50"
                >
                  Leave Circle
                </Button>
              )}
              {isOwner && (
                <Button
                  variant="destructive"
                  onClick={handleDeleteCircle}
                  className="w-full"
                >
                  Delete Circle
                </Button>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {/* Add Members Dialog */}
        <Dialog open={showAddMemberDialog} onOpenChange={setShowAddMemberDialog}>
          <DialogContent className="glass-card border-white/40 max-w-2xl max-h-[80vh] flex flex-col">
            <DialogHeader>
              <DialogTitle>Add Members to Circle</DialogTitle>
              <DialogDescription>
                Search by username or select from your friends list
              </DialogDescription>
            </DialogHeader>

            <div className="flex-1 overflow-y-auto space-y-6 py-4">
              {/* Search by Username */}
              <div className="space-y-3">
                <Label className="text-sm font-semibold">Search by Username</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Type username to search..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 glass-card border-white/40"
                  />
                  {searching && (
                    <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                  )}
                </div>
                {searchResults.length > 0 && (
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {searchResults.map((user) => (
                      <div
                        key={user.id}
                        className="flex items-center justify-between p-3 bg-white/80 rounded-lg border border-gray-200 hover:bg-white transition-colors cursor-pointer"
                        onClick={() => handleAddToTempList(user)}
                      >
                        <div className="flex items-center gap-3">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={user.profile_photo_url} />
                            <AvatarFallback className="bg-blue-100 text-blue-700 text-xs">
                              {user.full_name?.charAt(0) || user.username?.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-sm">{user.full_name}</p>
                            <p className="text-xs text-gray-600">@{user.username}</p>
                          </div>
                        </div>
                        <Button size="sm" variant="ghost">
                          <UserPlus className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Select from Friends */}
              {availableFriends.length > 0 && (
                <div className="space-y-3">
                  <Label className="text-sm font-semibold">Select from Friends</Label>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {availableFriends.map((friend) => (
                      <div
                        key={friend.id}
                        className="flex items-center justify-between p-3 bg-white/80 rounded-lg border border-gray-200 hover:bg-white transition-colors cursor-pointer"
                        onClick={() => handleAddToTempList(friend)}
                      >
                        <div className="flex items-center gap-3">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={friend.profile_photo_url} />
                            <AvatarFallback className="bg-green-100 text-green-700 text-xs">
                              {friend.full_name?.charAt(0) || friend.username?.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-sm">{friend.full_name}</p>
                            <p className="text-xs text-gray-600">@{friend.username}</p>
                          </div>
                        </div>
                        <Button size="sm" variant="ghost">
                          <UserPlus className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Members to Add List */}
              {membersToAdd.length > 0 && (
                <div className="space-y-3">
                  <Label className="text-sm font-semibold">Members to Add ({membersToAdd.length})</Label>
                  <div className="space-y-2">
                    {membersToAdd.map((member) => (
                      <div
                        key={member.email}
                        className="flex items-center justify-between p-3 bg-blue-50/80 rounded-lg border border-blue-200"
                      >
                        <div className="flex items-center gap-3">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={member.profile_photo_url} />
                            <AvatarFallback className="bg-blue-100 text-blue-700 text-xs">
                              {member.full_name?.charAt(0) || member.username?.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-sm">{member.full_name}</p>
                            <p className="text-xs text-gray-600">@{member.username}</p>
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleRemoveFromTempList(member.email)}
                          className="text-red-500 hover:text-red-700 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <DialogFooter className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setShowAddMemberDialog(false);
                  setMembersToAdd([]);
                  setSearchQuery("");
                  setSearchResults([]);
                }}
                disabled={addingMembers}
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddMembersToCircle}
                disabled={membersToAdd.length === 0 || addingMembers}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {addingMembers ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Adding...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Add {membersToAdd.length} Member{membersToAdd.length !== 1 ? 's' : ''}
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}