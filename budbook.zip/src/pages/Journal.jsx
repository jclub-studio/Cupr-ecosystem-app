import React from "react";
import JournalTab from "../components/personal/JournalTab";

export default function Journal() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50/30 to-blue-50/30 p-3 md:p-6">
      <div className="max-w-7xl mx-auto">
        <JournalTab />
      </div>
    </div>
  );
}