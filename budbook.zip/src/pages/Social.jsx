import React from 'react';
import SocialFeed from '../components/social/SocialFeed';

export default function Social() {
  return (
    <div className="p-3 md:p-6 pb-24 md:pb-6">
      <div className="max-w-6xl mx-auto">
        <SocialFeed />
      </div>
    </div>
  );
}