import React from "react";
import CannadexTab from "../components/explore/CannadexTab";

export default function CannadexPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50/30 to-blue-50/30 p-3 md:p-6">
      <div className="max-w-7xl mx-auto">
        <CannadexTab />
      </div>
    </div>
  );
}