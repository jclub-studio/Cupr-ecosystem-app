import React, { useState, useEffect } from 'react';
import { SharedBuddyAIChat } from '@/entities/SharedBuddyAIChat';
import MessageBubble from '../components/agent/MessageBubble';
import { Loader2, BrainCircuit, ShieldCheck } from 'lucide-react';
import { format } from 'date-fns';

export default function SharedChat() {
  const [sharedChat, setSharedChat] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSharedChat = async () => {
      try {
        const params = new URLSearchParams(window.location.search);
        const chatId = params.get('id');
        if (!chatId) {
          setError('No chat ID provided.');
          setLoading(false);
          return;
        }
        const chatData = await SharedBuddyAIChat.get(chatId);
        if (!chatData) {
          setError('This chat could not be found or is no longer available.');
          setLoading(false);
          return;
        }
        setSharedChat(chatData);
      } catch (err) {
        setError('An error occurred while loading the chat.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchSharedChat();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50/30 to-blue-50/30">
      <header className="p-4 border-b bg-white/80 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto flex items-center gap-3">
          <BrainCircuit className="w-6 h-6 text-green-600" />
          <div>
            <h1 className="text-xl font-bold text-gray-900">Shared Buddy AI Chat</h1>
            {sharedChat && (
              <p className="text-xs text-gray-500">
                Shared on {format(new Date(sharedChat.created_date), 'MMM d, yyyy')}
              </p>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1 p-3 md:p-6">
        <div className="max-w-4xl mx-auto">
          {loading && (
            <div className="flex flex-col items-center justify-center text-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-green-600 mb-4" />
              <p className="text-gray-600">Loading shared conversation...</p>
            </div>
          )}
          {error && (
            <div className="text-center py-20 text-red-600">
              <p>{error}</p>
            </div>
          )}
          {sharedChat && (
            <div className="space-y-4 md:space-y-6">
              <div className="bg-blue-50 border border-blue-200 text-blue-800 text-sm rounded-lg p-3 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 mt-0.5 flex-shrink-0" />
                <span>
                  This is a read-only, shared version of a conversation with Buddy AI. The content is a snapshot from the time of sharing.
                </span>
              </div>
              {sharedChat.messages.map((msg, index) => (
                <MessageBubble key={msg.id || index} message={msg} />
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}