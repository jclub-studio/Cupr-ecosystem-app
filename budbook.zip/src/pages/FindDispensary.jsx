import React, { useState, useEffect, useRef, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { MapPin, Loader2, List, Map, AlertCircle } from "lucide-react";
import { googlePlaces } from "@/functions/googlePlaces";
import DispensaryCard from "../components/dispensary/DispensaryCard";
import DispensaryDetailsModal from "../components/dispensary/DispensaryDetailsModal";

export default function FindDispensary() {
  const [location, setLocation] = useState(null);
  const [dispensaries, setDispensaries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedDispensary, setSelectedDispensary] = useState(null);
  const [details, setDetails] = useState(null);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [view, setView] = useState("map");
  const [mapLoaded, setMapLoaded] = useState(false);
  
  const mapRef = useRef(null);
  const googleMapRef = useRef(null);
  const markersRef = useRef([]);

  // Load Google Maps API
  useEffect(() => {
    const loadGoogleMaps = () => {
      if (window.google && window.google.maps) {
        setMapLoaded(true);
        return;
      }

      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyCMpMGtlE7Cz2kDXF8YUD8WwQHYAlzVXZ4&libraries=places`;
      script.async = true;
      script.defer = true;
      script.onload = () => setMapLoaded(true);
      script.onerror = () => setError("Failed to load Google Maps");
      document.head.appendChild(script);
    };

    loadGoogleMaps();
  }, []);

  // Get user location
  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation({ lat: latitude, lng: longitude });
          fetchDispensaries(latitude, longitude);
        },
        () => {
          setError("Unable to retrieve your location. Please enable location services.");
          setLoading(false);
        }
      );
    } else {
      setError("Geolocation is not supported by your browser.");
      setLoading(false);
    }
  }, []);

  // Initialize Google Map
  useEffect(() => {
    if (mapLoaded && location && mapRef.current && !googleMapRef.current) {
      googleMapRef.current = new window.google.maps.Map(mapRef.current, {
        center: location,
        zoom: 13,
        styles: [
          {
            featureType: "poi.business",
            elementType: "labels",
            stylers: [{ visibility: "off" }]
          },
          {
            featureType: "all",
            elementType: "geometry",
            stylers: [{ color: "#f5f5f5" }]
          },
          {
            featureType: "water",
            elementType: "geometry",
            stylers: [{ color: "#e9e9e9" }]
          }
        ]
      });

      // Add user location marker
      new window.google.maps.Marker({
        position: location,
        map: googleMapRef.current,
        title: "Your Location",
        icon: {
          url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(`
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#3b82f6">
              <circle cx="12" cy="12" r="8"/>
              <circle cx="12" cy="12" r="3" fill="white"/>
            </svg>
          `),
          scaledSize: new window.google.maps.Size(24, 24)
        }
      });
    }
  }, [mapLoaded, location]);

  const fetchDispensaries = async (latitude, longitude) => {
    setLoading(true);
    setError(null);
    try {
      const { data } = await googlePlaces({
        action: "nearby",
        latitude,
        longitude,
        radius: 50000,
      });

      if (data.results) {
        setDispensaries(data.results);
      } else {
        throw new Error(data.error || "Failed to fetch dispensaries.");
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  
  const fetchDetails = async (placeId) => {
    if(!placeId) return;
    setLoadingDetails(true);
    try {
      const { data } = await googlePlaces({ action: "details", place_id: placeId });
      if (data.result) {
        setDetails(data.result);
        setSelectedDispensary(data.result);
      } else {
        throw new Error(data.error || "Failed to fetch details.");
      }
    } catch(err) {
      setError("Could not load dispensary details. " + err.message);
    } finally {
      setLoadingDetails(false);
    }
  }

  const handleViewDetails = useCallback((place) => {
    fetchDetails(place.place_id);
  }, []);

  // Update map markers when dispensaries change
  useEffect(() => {
    if (googleMapRef.current && dispensaries.length > 0) {
      // Clear existing markers
      markersRef.current.forEach(marker => marker.setMap(null));
      markersRef.current = [];

      // Add dispensary markers
      dispensaries.forEach(place => {
        const marker = new window.google.maps.Marker({
          position: {
            lat: place.geometry.location.lat,
            lng: place.geometry.location.lng
          },
          map: googleMapRef.current,
          title: place.name,
          icon: {
            url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(`
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="#16a34a">
                <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/>
                <circle cx="12" cy="9" r="2.5" fill="white"/>
              </svg>
            `),
            scaledSize: new window.google.maps.Size(32, 32)
          }
        });

        marker.addListener('click', () => {
          handleViewDetails(place);
        });

        markersRef.current.push(marker);
      });
    }
  }, [dispensaries, mapLoaded, handleViewDetails]);

  return (
    <div className="p-3 md:p-6 pb-24 md:pb-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="text-center">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">Find Dispensaries</h1>
          <p className="text-gray-600 text-sm md:text-base">Discover cannabis dispensaries near you</p>
        </div>

        {error && (
          <Alert variant="destructive" className="glass-card border-red-200/50">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* View Toggle */}
        <div className="flex justify-center">
          <div className="flex items-center gap-1 bg-gray-100/80 p-1 rounded-lg backdrop-blur-sm">
            <Button 
              variant={view === 'map' ? 'default' : 'ghost'} 
              onClick={() => setView('map')} 
              className="gap-2 min-h-[44px] px-4"
              size="sm"
            >
              <Map size={16}/> Map
            </Button>
            <Button 
              variant={view === 'list' ? 'default' : 'ghost'} 
              onClick={() => setView('list')} 
              className="gap-2 min-h-[44px] px-4"
              size="sm"
            >
              <List size={16}/> List
            </Button>
          </div>
        </div>

        <div className={`grid ${view === 'map' ? 'grid-cols-1 lg:grid-cols-3' : 'grid-cols-1'} gap-6`}>
          {/* Map View */}
          <div className={`${view === 'map' ? 'lg:col-span-2' : 'hidden'}`}>
            <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
              <CardContent className="p-0">
                <div className="h-[300px] md:h-[500px] lg:h-[600px] w-full rounded-lg overflow-hidden">
                  {location && mapLoaded ? (
                    <div 
                      ref={mapRef} 
                      className="h-full w-full"
                    />
                  ) : (
                    <div className="h-full w-full flex items-center justify-center bg-gray-100/80 glass-card">
                      {loading ? (
                        <div className="flex flex-col items-center gap-3">
                          <Loader2 className="animate-spin w-8 h-8 text-green-600" /> 
                          <p className="text-gray-600 text-sm">Finding your location...</p>
                        </div>
                      ) : (
                        <p className="text-gray-500">Map unavailable</p>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* List View */}
          <div className={`${view === 'list' ? 'max-w-4xl mx-auto' : 'lg:col-span-1'}`}>
            <div className={`${view === 'map' ? 'h-[600px] overflow-y-auto' : ''} space-y-4`}>
              {loading && !location ? (
                <Card className="glass-card border-white/40">
                  <CardContent className="flex items-center justify-center py-12">
                    <div className="text-center">
                      <Loader2 className="animate-spin text-green-600 mx-auto mb-3" size={32} />
                      <p className="text-gray-600">Loading dispensaries...</p>
                    </div>
                  </CardContent>
                </Card>
              ) : dispensaries.length > 0 ? (
                <>
                  <div className="text-sm text-gray-600 mb-4 text-center md:text-left">
                    Found {dispensaries.length} dispensaries nearby
                  </div>
                  <div className={`${view === 'list' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6' : 'space-y-4'}`}>
                    {dispensaries.map(place => (
                      <DispensaryCard 
                        key={place.place_id} 
                        place={place} 
                        onSelect={() => handleViewDetails(place)} 
                      />
                    ))}
                  </div>
                </>
              ) : !loading && location ? (
                <Card className="glass-card border-white/40">
                  <CardContent className="text-center py-12">
                    <MapPin className="w-12 h-12 md:w-16 md:h-16 mx-auto mb-4 text-gray-300" />
                    <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2">No dispensaries found</h3>
                    <p className="text-gray-600 text-sm md:text-base">Try expanding your search radius or check back later.</p>
                  </CardContent>
                </Card>
              ) : null}
            </div>
          </div>
        </div>
      </div>
      
      {selectedDispensary && (
        <DispensaryDetailsModal 
            isOpen={!!selectedDispensary}
            onClose={() => setSelectedDispensary(null)}
            details={details}
            isLoading={loadingDetails}
        />
      )}
    </div>
  );
}