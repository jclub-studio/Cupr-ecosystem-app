
import React, { useState, useEffect } from 'react';
import { SmokeCircle, User } from '@/entities/User';
import { SendEmail } from '@/integrations/Core';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
import { Users, Plus, Lock, Globe, Star, ShieldCheck, Loader2, Mail, X } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const CircleCard = ({ circle }) => {
  const getIcon = () => {
    switch (circle.circle_type) {
      case 'public':
        return <Globe className="w-4 h-4 text-blue-500" />;
      case 'exclusive':
        return <Star className="w-4 h-4 text-yellow-500" />;
      case 'private':
      default:
        return <Lock className="w-4 h-4 text-gray-500" />;
    }
  };

  return (
    <Link to={createPageUrl(`CircleDetails?id=${circle.id}`)}>
      <Card className="glass-card border-white/40 h-full flex flex-col group hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
        <CardHeader>
          <div className="flex justify-between items-start gap-3">
            <CardTitle className="text-base md:text-lg group-hover:text-green-600 transition-colors duration-200">
              {circle.name}
            </CardTitle>
            {getIcon()}
          </div>
          <CardDescription className="capitalize text-xs">{circle.circle_type} Circle</CardDescription>
        </CardHeader>
        <CardContent className="flex-grow">
          <p className="text-sm text-gray-600 line-clamp-2">{circle.description || 'No description provided.'}</p>
        </CardContent>
        <CardFooter>
          <div className="flex items-center text-sm text-gray-500">
            <Users className="w-4 h-4 mr-2" />
            <span>{circle.members?.length || 0} {circle.members?.length === 1 ? 'member' : 'members'}</span>
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
};

const CreateCircleForm = ({ onSubmit, onCancel, creating, currentUser }) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    circle_type: 'private',
    friendEmails: []
  });
  const [emailInput, setEmailInput] = useState('');

  const addEmail = (e) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const email = emailInput.trim().toLowerCase();
      if (email && !formData.friendEmails.includes(email) && email.includes('@')) {
        setFormData(prev => ({
          ...prev,
          friendEmails: [...prev.friendEmails, email]
        }));
        setEmailInput('');
      }
    }
  };

  const removeEmail = (emailToRemove) => {
    setFormData(prev => ({
      ...prev,
      friendEmails: prev.friendEmails.filter(email => email !== emailToRemove)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const typeDescriptions = {
    private: 'Only invited members can view and post.',
    public: 'Anyone can join, view, and post.',
    exclusive: 'Anyone can view the feed, but only verified members can post.'
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <div>
          <Label htmlFor="circle-name" className="text-sm font-medium text-gray-800">Circle Name</Label>
          <Input
            id="circle-name"
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            placeholder="e.g., Weekend Growers"
            className="mt-1 glass-card border-white/40"
          />
        </div>

        <div>
          <Label htmlFor="circle-description" className="text-sm font-medium text-gray-800">Description</Label>
          <Textarea
            id="circle-description"
            value={formData.description}
            onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
            placeholder="A short description of your circle's purpose"
            rows={3}
            className="mt-1 glass-card border-white/40"
          />
        </div>
        
        <div>
            <Label htmlFor="circle-type" className="text-sm font-medium text-gray-800">Circle Type</Label>
            <Select onValueChange={(value) => setFormData(prev => ({ ...prev, circle_type: value }))} defaultValue="private">
              <SelectTrigger id="circle-type" className="mt-1 glass-card border-white/40">
                <SelectValue placeholder="Select a circle type" />
              </SelectTrigger>
              <SelectContent className="glass-card">
                <SelectItem value="private"><div className="flex items-center gap-2"><Lock className="w-4 h-4"/>Private</div></SelectItem>
                <SelectItem value="public"><div className="flex items-center gap-2"><Globe className="w-4 h-4"/>Public</div></SelectItem>
                <SelectItem value="exclusive"><div className="flex items-center gap-2"><ShieldCheck className="w-4 h-4"/>Exclusive</div></SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-gray-600 mt-2">{typeDescriptions[formData.circle_type]}</p>
        </div>


        <div>
          <Label className="text-sm font-medium mb-3 block text-gray-800">Invite Friends (Optional)</Label>
          <div className="space-y-2">
            <Input
              value={emailInput}
              onChange={(e) => setEmailInput(e.target.value)}
              onKeyDown={addEmail}
              placeholder="Enter email, press Enter to add"
              className="text-sm glass-card border-white/40"
            />
            {formData.friendEmails.length > 0 && (
              <div className="flex flex-wrap gap-1 p-2 bg-gray-50/80 rounded-lg glass-card border-white/40">
                {formData.friendEmails.map(email => (
                  <Badge key={email} variant="secondary" className="text-xs flex items-center gap-1 glass-card border-white/40">
                    <Mail className="w-3 h-3" />
                    {email}
                    <button
                      type="button"
                      onClick={() => removeEmail(email)}
                      className="ml-1 text-red-500 hover:text-red-700"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4 border-t border-white/30">
        <Button type="button" variant="outline" onClick={onCancel} className="glass-card border-white/40 min-h-[44px]">
          Cancel
        </Button>
        <Button type="submit" disabled={creating || !formData.name.trim()} className="bg-green-600/90 hover:bg-green-700/90 min-h-[44px]">
          {creating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Creating...
            </>
          ) : (
            <>
              <Plus className="w-4 h-4 mr-2" />
              Create Circle
            </>
          )}
        </Button>
      </div>
    </form>
  );
};

export default function MyCircles() {
  const [circles, setCircles] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [showCreateForm, setShowCreateForm] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [user, allCirclesData] = await Promise.all([
        User.me(),
        SmokeCircle.list("-created_date")
      ]);
      setCurrentUser(user);
      // Filter for circles where the current user is a member
      const userCircles = allCirclesData.filter(c => c.members?.includes(user?.email));
      setCircles(userCircles);
    } catch (error) {
      console.error("Failed to load circles:", error);
      toast.error("Could not load circles. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCircle = async (formData) => {
    setCreating(true);
    try {
      const members = Array.from(new Set([currentUser.email, ...formData.friendEmails]));
      const owner = currentUser.email;

      const newCircleData = {
        name: formData.name,
        description: formData.description,
        circle_type: formData.circle_type,
        owner_email: owner,
        members: members,
      };

      if (formData.circle_type === 'exclusive') {
        newCircleData.verified_members = members; // Creator and invitees can post in exclusive circles
      } else {
        newCircleData.verified_members = [];
      }
      
      const newCircle = await SmokeCircle.create(newCircleData);

      if ((formData.circle_type === 'private' || formData.circle_type === 'exclusive') && formData.friendEmails.length > 0) {
        const invitePromises = formData.friendEmails.map(async (email) => {
          try {
            await SendEmail({
              to: email,
              subject: `You're invited to join "${formData.name}" on BudBook`,
              body: `${currentUser.full_name} has invited you to join their circle "${formData.name}" on BudBook.\n\n"${formData.description}"\n\nSign in to BudBook to see the circle.`
            });
          } catch (error) {
            console.error(`Failed to send invitation to ${email}:`, error);
          }
        });
        
        await Promise.all(invitePromises);
        toast.success(`Circle created and ${formData.friendEmails.length} invitations sent!`);
      } else {
        toast.success("Circle created successfully!");
      }

      setCircles(prev => [newCircle, ...prev]);
      setShowCreateForm(false);
    } catch (error) {
      console.error("Failed to create circle:", error);
      toast.error("Could not create circle. Please try again.");
    } finally {
      setCreating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-20">
        <Loader2 className="w-12 h-12 animate-spin text-green-600" />
      </div>
    );
  }

  return (
    <div className="p-3 md:p-6 pb-24 md:pb-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-6 md:mb-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">My Circles</h1>
            <p className="text-gray-600 text-sm md:text-base">Groups for shared experiences and discussions.</p>
          </div>
          <Dialog open={showCreateForm} onOpenChange={setShowCreateForm}>
            <DialogTrigger asChild>
              <Button className="min-h-[44px] bg-green-600/90 hover:bg-green-700/90 shadow-lg">
                <Plus className="w-4 h-4 mr-2" />
                Create Circle
              </Button>
            </DialogTrigger>
            <DialogContent className="w-[95vw] max-w-lg glass-card border-white/40">
              <DialogHeader>
                <DialogTitle>Create a New Circle</DialogTitle>
                <DialogDescription>
                  Start a new community. You'll be the owner.
                </DialogDescription>
              </DialogHeader>
              <CreateCircleForm
                currentUser={currentUser}
                onSubmit={handleCreateCircle}
                onCancel={() => setShowCreateForm(false)}
                creating={creating}
              />
            </DialogContent>
          </Dialog>
        </div>

        {loading ? (
          <div className="text-center p-10">
            <Loader2 className="w-8 h-8 animate-spin mx-auto text-gray-400" />
            <p className="mt-4 text-gray-500">Loading circles...</p>
          </div>
        ) : circles.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
            {circles.map(circle => (
              <CircleCard key={circle.id} circle={circle} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 px-6 glass-card rounded-2xl border-white/40">
            <div className="w-16 h-16 bg-green-100/80 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No circles yet</h3>
            <p className="text-gray-600 mb-6">Create your first circle to start a community.</p>
            <Button onClick={() => setShowCreateForm(true)} className="bg-green-600/90 hover:bg-green-700/90 shadow-lg">
              <Plus className="w-4 h-4 mr-2" />
              Create a Circle
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
