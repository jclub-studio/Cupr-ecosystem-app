import { Navigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Explore() {
  // This page now acts as a redirect to the default explore section.
  return <Navigate to={createPageUrl("Cannadex")} replace />;
}