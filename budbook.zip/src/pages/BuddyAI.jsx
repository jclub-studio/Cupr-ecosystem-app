import React, { useState, useEffect, useRef } from 'react';
import { User } from '@/entities/User';
import { SharedBuddyAIChat } from '@/entities/SharedBuddyAIChat';
import { agentSDK } from '@/agents';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import MessageBubble from '../components/agent/MessageBubble';
import {
  Send,
  Plus,
  MessageSquare,
  Brain,
  Share2,
  Loader2,
  Sparkles
} from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

export default function BuddyAI() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [currentConversation, setCurrentConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareTitle, setShareTitle] = useState('');
  const messagesEndRef = useRef(null);

  useEffect(() => {
    loadInitialData();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (currentConversation?.id) {
      const unsubscribe = agentSDK.subscribeToConversation(currentConversation.id, (data) => {
        setMessages(data.messages || []);
      });
      return () => {
        if (typeof unsubscribe === 'function') {
          unsubscribe();
        }
      };
    }
  }, [currentConversation?.id]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadInitialData = async () => {
    try {
      const [user, convos] = await Promise.all([
        User.me(),
        agentSDK.listConversations({ agent_name: 'buddyAI' })
      ]);
      setCurrentUser(user);
      setConversations(convos || []);
      
      if (convos && convos.length > 0) {
        const latestConvo = convos[0];
        setCurrentConversation(latestConvo);
        setMessages(latestConvo.messages || []);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const createNewConversation = async () => {
    try {
      const newConversation = await agentSDK.createConversation({
        agent_name: 'buddyAI',
        metadata: {
          name: 'New Chat',
          description: 'Cannabis consultation chat'
        }
      });
      
      setConversations(prev => [newConversation, ...prev]);
      setCurrentConversation(newConversation);
      setMessages([]);
    } catch (error) {
      console.error('Error creating conversation:', error);
      toast.error('Failed to create new conversation');
    }
  };

  const sendMessage = async () => {
    if (!inputMessage.trim() || !currentConversation || isLoading) return;

    setIsLoading(true);
    const messageContent = inputMessage.trim();
    setInputMessage('');

    try {
      await agentSDK.addMessage(currentConversation, {
        role: 'user',
        content: messageContent
      });
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message');
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const shareConversation = async () => {
    if (!currentConversation || !shareTitle.trim()) {
      toast.error('Please enter a title for the shared chat');
      return;
    }

    try {
      await SharedBuddyAIChat.create({
        original_conversation_id: currentConversation.id,
        messages: messages,
        shared_by: currentUser.email,
        title: shareTitle.trim()
      });
      
      toast.success('Chat shared successfully!');
      setShowShareModal(false);
      setShareTitle('');
    } catch (error) {
      console.error('Error sharing conversation:', error);
      toast.error('Failed to share chat');
    }
  };

  return (
    <div className="h-screen flex flex-col md:flex-row bg-gradient-to-br from-green-50/30 to-blue-50/30">
      {/* Sidebar */}
      <div className="w-full md:w-80 bg-white/90 backdrop-blur-xl border-b md:border-r border-white/30 shadow-xl flex flex-col">
        <div className="p-4 md:p-6 border-b border-white/30">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 to-green-600 shadow-lg flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Buddy AI</h1>
              <p className="text-sm text-gray-600">Cannabis Consultant</p>
            </div>
          </div>
          <Button 
            onClick={createNewConversation}
            className="w-full bg-green-600/90 hover:bg-green-700/90 min-h-[44px] shadow-lg font-medium"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Chat
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto p-3 md:p-4">
          <div className="space-y-2">
            {conversations.map((convo) => (
              <button
                key={convo.id}
                onClick={() => {
                  setCurrentConversation(convo);
                  setMessages(convo.messages || []);
                }}
                className={`w-full text-left p-3 rounded-lg transition-all duration-200 ${
                  currentConversation?.id === convo.id
                    ? 'bg-green-50/80 border border-green-200/50 shadow-sm'
                    : 'hover:bg-white/60 glass-card border-white/40'
                }`}
              >
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-gray-500 flex-shrink-0" />
                  <span className="text-sm font-medium text-gray-800 truncate">
                    {convo.metadata?.name || 'Untitled Chat'}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {currentConversation ? (
          <>
            {/* Chat Header */}
            <div className="p-3 md:p-4 bg-white/90 backdrop-blur-xl border-b border-white/30 shadow-sm">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-white" />
                  </div>
                  <h2 className="font-semibold text-gray-900 text-sm md:text-base">
                    {currentConversation.metadata?.name || 'Chat with Buddy'}
                  </h2>
                </div>
                <Dialog open={showShareModal} onOpenChange={setShowShareModal}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="glass-card border-white/40 hover:bg-white/60">
                      <Share2 className="w-4 h-4 mr-2" />
                      Share
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="glass-card border-white/40">
                    <DialogHeader>
                      <DialogTitle>Share Conversation</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="share-title">Chat Title</Label>
                        <Input
                          id="share-title"
                          value={shareTitle}
                          onChange={(e) => setShareTitle(e.target.value)}
                          placeholder="Give your chat a descriptive title"
                          className="glass-card border-white/40 mt-1"
                        />
                      </div>
                      <div className="flex justify-end gap-3">
                        <Button variant="outline" onClick={() => setShowShareModal(false)}>
                          Cancel
                        </Button>
                        <Button onClick={shareConversation} className="bg-green-600/90 hover:bg-green-700/90">
                          Share Chat
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-3 md:p-4 space-y-4">
              {messages.length === 0 ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-green-100/80 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Brain className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Start a conversation</h3>
                  <p className="text-gray-600 text-sm md:text-base max-w-md mx-auto">
                    Ask me anything about cannabis strains, effects, dosing, or get personalized recommendations based on your goals.
                  </p>
                </div>
              ) : (
                <>
                  {messages.map((message, index) => (
                    <MessageBubble key={index} message={message} />
                  ))}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="glass-card border-white/40 rounded-2xl px-4 py-3 max-w-xs">
                        <div className="flex items-center gap-2">
                          <Loader2 className="w-4 h-4 animate-spin text-green-600" />
                          <span className="text-sm text-gray-600">Buddy is thinking...</span>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-3 md:p-4 bg-white/90 backdrop-blur-xl border-t border-white/30">
              <div className="flex gap-2 md:gap-3">
                <div className="flex-1">
                  <Textarea
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyDown={handleKeyPress}
                    placeholder="Ask Buddy about strains, effects, dosing..."
                    className="glass-card border-white/40 resize-none min-h-[44px] max-h-32"
                    rows={1}
                  />
                </div>
                <Button
                  onClick={sendMessage}
                  disabled={!inputMessage.trim() || isLoading}
                  className="bg-green-600/90 hover:bg-green-700/90 min-w-[44px] min-h-[44px] self-end shadow-lg"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center p-6">
            <div className="text-center">
              <div className="w-20 h-20 bg-green-100/80 rounded-full flex items-center justify-center mx-auto mb-6">
                <Brain className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-3">Welcome to Buddy AI</h2>
              <p className="text-gray-600 mb-6 max-w-md mx-auto">
                Your personal cannabis consultant. Create a new chat to get started with personalized recommendations and insights.
              </p>
              <Button 
                onClick={createNewConversation}
                className="bg-green-600/90 hover:bg-green-700/90 min-h-[44px] px-6 font-medium shadow-lg"
              >
                <Plus className="w-4 h-4 mr-2" />
                Start Your First Chat
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}