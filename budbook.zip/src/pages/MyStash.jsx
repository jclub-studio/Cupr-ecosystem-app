import React, { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import StashTab from "../components/personal/StashTab";
import MyDispensaries from "../components/inventory/MyDispensaries";
import AccessoriesTab from "../components/inventory/AccessoriesTab";
import { Package, Store, Wrench } from "lucide-react";
import { useLocation } from "react-router-dom";

export default function MyStash() {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const initialTab = searchParams.get('tab') || 'products';
  const [activeTab, setActiveTab] = useState(initialTab);

  useEffect(() => {
    const tab = searchParams.get('tab');
    if (tab) {
      setActiveTab(tab);
    }
  }, [location.search]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50/30 to-blue-50/30 p-3 md:p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6">Stash</h1>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-white/80 backdrop-blur-sm p-1 rounded-xl shadow-sm">
            <TabsTrigger 
              value="products" 
              className="flex items-center gap-2 data-[state=active]:bg-green-600 data-[state=active]:text-white"
            >
              <Package className="w-4 h-4" />
              <span className="hidden sm:inline">Products</span>
            </TabsTrigger>
            <TabsTrigger 
              value="accessories"
              className="flex items-center gap-2 data-[state=active]:bg-green-600 data-[state=active]:text-white"
            >
              <Wrench className="w-4 h-4" />
              <span className="hidden sm:inline">Accessories</span>
            </TabsTrigger>
            <TabsTrigger 
              value="shops"
              className="flex items-center gap-2 data-[state=active]:bg-green-600 data-[state=active]:text-white"
            >
              <Store className="w-4 h-4" />
              <span className="hidden sm:inline">Shops</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="products" className="mt-6">
            <StashTab />
          </TabsContent>

          <TabsContent value="accessories" className="mt-6">
            <AccessoriesTab />
          </TabsContent>

          <TabsContent value="shops" className="mt-6">
            <MyDispensaries />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}