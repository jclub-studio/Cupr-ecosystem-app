import React from "react";
import DashboardTab from "../components/personal/DashboardTab";

export default function Personal() {
  return (
    <div className="min-h-screen p-4 md:p-6 pb-20 md:pb-6">
      <div className="max-w-7xl mx-auto">
        <DashboardTab />
      </div>
    </div>
  );
}