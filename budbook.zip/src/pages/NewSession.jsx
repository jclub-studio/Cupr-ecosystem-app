import React, { useState, useEffect, useCallback } from "react";
import { Session, UserInventory, Product, User, SocialPost, SmokeCircle } from "@/entities/all";
import { SendEmail, UploadFile } from "@/integrations/Core";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import {
  Save,
  Star,
  Leaf,
  Heart,
  HeartPulse,
  CheckCircle2,
  Plus,
  X,
  ExternalLink,
  Music,
  Video,
  Play,
  UserPlus,
  Mail,
  AlertCircle,
  Pencil,
  Camera,
  Headphones,
  Zap,
  ClipboardEdit,
  Loader2,
  Book,
  Send,
  Package
} from "lucide-react";
import { useNavigate, Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ActivitySelector from "../components/session/ActivitySelector";
import SessionLogCard from "../components/session/SessionLogCard";
import SessionImageCapture from "../components/session/SessionImageCapture";
import SessionColorPicker from "../components/session/SessionColorPicker";
import AccessorySelector from "../components/session/AccessorySelector";
import { cn } from "@/lib/utils";

const CONSUMPTION_METHODS = [
  "smoking", "vaporizing", "edibles", "tincture", "dabbing", "topical"
];

const METHOD_TAGS = ['Flavor', 'Smoothness', 'Burn Quality'];

const COMMON_EFFECTS = [
  "Relaxed", "Happy", "Euphoric", "Uplifted", "Energetic", "Focused",
  "Creative", "Sleepy", "Hungry", "Talkative", "Giggly", "Calm",
  "Pain Relief", "Stress Relief", "Anxiety Relief"
];

const SOLO_ACTIVITIES = [
  "Meditation", "Exercise", "Cooking", "Gaming", "Reading", "Music",
  "Movies", "Work", "Art/Creative", "Nature Walk", "Relaxing", "Sleep"
];

const SOCIAL_ACTIVITIES = [
  "Group Session", "Socializing", "Concert", "Sports Event",
  "Dinner Out", "Movie Night", "Party", "Networking", "Family Gathering", "Festival", "Date Night"
];

const MEDIA_PLATFORMS = [
  { value: "youtube", label: "YouTube", icon: Video },
  { value: "spotify", label: "Spotify", icon: Music },
  { value: "apple_music", label: "Apple Music", icon: Music },
  { value: "netflix", label: "Netflix", icon: Play },
  { value: "instagram", label: "Instagram", icon: Video },
  { value: "tiktok", label: "TikTok", icon: Video },
  { value: "other", label: "Other", icon: ExternalLink }
];

const inferConsumptionMethod = (productCategory) => {
  const categoryMethodMap = {
    "preroll": "smoking",
    "flower": "smoking",
    "vape": "vaporizing",
    "cartridge": "vaporizing",
    "oil": "dabbing",
    "concentrate": "dabbing",
    "edible": "edibles",
    "capsule": "edibles",
    "drink": "edibles",
    "tincture": "tincture",
    "topical": "topical"
  };
  return categoryMethodMap[productCategory.toLowerCase()] || "";
};

const MediaLinkInput = ({ onAdd }) => {
  const [url, setUrl] = useState('');
  const [platform, setPlatform] = useState('');

  const detectPlatform = (url) => {
    if (url.includes('youtube.com') || url.includes('youtu.be')) return 'youtube';
    if (url.includes('spotify.com')) return 'spotify';
    if (url.includes('music.apple.com')) return 'apple_music';
    if (url.includes('netflix.com')) return 'netflix';
    if (url.includes('instagram.com') || url.includes('instagram.com')) return 'instagram';
    if (url.includes('tiktok.com')) return 'tiktok';
    return 'other';
  };

  const handleUrlChange = (value) => {
    setUrl(value);
    if (value) {
      const detectedPlatform = detectPlatform(value);
      setPlatform(detectedPlatform);
    }
  };

  const handleAdd = () => {
    if (url && platform) {
      onAdd({
        url,
        platform,
        title: '',
        thumbnail_url: ''
      });
      setUrl('');
      setPlatform('');
    }
  };

  return (
    <div className="bg-white/60 backdrop-blur-sm rounded-xl border border-white/40 p-4">
      <div className="grid md:grid-cols-3 gap-3">
        <div className="md:col-span-2">
          <Input
            placeholder="Paste media link"
            value={url}
            onChange={(e) => handleUrlChange(e.target.value)}
            className="bg-white/80 border-gray-200 min-h-[52px] text-base"
            onFocus={(e) => {
              setTimeout(() => {
                e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }, 100);
            }}
          />
        </div>
        <Select value={platform} onValueChange={setPlatform}>
          <SelectTrigger className="bg-white/80 border-gray-200 min-h-[52px] text-base">
            <SelectValue placeholder="Platform" />
          </SelectTrigger>
          <SelectContent className="bg-white/95 backdrop-blur-md">
            {MEDIA_PLATFORMS.map(p => (
              <SelectItem key={p.value} value={p.value}>
                <div className="flex items-center gap-2">
                  <p.icon className="w-4 h-4" />
                  {p.label}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={handleAdd}
        disabled={!url || !platform}
        className="w-full mt-3 bg-white/80 border-gray-200 hover:bg-white min-h-[52px] text-base"
      >
        <Plus className="w-4 h-4 mr-2" />
        Add Media
      </Button>
    </div>
  );
};

const MediaItem = ({ media, onRemove }) => {
  const platform = MEDIA_PLATFORMS.find(p => p.value === media.platform);
  const Icon = platform?.icon || ExternalLink;

  return (
    <div className="flex items-center gap-3 p-3 bg-white/80 rounded-lg border border-gray-200">
      <Icon className="w-5 h-5 text-indigo-600 flex-shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm">{platform?.label || 'Unknown Platform'}</p>
        <p className="text-xs text-gray-500 truncate">{media.url}</p>
      </div>
      <Button
        type="button"
        variant="ghost"
        size="sm"
        onClick={onRemove}
        className="text-red-500 hover:text-red-700 hover:bg-red-50 min-h-[40px]"
      >
        <X className="w-4 h-4" />
      </Button>
    </div>
  );
};

const FriendTagInput = ({ onAdd, taggedFriends }) => {
  const [emailInput, setEmailInput] = useState('');

  const addFriend = (e) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const email = emailInput.trim().toLowerCase();
      if (email && !taggedFriends.includes(email) && email.includes('@')) {
        onAdd(email);
        setEmailInput('');
      }
    }
  };

  return (
    <div className="bg-white/60 backdrop-blur-sm rounded-xl border border-white/40 p-4">
      <Input
        placeholder="Enter friend's email address (press Enter to add)"
        value={emailInput}
        onChange={(e) => setEmailInput(e.target.value)}
        onKeyDown={addFriend}
        className="mb-3 bg-white/80 border-gray-200 min-h-[52px] text-base"
        onFocus={(e) => {
          setTimeout(() => {
            e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }, 100);
        }}
      />
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={() => {
          const email = emailInput.trim().toLowerCase();
          if (email && !taggedFriends.includes(email) && email.includes('@')) {
            onAdd(email);
            setEmailInput('');
          }
        }}
        disabled={!emailInput.trim() || !emailInput.includes('@')}
        className="w-full bg-white/80 border-gray-200 hover:bg-white min-h-[52px] text-base"
      >
        <UserPlus className="w-4 h-4 mr-2" />
        Tag Friend
      </Button>
    </div>
  );
};

const SaveOrPostDialog = ({ open, onOpenChange, onJournal, onPost, saving }) => (
  <Dialog open={open} onOpenChange={onOpenChange}>
    <DialogContent className="glass-card border-white/40">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-3 text-lg">
          <Save className="w-5 h-5 text-green-600"/>
          Save Session
        </DialogTitle>
        <DialogDescription>
          Save this session to your private journal, or post it to share with a circle.
        </DialogDescription>
      </DialogHeader>
      <DialogFooter className="gap-2 sm:justify-center">
        <Button variant="outline" className="w-full sm:w-auto glass-card min-h-[52px] text-base font-medium gap-2" onClick={onJournal} disabled={saving}>
          {saving ? <Loader2 className="w-4 h-4 animate-spin"/> : <Book className="w-4 h-4"/>}
          Save Only
        </Button>
        <Button className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 min-h-[52px] text-base font-medium gap-2" onClick={onPost} disabled={saving}>
          {saving ? <Loader2 className="w-4 h-4 animate-spin"/> : <Send className="w-4 h-4"/>}
          Post
        </Button>
      </DialogFooter>
    </DialogContent>
  </Dialog>
);

const PostToCircleDialog = ({ open, onOpenChange, session, onPostComplete }) => {
  const [circles, setCircles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newCircleName, setNewCircleName] = useState('');
  const [newCircleDescription, setNewCircleDescription] = useState('');
  const [newCircleIsPrivate, setNewCircleIsPrivate] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      if (!open) return;
      setLoading(true);
      setShowCreateForm(false);
      setNewCircleName('');
      setNewCircleDescription('');
      setNewCircleIsPrivate(true);

      const [user, userCircles] = await Promise.all([
        User.me(),
        SmokeCircle.list()
      ]);
      setCurrentUser(user);
      setCircles(userCircles);
      setLoading(false);
    };
    loadData();
  }, [open]);

  const handlePost = async (circleId) => {
    if (!session || !currentUser) return;
    setPosting(true);
    try {
      const product = await Product.get(session.product_id);
      const content = `Logged a session with ${product?.name || 'a cannabis product'}. Feeling: ${session.effects_felt.slice(0, 2).join(', ')}.`;

      await SocialPost.create({
        content,
        visibility: 'public',
        session_id: session.id,
        circle_id: circleId,
        author_name: currentUser.full_name,
        likes: [],
      });
      onPostComplete();
    } catch (error) {
      console.error("Failed to post:", error);
    } finally {
      setPosting(false);
    }
  };

  const handleCreateAndPost = async (e) => {
    e.preventDefault();
    if (!newCircleName.trim() || !currentUser) return;
    setPosting(true);
    try {
      const newCircle = await SmokeCircle.create({
        name: newCircleName,
        description: newCircleDescription,
        is_private: newCircleIsPrivate,
        members: [currentUser.email],
        owner_id: currentUser.id
      });
      await handlePost(newCircle.id);
      const updatedCircles = await SmokeCircle.list();
      setCircles(updatedCircles);
    } catch (error) {
      console.error("Failed to create circle and post:", error);
    } finally {
      setPosting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[95vw] max-w-lg h-[80vh] sm:max-h-[70vh] flex flex-col glass-card border-white/40">
        <DialogHeader>
          <DialogTitle>{showCreateForm ? 'Create & Post' : 'Post Session to a Circle'}</DialogTitle>
          <DialogDescription>
            {showCreateForm ? 'Create a new circle to share your session with.' : 'Select a circle to share your session log with.'}
          </DialogDescription>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto -mx-6 px-6 py-4 border-y border-white/30">
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <Loader2 className="w-8 h-8 animate-spin text-gray-400"/>
            </div>
          ) : showCreateForm ? (
            <form onSubmit={handleCreateAndPost} className="space-y-4">
              <div>
                <Label htmlFor="circle-name" className="text-sm font-medium text-gray-800 mb-2 block">Circle Name</Label>
                <Input
                  id="circle-name"
                  value={newCircleName}
                  onChange={(e) => setNewCircleName(e.target.value)}
                  placeholder="e.g., Weekend Warriors"
                  className="bg-white/80 border-gray-200 min-h-[52px] text-base"
                />
              </div>
              <div>
                <Label htmlFor="circle-desc" className="text-sm font-medium text-gray-800 mb-2 block">Description (Optional)</Label>
                <Textarea
                  id="circle-desc"
                  value={newCircleDescription}
                  onChange={(e) => setNewCircleDescription(e.target.value)}
                  placeholder="A group for weekend cannabis enthusiasts"
                  className="bg-white/80 border-gray-200 text-base min-h-[80px]"
                />
              </div>
              <div className="flex items-center space-x-2 pt-2">
                <Switch
                  id="is-private"
                  checked={newCircleIsPrivate}
                  onCheckedChange={setNewCircleIsPrivate}
                  className="data-[state=checked]:bg-blue-600"
                />
                <Label htmlFor="is-private">Private Circle</Label>
              </div>
              <div className="flex justify-end gap-3 pt-4">
                <Button type="button" variant="ghost" onClick={() => setShowCreateForm(false)} disabled={posting}>
                  Cancel
                </Button>
                <Button type="submit" disabled={posting || !newCircleName.trim()} className="bg-blue-600 hover:bg-blue-700 min-h-[52px] text-base font-medium gap-2">
                  {posting ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : <Send className="w-4 h-4 mr-2"/>}
                  Create & Post
                </Button>
              </div>
            </form>
          ) : (
            <div className="space-y-3">
              {circles.map(circle => (
                <button
                  key={circle.id}
                  onClick={() => handlePost(circle.id)}
                  disabled={posting}
                  className="w-full text-left p-4 rounded-lg bg-white/80 hover:bg-white border border-gray-200 transition-all flex items-center gap-3 disabled:opacity-50"
                >
                  <div className="flex-1">
                    <p className="font-medium">{circle.name}</p>
                    <p className="text-xs text-gray-500">{circle.description}</p>
                  </div>
                  {posting ? <Loader2 className="w-4 h-4 animate-spin"/> : <Send className="w-4 h-4 text-gray-400"/>}
                </button>
              ))}
               <Button variant="outline" onClick={() => setShowCreateForm(true)} className="w-full glass-card min-h-[52px] text-base font-medium gap-2">
                  <Plus className="w-4 h-4" /> Create New Circle
              </Button>
            </div>
          )}
        </div>
        <DialogFooter>
           <Button variant="ghost" onClick={() => onOpenChange(false)}>
             {showCreateForm ? 'Back to Circles' : 'Cancel'}
           </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default function NewSession() {
  const navigate = useNavigate();
  const location = useLocation();

  const [inventory, setInventory] = useState([]);
  const [products, setProducts] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [sessionImageFile, setSessionImageFile] = useState(null);
  const [sessionBackgroundColor, setSessionBackgroundColor] = useState(null);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showMethodNotes, setShowMethodNotes] = useState(false);
  const [activeModalStep, setActiveModalStep] = useState(null);
  const [showSaveOptionsDialog, setShowSaveOptionsDialog] = useState(false);
  const [showPostDialog, setShowPostDialog] = useState(false);
  const [newlySavedSession, setNewlySavedSession] = useState(null);

  const [formData, setFormData] = useState({
    session_name: "",
    product_id: "",
    date: new Date().toISOString().slice(0, 16),
    consumption_method: "",
    accessories_used: [],
    method_notes: "",
    method_tags: [],
    amount_consumed: "",
    amount_unit: "grams",
    effects_felt: [],
    mood_before: 5,
    mood_after: 5,
    pain_before: 0,
    pain_after: 0,
    anxiety_before: 0,
    anxiety_after: 0,
    notes: "",
    rating: 3,
    context: "",
    activities: [],
    shared_media: [],
    tagged_friends: [],
    confirmed_friends: [],
    session_image_url: "",
    session_background_color: "",
  });

  const searchParams = new URLSearchParams(location.search);
  const isFullscreen = searchParams.get('fullscreen') === 'true';
  const returnPath = searchParams.get('returnPath');

  const modalSteps = [
    { 
      id: 'product', 
      title: 'Product & Method', 
      subtitle: 'What did you consume and how?',
      icon: Leaf,
      color: 'bg-green-600'
    },
    { 
      id: 'accessories',
      title: 'Accessories',
      subtitle: 'What accessories did you use?',
      icon: Package,
      color: 'bg-purple-600'
    },
    { 
      id: 'details', 
      title: 'Activity & Time',
      subtitle: 'What were you doing and when?',
      icon: Zap,
      color: 'bg-blue-600'
    },
    { 
      id: 'effects', 
      title: 'Effects & Wellness', 
      subtitle: 'How did you feel before and after?',
      icon: HeartPulse,
      color: 'bg-emerald-600'
    },
    { 
      id: 'friends', 
      title: 'Friends', 
      subtitle: 'Who was part of this session?',
      icon: UserPlus,
      color: 'bg-indigo-600'
    },
    { 
      id: 'media', 
      title: 'Media', 
      subtitle: 'What were you listening to or watching?',
      icon: Headphones,
      color: 'bg-pink-600'
    },
    { 
      id: 'notes', 
      title: 'Notes', 
      subtitle: 'Any additional thoughts?',
      icon: ClipboardEdit,
      color: 'bg-gray-600'
    },
    { 
      id: 'camera', 
      title: 'Session Photo', 
      subtitle: 'Capture the moment',
      icon: Camera,
      color: 'bg-red-600'
    }
  ];

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [inventoryData, productsData, userData] = await Promise.all([
        UserInventory.filter({ is_active: true }, "-purchase_date"),
        Product.list("-created_date"),
        User.me()
      ]);

      setInventory(inventoryData);
      setProducts(productsData);
      setCurrentUser(userData);

      const urlParams = new URLSearchParams(window.location.search);
      const productId = urlParams.get('product');
      if (productId && productsData.length > 0) {
        const selectedProduct = productsData.find(p => p.id === productId);
        if (selectedProduct && selectedProduct.category) {
          const inferredMethod = inferConsumptionMethod(selectedProduct.category.toLowerCase());
          setFormData(prev => ({
            ...prev,
            product_id: productId,
            consumption_method: inferredMethod || prev.consumption_method
          }));
        } else {
          setFormData(prev => ({ ...prev, product_id: productId }));
        }
      }
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  const getProductById = useCallback((productId) => {
    return products.find(p => p.id === productId);
  }, [products]);

  const generateDefaultSessionName = useCallback((productId, date) => {
    const product = getProductById(productId);
    if (!product) return '';

    const sessionDate = new Date(date);
    const dateStr = sessionDate.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });

    const strainName = product.strain_name || product.name;
    const type = product.type ? product.type.charAt(0).toUpperCase() + product.type.slice(1) : '';

    return `${strainName} ${type} - ${dateStr}`;
  }, [getProductById]);

  const handleInputChange = (field, value) => {
    const updates = { [field]: value };

    if (field === 'product_id' && value) {
      const selectedProduct = getProductById(value);
      if (selectedProduct && selectedProduct.category) {
        const inferredMethod = inferConsumptionMethod(selectedProduct.category.toLowerCase());
        if (inferredMethod) {
          updates.consumption_method = inferredMethod;
        }
      }
      const prevDefaultName = formData.product_id ? generateDefaultSessionName(formData.product_id, formData.date) : "";
      if (!formData.session_name || formData.session_name === prevDefaultName) {
        updates.session_name = generateDefaultSessionName(value, formData.date);
      }
    }

    if (field === 'date' && formData.product_id) {
      const currentDefaultName = generateDefaultSessionName(formData.product_id, formData.date);
      if (!formData.session_name || formData.session_name === currentDefaultName) {
        updates.session_name = generateDefaultSessionName(formData.product_id, value);
      }
    }

    setFormData(prev => ({ ...prev, ...updates }));
  };

  const handleSessionNameChange = (name) => {
    setFormData(prev => ({ ...prev, session_name: name }));
  };

  const handleArrayToggle = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter(item => item !== value)
        : [...prev[field], value]
    }));
  };

  const handleMethodTagToggle = (tag) => {
    handleArrayToggle('method_tags', tag);
  };

  const handleMethodNotesToggle = (checked) => {
    setShowMethodNotes(checked);
  };

  const addMediaLink = (mediaData) => {
    setFormData(prev => ({
      ...prev,
      shared_media: [...prev.shared_media, mediaData]
    }));
  };

  const removeMediaLink = (index) => {
    setFormData(prev => ({
      ...prev,
      shared_media: prev.shared_media.filter((_, i) => i !== index)
    }));
  };

  const addTaggedFriend = (email) => {
    setFormData(prev => ({
      ...prev,
      tagged_friends: [...prev.tagged_friends, email]
    }));
  };

  const removeTaggedFriend = (email) => {
    setFormData(prev => ({
      ...prev,
      tagged_friends: prev.tagged_friends.filter(friend => friend !== email)
    }));
  };

  const handleImageSelect = (image) => {
    setSessionImageFile(image);
    if (image) {
      setSessionBackgroundColor(null);
      setFormData(prev => ({ ...prev, session_background_color: "" }));
    }
  };

  const handleColorSelect = (color) => {
    setSessionBackgroundColor(color);
    setShowColorPicker(false);
    if (color) {
      setSessionImageFile(null);
      setFormData(prev => ({ ...prev, session_background_color: color, session_image_url: "" }));
    }
  };

  const saveSession = async () => {
    if (!formData.product_id) {
      setError("Please select a product");
      return null;
    }
    if (!currentUser) {
      setError("User data not loaded. Please try again.");
      return null;
    }

    try {
      let imageUrl = null;
      if (sessionImageFile instanceof File) {
        const { file_url } = await UploadFile({ file: sessionImageFile, folder: "session_images" });
        imageUrl = file_url;
      } else if (typeof sessionImageFile === 'string' && sessionImageFile.startsWith('data:')) {
        const response = await fetch(sessionImageFile);
        const blob = await response.blob();
        const file = new File([blob], `session-image-${Date.now()}.png`, { type: 'image/png' });
        const { file_url } = await UploadFile({ file, folder: "session_images" });
        imageUrl = file_url;
      }
      
      const sessionName = formData.session_name || generateDefaultSessionName(formData.product_id, formData.date);
      
      const sessionDataForApi = { ...formData };
      if (sessionDataForApi.amount_consumed === "" || isNaN(sessionDataForApi.amount_consumed)) {
        sessionDataForApi.amount_consumed = null;
      } else {
        sessionDataForApi.amount_consumed = Number(sessionDataForApi.amount_consumed);
      }

      const sessionData = {
        ...sessionDataForApi,
        session_image_url: imageUrl,
        session_background_color: sessionBackgroundColor,
        session_name: sessionName
      };

      const session = await Session.create(sessionData);

      if (formData.tagged_friends.length > 0) {
        const selectedProduct = getProductById(formData.product_id);
        const invitePromises = formData.tagged_friends.map(async (email) => {
          try {
            const confirmationUrl = `${window.location.origin}${createPageUrl("ConfirmSessionParticipation")}`;
            const urlWithParams = new URL(confirmationUrl);
            urlWithParams.searchParams.append("session_id", session.id);
            urlWithParams.searchParams.append("inviter_email", currentUser.email);

            await SendEmail({
              to: email,
              subject: `${currentUser.full_name} has tagged you in a session on BudBook`,
              body: `${currentUser.full_name} has invited you to confirm participation in their session with ${selectedProduct?.name || 'a cannabis product'}.\n\nTo confirm your participation and have this session appear in your journal, click here: ${urlWithParams.toString()}\n\nIf you weren't part of this session, you can simply ignore this email.`
            });
          } catch (error) {
            console.error(`Failed to send invitation to ${email}:`, error);
          }
        });

        await Promise.all(invitePromises);
      }
      return session;
    } catch (err) {
      setError(err.message || "Failed to save session");
      return null;
    }
  };
  
  const handleSubmitTrigger = async (e) => {
    e?.preventDefault();
    if (isFullscreen) {
      setShowSaveOptionsDialog(true);
    } else {
      setSaving(true);
      const session = await saveSession();
      if(session) {
        navigate(createPageUrl("Journal"));
      }
      setSaving(false);
    }
  };

  const handleSaveJournalOnly = async () => {
    setSaving(true);
    const session = await saveSession();
    if (session) {
      setShowSaveOptionsDialog(false);
      navigate(createPageUrl("Journal"));
    }
    setSaving(false);
  };

  const handleSaveAndInitiatePost = async () => {
    setSaving(true);
    const session = await saveSession();
    if (session) {
      setNewlySavedSession(session);
      setShowSaveOptionsDialog(false);
      setShowPostDialog(true);
    }
    setSaving(false);
  };

  const handlePostComplete = () => {
    setShowPostDialog(false);
    navigate(returnPath || createPageUrl("Journal"));
  };

  const handleExit = () => {
    navigate(returnPath || createPageUrl("Personal"));
  };

  const selectedProduct = getProductById(formData.product_id);
  const isSocialSession = formData.activities.some(activity =>
    SOCIAL_ACTIVITIES.includes(activity)
  );

  const handleSectionClick = (sectionId) => {
    setActiveModalStep(sectionId);
  };

  const closeModal = () => {
    setActiveModalStep(null);
  };

  const formDataWithStrain = {
    ...formData,
    strain_name: selectedProduct?.strain_name
  };
  
  const hasContentCheck = (sectionId) => {
    switch (sectionId) {
      case 'product': return !!formData?.product_id;
      case 'accessories': return formData?.accessories_used?.length > 0;
      case 'details': return !!(formData?.date && formData?.activities?.length > 0);
      case 'friends': return formData?.tagged_friends?.length > 0;
      case 'media': return formData?.shared_media?.length > 0;
      case 'effects': return formData?.effects_felt?.length > 0 ||
                            formData?.mood_before !== 5 || formData?.mood_after !== 5 ||
                            formData?.pain_before !== 0 || formData?.pain_after !== 0 ||
                            formData?.anxiety_before !== 0 || formData?.anxiety_after !== 0 ||
                            formData?.rating !== 3;
      case 'notes': return !!formData?.notes;
      case 'camera': return !!sessionImageFile || !!formData?.session_image_url;
      case 'color': return !!sessionBackgroundColor;
      default: return false;
    }
  };

  useEffect(() => {
    if (formData.product_id && !formData.session_name) {
      const defaultName = generateDefaultSessionName(formData.product_id, formData.date);
      if (defaultName) {
        setFormData(prev => ({ ...prev, session_name: defaultName }));
      }
    }
  }, [formData.product_id, formData.date, formData.session_name, generateDefaultSessionName]);

  const renderModalContent = () => {
    const activeStep = modalSteps.find(step => step.id === activeModalStep);
    if (!activeStep) return null;

    const { id, title, subtitle, icon: Icon, color } = activeStep;

    return (
      <DialogContent className="w-[95vw] max-w-4xl h-[90vh] sm:h-auto sm:max-h-[85vh] flex flex-col glass-card border-white/40 mx-auto">
        <DialogHeader className="pb-4 flex-shrink-0">
          <DialogTitle className="flex items-center gap-3 text-lg">
            <div className={`w-7 h-7 rounded-lg ${color} flex items-center justify-center`}>
              <Icon className="w-4 h-4 text-white" />
            </div>
            {title}
          </DialogTitle>
          <DialogDescription>{subtitle}</DialogDescription>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto px-1 pb-4">
          {id === 'product' && (
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-gray-800 mb-2 block">Select Product</Label>
                <div className="flex flex-col gap-3">
                  <Select value={formData.product_id} onValueChange={(value) => handleInputChange('product_id', value)}>
                    <SelectTrigger className="w-full bg-white/80 border-gray-200 min-h-[52px] text-base">
                      <SelectValue placeholder="Choose from your stash" />
                    </SelectTrigger>
                    <SelectContent className="bg-white/95 backdrop-blur-md">
                      {inventory.map((item) => {
                        const product = getProductById(item.product_id);
                        return product ? (
                          <SelectItem key={item.id} value={item.product_id}>
                            <div className="flex flex-col gap-1 py-1">
                              <span className="font-medium">{product.name}</span>
                              <div className="flex items-center gap-2 text-xs text-gray-500">
                                <span>{product.type}</span>
                                <Badge variant="outline" className="text-xs">{product.category}</Badge>
                              </div>
                            </div>
                          </SelectItem>
                        ) : null;
                      })}
                    </SelectContent>
                  </Select>
                  <Link to={createPageUrl("Scanner")} className="w-full">
                    <Button variant="outline" className="w-full bg-white/80 border-gray-200 hover:bg-white min-h-[52px] text-base">
                      <Plus className="w-4 h-4 mr-2" /> Add New Product
                    </Button>
                  </Link>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium text-gray-800 mb-2 block">Consumption Method</Label>
                <Select value={formData.consumption_method} onValueChange={(value) => handleInputChange('consumption_method', value)}>
                  <SelectTrigger className="bg-white/80 border-gray-200 min-h-[52px] text-base">
                    <SelectValue placeholder="How did you consume?" />
                  </SelectTrigger>
                  <SelectContent className="bg-white/95 backdrop-blur-md">
                    {CONSUMPTION_METHODS.map(method => (
                      <SelectItem key={method} value={method}>
                        {method.charAt(0).toUpperCase() + method.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium text-gray-800 mb-2 block">Amount Consumed</Label>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    step="0.1"
                    value={formData.amount_consumed}
                    onChange={(e) => handleInputChange('amount_consumed', e.target.value)}
                    className="flex-1 bg-white/80 border-gray-200 min-h-[52px] text-base"
                    onFocus={(e) => {
                      setTimeout(() => {
                        e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                      }, 100);
                    }}
                  />
                  <Select value={formData.amount_unit} onValueChange={(value) => handleInputChange('amount_unit', value)}>
                    <SelectTrigger className="w-24 bg-white/80 border-gray-200 min-h-[52px] text-base">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white/95 backdrop-blur-md">
                      <SelectItem value="grams">g</SelectItem>
                      <SelectItem value="mg">mg</SelectItem>
                      <SelectItem value="ml">ml</SelectItem>
                      <SelectItem value="puffs">puffs</SelectItem>
                      <SelectItem value="drops">drops</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-white/80 rounded-lg p-4 border border-gray-200">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2 text-sm font-medium cursor-pointer">
                      <Pencil className="w-4 h-4 text-blue-600" />
                      Add Method Notes
                    </Label>
                    <Switch
                      checked={showMethodNotes}
                      onCheckedChange={handleMethodNotesToggle}
                      className="data-[state=checked]:bg-blue-600"
                    />
                  </div>
                </div>

                {showMethodNotes && (
                  <div className="bg-white/60 backdrop-blur-sm rounded-xl border border-white/40 p-4 space-y-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-800 mb-2 block">Notes</Label>
                      <Textarea
                        value={formData.method_notes}
                        onChange={(e) => handleInputChange('method_notes', e.target.value)}
                        placeholder="e.g., Very smooth, earthy taste..."
                        className="min-h-[100px] bg-white/80 border-gray-200 text-base"
                        onFocus={(e) => {
                          setTimeout(() => {
                            e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                          }, 100);
                        }}
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-800 mb-3 block">Tags</Label>
                      <div className="flex flex-wrap gap-2">
                        {METHOD_TAGS.map(tag => (
                          <Button
                            key={tag}
                            type="button"
                            variant="outline"
                            onClick={() => handleMethodTagToggle(tag)}
                            className={cn(
                              "text-sm rounded-lg border transition-all min-h-[44px]",
                              formData.method_tags.includes(tag)
                                ? 'bg-blue-600 text-white border-blue-600 hover:bg-blue-700'
                                : 'bg-white/80 border-gray-200 hover:bg-white'
                            )}
                          >
                            {formData.method_tags.includes(tag) && <CheckCircle2 className="w-3 h-3 mr-1" />}
                            {tag}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {id === 'accessories' && (
            <div className="space-y-4">
              <AccessorySelector
                selectedAccessoryIds={formData.accessories_used}
                onAccessoriesChange={(accessories) => handleInputChange('accessories_used', accessories)}
              />
            </div>
          )}

          {id === 'details' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-800 mb-2 block">Date & Time</Label>
                  <Input
                    type="datetime-local"
                    value={formData.date}
                    onChange={(e) => handleInputChange('date', e.target.value)}
                    className="bg-white/80 border-gray-200 min-h-[52px] text-base"
                    onFocus={(e) => {
                      setTimeout(() => {
                        e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                      }, 100);
                    }}
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-gray-200/60">
                <Label className="text-sm font-medium text-gray-800 mb-4 block">Activities & Context</Label>
                <ActivitySelector
                  selectedActivities={formData.activities}
                  onToggleActivity={(activity) => handleArrayToggle('activities', activity)}
                />
              </div>
            </div>
          )}

          {id === 'camera' && (
            <SessionImageCapture
              onImageSelect={handleImageSelect}
              currentImage={sessionImageFile}
            />
          )}

          {id === 'friends' && (
            <div className="space-y-6">
              {isSocialSession && formData.tagged_friends.length === 0 && (
                <Alert className="bg-blue-50/80 border-blue-200">
                  <AlertCircle className="h-4 w-4 text-blue-600" />
                  <AlertDescription className="text-blue-800">
                    You've selected a social activity! Consider tagging friends who were part of this session.
                  </AlertDescription>
                </Alert>
              )}

              <p className="text-gray-600 text-sm">
                Tag friends who were part of this session. They'll receive an invitation to confirm their participation.
              </p>

              <FriendTagInput onAdd={addTaggedFriend} taggedFriends={formData.tagged_friends} />

              {formData.tagged_friends.length > 0 && (
                <div className="space-y-4">
                  <Label className="text-sm font-medium text-gray-800 block">Tagged Friends ({formData.tagged_friends.length})</Label>
                  <div className="space-y-2">
                    {formData.tagged_friends.map((email, index) => (
                      <div key={index} className="flex items-center gap-3 p-3 bg-white/80 rounded-lg border border-gray-200">
                        <Mail className="w-4 h-4 text-indigo-600 flex-shrink-0" />
                        <span className="flex-1 text-sm">{email}</span>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeTaggedFriend(email)}
                          className="text-red-500 hover:text-red-700 hover:bg-red-50 min-h-[40px]"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {id === 'media' && (
            <div className="space-y-6">
              <p className="text-gray-600 text-sm">
                Add links to music, videos, or other media you enjoyed during this session.
              </p>

              <MediaLinkInput onAdd={addMediaLink} />

              {formData.shared_media.length > 0 && (
                <div className="space-y-4">
                  <Label className="text-sm font-medium text-gray-800 block">Added Media ({formData.shared_media.length})</Label>
                  <div className="space-y-2">
                    {formData.shared_media.map((media, index) => (
                      <MediaItem
                        key={index}
                        media={media}
                        onRemove={() => removeMediaLink(index)}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {id === 'effects' && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label className="flex items-center gap-2 text-sm font-medium text-gray-800 mb-2 block">
                    <Heart className="w-4 h-4" />
                    Mood Before (1-10)
                  </Label>
                  <div>
                    <Slider
                      value={[formData.mood_before]}
                      onValueChange={(value) => handleInputChange('mood_before', value[0])}
                      min={1}
                      max={10}
                      step={1}
                      className="mb-2"
                    />
                    <div className="text-center text-lg font-medium text-gray-800 p-4 bg-white/80 rounded-lg border border-gray-200">
                      {formData.mood_before}/10
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="flex items-center gap-2 text-sm font-medium text-gray-800 mb-2 block">
                    <Heart className="w-4 h-4" />
                    Mood After (1-10)
                  </Label>
                  <div>
                    <Slider
                      value={[formData.mood_after]}
                      onValueChange={(value) => handleInputChange('mood_after', value[0])}
                      min={1}
                      max={10}
                      step={1}
                      className="mb-2"
                    />
                    <div className="text-center text-lg font-medium text-gray-800 p-4 bg-white/80 rounded-lg border border-gray-200">
                      {formData.mood_after}/10
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { key: 'pain_before', label: 'Pain Before (0-10)' },
                  { key: 'pain_after', label: 'Pain After (0-10)' },
                  { key: 'anxiety_before', label: 'Anxiety Before (0-10)' },
                  { key: 'anxiety_after', label: 'Anxiety After (0-10)' }
                ].map(({ key, label }) => (
                  <div key={key}>
                    <Label className="text-xs font-medium text-gray-800 mb-2 block">{label}</Label>
                    <div>
                      <Slider
                        value={[formData[key]]}
                        onValueChange={(value) => handleInputChange(key, value[0])}
                        min={0}
                        max={10}
                        step={1}
                        className="mb-2"
                      />
                      <div className="text-center text-sm font-medium p-2 bg-white/80 rounded-lg border border-gray-200">
                        {formData[key]}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div>
                <Label className="text-sm font-medium text-gray-800 mb-4 block">Effects Experienced</Label>
                <div className="flex flex-wrap gap-2">
                  {COMMON_EFFECTS.map(effect => (
                    <Button
                      key={effect}
                      type="button"
                      variant="outline"
                      onClick={() => handleArrayToggle('effects_felt', effect)}
                      className={cn(
                        "text-sm rounded-lg border transition-all min-h-[44px]",
                        formData.effects_felt.includes(effect)
                          ? 'bg-green-600 text-white border-green-600 hover:bg-green-700'
                          : 'bg-white/80 border-gray-200 hover:bg-white'
                      )}
                    >
                      {formData.effects_felt.includes(effect) && <CheckCircle2 className="w-3 h-3 mr-1" />}
                      {effect}
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <Label className="flex items-center gap-2 mb-4 text-sm font-medium text-gray-800 block">
                  <Star className="w-4 h-4" />
                  Overall Rating
                </Label>
                <div className="flex gap-2 justify-center md:justify-start">
                  {[1, 2, 3, 4, 5].map(star => (
                    <Star
                      key={star}
                      className={`w-12 h-12 cursor-pointer transition-all duration-200 ${
                        star <= formData.rating ? 'text-yellow-400 fill-current drop-shadow-md' : 'text-gray-300'
                      }`}
                      onClick={() => handleInputChange('rating', star)}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {id === 'notes' && (
            <Textarea
              value={formData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              placeholder="Additional thoughts, observations, or notes about this session..."
              className="min-h-[200px] bg-white/80 border-gray-200 text-base resize-none"
              onFocus={(e) => {
                setTimeout(() => {
                  e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }, 100);
              }}
            />
          )}
        </div>
        <DialogFooter className="flex-shrink-0 px-1">
          <Button
            type="button"
            variant="outline"
            onClick={closeModal}
            className="glass-card border-white/40 hover:bg-white/60 min-h-[52px] px-6 text-base"
          >
            Done
          </Button>
        </DialogFooter>
      </DialogContent>
    );
  };

  if (loading) {
    return (
      <div className="p-4 md:p-6 pb-24 md:pb-6">
        <div className="animate-pulse max-w-4xl mx-auto space-y-6">
          <div className="h-8 bg-gray-200/60 rounded-xl mb-8"></div>
          <div className="h-96 bg-gray-200/60 rounded-3xl"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50/30 p-2 md:p-6 pb-24 md:pb-6">
      <form onSubmit={handleSubmitTrigger} className="max-w-screen-2xl mx-auto space-y-4 md:space-y-8">
        <div className="text-center">
          <h1 className="text-2xl md:text-3xl font-light text-gray-900 mb-2">New Session Log</h1>
        </div>

        {error && (
          <Alert variant="destructive" className="bg-red-50/80 border-red-200 max-w-4xl mx-auto">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          <div className="lg:sticky lg:top-24">
            <SessionLogCard
              sessionImage={sessionImageFile}
              sessionBackgroundColor={sessionBackgroundColor}
              onSectionClick={handleSectionClick}
              onColorPickerClick={() => setShowColorPicker(true)}
              formData={formDataWithStrain}
              onSessionNameChange={handleSessionNameChange}
              products={products}
              onSave={handleSubmitTrigger}
              onCancel={isFullscreen ? handleExit : () => navigate(createPageUrl("Journal"))}
              isSavingDisabled={saving || !formData.product_id}
              saving={saving}
            />
          </div>

          <div className="hidden lg:block space-y-6">
            <div className="glass-card p-6 rounded-2xl border-white/40">
              <h3 className="font-semibold text-lg mb-4 flex items-center gap-3"><Leaf className="w-5 h-5 text-green-600" />Product & Method</h3>
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-gray-800 mb-2 block">Select Product</Label>
                  <div className="flex flex-col gap-3">
                    <Select value={formData.product_id} onValueChange={(value) => handleInputChange('product_id', value)}>
                      <SelectTrigger className="w-full bg-white/80 border-gray-200 min-h-[48px] text-base">
                        <SelectValue placeholder="Choose from your stash" />
                      </SelectTrigger>
                      <SelectContent className="bg-white/95 backdrop-blur-md">
                        {inventory.map((item) => {
                          const product = getProductById(item.product_id);
                          return product ? (
                            <SelectItem key={item.id} value={item.product_id}>
                              <div className="flex flex-col gap-1 py-1">
                                <span className="font-medium">{product.name}</span>
                                <div className="flex items-center gap-2 text-xs text-gray-500">
                                  <span>{product.type}</span>
                                  <Badge variant="outline" className="text-xs">{product.category}</Badge>
                                </div>
                              </div>
                            </SelectItem>
                          ) : null;
                        })}
                      </SelectContent>
                    </Select>
                    <Link to={createPageUrl("Scanner")} className="w-full">
                      <Button variant="outline" className="w-full bg-white/80 border-gray-200 hover:bg-white min-h-[48px] text-base">
                        <Plus className="w-4 h-4 mr-2" /> Add New Product
                      </Button>
                    </Link>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-800 mb-2 block">Consumption Method</Label>
                  <Select value={formData.consumption_method} onValueChange={(value) => handleInputChange('consumption_method', value)}>
                    <SelectTrigger className="bg-white/80 border-gray-200 min-h-[48px] text-base">
                      <SelectValue placeholder="How did you consume?" />
                    </SelectTrigger>
                    <SelectContent className="bg-white/95 backdrop-blur-md">
                      {CONSUMPTION_METHODS.map(method => (
                        <SelectItem key={method} value={method}>{method.charAt(0).toUpperCase() + method.slice(1)}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-800 mb-2 block">Amount Consumed</Label>
                  <div className="flex gap-2">
                    <Input type="number" step="0.1" value={formData.amount_consumed} onChange={(e) => handleInputChange('amount_consumed', e.target.value)} className="flex-1 bg-white/80 border-gray-200 min-h-[48px] text-base" placeholder="0.5" />
                    <Select value={formData.amount_unit} onValueChange={(value) => handleInputChange('amount_unit', value)}>
                      <SelectTrigger className="w-24 bg-white/80 border-gray-200 min-h-[48px] text-base"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-white/95 backdrop-blur-md">
                        <SelectItem value="grams">g</SelectItem><SelectItem value="mg">mg</SelectItem><SelectItem value="ml">ml</SelectItem><SelectItem value="puffs">puffs</SelectItem><SelectItem value="drops">drops</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between bg-white/80 rounded-lg p-4 border border-gray-200">
                    <Label className="flex items-center gap-2 text-sm font-medium cursor-pointer">
                      <Pencil className="w-4 h-4 text-blue-600" />
                      Add Method Notes
                    </Label>
                    <Switch
                      checked={showMethodNotes}
                      onCheckedChange={handleMethodNotesToggle}
                      className="data-[state=checked]:bg-blue-600"
                    />
                  </div>

                  {showMethodNotes && (
                    <div className="bg-white/60 backdrop-blur-sm rounded-xl border border-white/40 p-4 space-y-4">
                      <div>
                        <Label className="text-sm font-medium text-gray-800 mb-2 block">Notes</Label>
                        <Textarea
                          value={formData.method_notes}
                          onChange={(e) => handleInputChange('method_notes', e.target.value)}
                          placeholder="e.g., Very smooth, earthy taste..."
                          className="min-h-[100px] bg-white/80 border-gray-200 text-base"
                        />
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-800 mb-3 block">Tags</Label>
                        <div className="flex flex-wrap gap-2">
                          {METHOD_TAGS.map(tag => (
                            <Button
                              key={tag}
                              type="button"
                              variant="outline"
                              onClick={() => handleMethodTagToggle(tag)}
                              className={cn(
                                "text-sm rounded-lg border transition-all min-h-[44px]",
                                formData.method_tags.includes(tag)
                                  ? 'bg-blue-600 text-white border-blue-600 hover:bg-blue-700'
                                  : 'bg-white/80 border-gray-200 hover:bg-white'
                              )}
                            >
                              {formData.method_tags.includes(tag) && <CheckCircle2 className="w-3 h-3 mr-1" />}
                              {tag}
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="glass-card p-6 rounded-2xl border-white/40">
              <h3 className="font-semibold text-lg mb-4 flex items-center gap-3"><Package className="w-5 h-5 text-purple-600" />Accessories Used</h3>
              <AccessorySelector
                selectedAccessoryIds={formData.accessories_used}
                onAccessoriesChange={(accessories) => handleInputChange('accessories_used', accessories)}
              />
            </div>

            <div className="glass-card p-6 rounded-2xl border-white/40">
              <h3 className="font-semibold text-lg mb-4 flex items-center gap-3"><Zap className="w-5 h-5 text-blue-600" />Activity & Time</h3>
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-gray-800 mb-2 block">Date & Time</Label>
                  <Input type="datetime-local" value={formData.date} onChange={(e) => handleInputChange('date', e.target.value)} className="bg-white/80 border-gray-200 min-h-[48px] text-base" />
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-800 mb-2 block">Activities & Context</Label>
                  <ActivitySelector selectedActivities={formData.activities} onToggleActivity={(activity) => handleArrayToggle('activities', activity)} />
                </div>
              </div>
            </div>

            <div className="glass-card p-6 rounded-2xl border-white/40">
              <h3 className="font-semibold text-lg mb-4 flex items-center gap-3"><HeartPulse className="w-5 h-5 text-emerald-600" />Wellness</h3>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="flex items-center gap-2 text-sm font-medium text-gray-800 mb-2 block">
                      <Heart className="w-4 h-4" />
                      Mood Before (1-10)
                    </Label>
                    <div>
                      <Slider
                        value={[formData.mood_before]}
                        onValueChange={(value) => handleInputChange('mood_before', value[0])}
                        min={1}
                        max={10}
                        step={1}
                        className="mb-2"
                      />
                      <div className="text-center text-sm font-medium text-gray-700 mt-2">
                        {formData.mood_before}/10
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label className="flex items-center gap-2 text-sm font-medium text-gray-800 mb-2 block">
                      <Heart className="w-4 h-4" />
                      Mood After (1-10)
                    </Label>
                    <div>
                      <Slider
                        value={[formData.mood_after]}
                        onValueChange={(value) => handleInputChange('mood_after', value[0])}
                        min={1}
                        max={10}
                        step={1}
                        className="mb-2"
                      />
                      <div className="text-center text-sm font-medium text-gray-700 mt-2">
                        {formData.mood_after}/10
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { key: 'pain_before', label: 'Pain Before (0-10)' },
                    { key: 'pain_after', label: 'Pain After (0-10)' },
                    { key: 'anxiety_before', label: 'Anxiety Before (0-10)' },
                    { key: 'anxiety_after', label: 'Anxiety After (0-10)' }
                  ].map(({ key, label }) => (
                    <div key={key}>
                      <Label className="text-xs font-medium text-gray-800 mb-2 block">{label}</Label>
                      <div>
                        <Slider
                          value={[formData[key]]}
                          onValueChange={(value) => handleInputChange(key, value[0])}
                          min={0}
                          max={10}
                          step={1}
                          className="mb-2"
                        />
                        <div className="text-center text-sm font-medium p-2 bg-white/80 rounded-lg border border-gray-200">
                          {formData[key]}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div>
                  <Label className="text-sm font-medium text-gray-800 mb-4 block">Effects Experienced</Label>
                  <div className="flex flex-wrap gap-2">
                    {COMMON_EFFECTS.map(effect => (
                      <Button key={effect} type="button" variant="outline" onClick={() => handleArrayToggle('effects_felt', effect)}
                        className={cn("text-sm rounded-lg border transition-all min-h-[44px]", formData.effects_felt.includes(effect) ? 'bg-green-600 text-white border-green-600 hover:bg-green-700' : 'bg-white/80 border-gray-200 hover:bg-white')}>
                        {formData.effects_felt.includes(effect) && <CheckCircle2 className="w-3 h-3 mr-1" />}
                        {effect}
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="flex items-center gap-2 mb-4 text-sm font-medium text-gray-800 block"><Star className="w-4 h-4" />Overall Rating</Label>
                  <div className="flex gap-2 justify-center">
                    {[1, 2, 3, 4, 5].map(star => (
                      <Star key={star} className={`w-10 h-10 cursor-pointer transition-all duration-200 ${star <= formData.rating ? 'text-yellow-400 fill-current drop-shadow-md' : 'text-gray-300'}`} onClick={() => handleInputChange('rating', star)} />
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="glass-card p-6 rounded-2xl border-white/40">
              <h3 className="font-semibold text-lg mb-4 flex items-center gap-3"><ClipboardEdit className="w-5 h-5 text-gray-600" />Notes</h3>
              <Textarea value={formData.notes} onChange={(e) => handleInputChange('notes', e.target.value)} placeholder="Additional thoughts, observations, or notes..." className="min-h-[150px] bg-white/80 border-gray-200 text-base resize-none" />
            </div>

            <div className="grid grid-cols-2 gap-4">
                <Button type="button" variant="outline" className="glass-card min-h-[52px] text-base font-medium gap-2" onClick={() => handleSectionClick('friends')}><UserPlus className="w-5 h-5 text-indigo-600"/>Social</Button>
                <Button type="button" variant="outline" className="glass-card min-h-[52px] text-base font-medium gap-2" onClick={() => handleSectionClick('media')}><Headphones className="w-5 h-5 text-pink-600"/>Media</Button>
            </div>
          </div>
        </div>

        <SaveOrPostDialog 
          open={showSaveOptionsDialog} 
          onOpenChange={setShowSaveOptionsDialog}
          onJournal={handleSaveJournalOnly}
          onPost={handleSaveAndInitiatePost}
          saving={saving}
        />
        <PostToCircleDialog
          open={showPostDialog}
          onOpenChange={setShowPostDialog}
          session={newlySavedSession}
          onPostComplete={handlePostComplete}
        />

        <Dialog open={!!activeModalStep} onOpenChange={(open) => !open && closeModal()}>
          {renderModalContent()}
        </Dialog>

        <SessionColorPicker
          open={showColorPicker}
          onOpenChange={setShowColorPicker}
          onColorSelect={handleColorSelect}
        />
      </form>
    </div>
  );
}