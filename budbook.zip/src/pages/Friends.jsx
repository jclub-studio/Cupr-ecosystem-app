import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  UserPlus,
  Users,
  Search,
  UserCheck,
  Loader2,
  Heart,
  MessageSquare,
  CheckCircle2,
  Clock,
  X,
  Send,
  Mail,
  ContactRound,
  Share2,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';

const FriendRequestCard = ({ request, onRespond, loading }) => (
  <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
    <CardContent className="p-4">
      <div className="flex items-center gap-3">
        <Avatar className="w-12 h-12">
          <AvatarImage src={request.sender_profile_photo_url} />
          <AvatarFallback className="bg-green-100 text-green-600 font-semibold">
            {request.sender_username?.charAt(0).toUpperCase() || 'U'}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900">@{request.sender_username}</h3>
          <p className="text-sm text-gray-600 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Friend request
          </p>
          {request.message && (
            <p className="text-xs text-gray-500 mt-1 line-clamp-2">"{request.message}"</p>
          )}
        </div>
        <div className="flex gap-2">
          <Button
            size="sm"
            onClick={() => onRespond(request.id, 'accept')}
            disabled={loading}
            className="bg-green-600/90 hover:bg-green-700/90 text-white"
          >
            {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle2 className="w-3 h-3" />}
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => onRespond(request.id, 'decline')}
            disabled={loading}
            className="border-red-200 text-red-600 hover:bg-red-50"
          >
            <X className="w-3 h-3" />
          </Button>
        </div>
      </div>
    </CardContent>
  </Card>
);

const UserCard = ({ user, currentUser, onSendRequest, sending }) => {
  const isFriend = currentUser?.friends?.includes(user.email);
  const isSelf = currentUser?.email === user.email;

  return (
    <Card className="glass-card border-white/40 hover:shadow-xl transition-all duration-300">
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <Avatar className="w-12 h-12">
            <AvatarImage src={user.profile_photo_url} />
            <AvatarFallback className="bg-purple-100 text-purple-600 font-semibold">
              {user.username?.charAt(0).toUpperCase() || user.full_name?.charAt(0).toUpperCase() || 'U'}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-gray-900 truncate">@{user.username}</h3>
            {user.full_name && <p className="text-sm text-gray-600 truncate">{user.full_name}</p>}
            {user.bio && (
              <p className="text-xs text-gray-500 mt-1 line-clamp-1">{user.bio}</p>
            )}
          </div>
          {isSelf ? (
            <Badge variant="secondary" className="glass-card border-white/40">
              You
            </Badge>
          ) : isFriend ? (
            <Badge className="bg-green-100 text-green-700 border-green-200">
              <UserCheck className="w-3 h-3 mr-1" />
              Friends
            </Badge>
          ) : (
            <Button
              size="sm"
              onClick={() => onSendRequest(user.username)}
              disabled={sending}
              className="min-h-[36px] bg-blue-600/90 hover:bg-blue-700/90 text-white"
            >
              {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default function Friends() {
  const [currentUser, setCurrentUser] = useState(null);
  const [allUsers, setAllUsers] = useState([]);
  const [friendRequests, setFriendRequests] = useState([]);
  const [searchResults, setSearchResults] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteMessage, setInviteMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [sending, setSending] = useState(false);
  const [respondingToRequest, setRespondingToRequest] = useState(false);
  const [sendingInvite, setSendingInvite] = useState(false);
  const [selectedContacts, setSelectedContacts] = useState([]);
  const [contactPickerSupported, setContactPickerSupported] = useState(false);

  useEffect(() => {
    loadUserData();
    // Check if Contact Picker API is supported
    setContactPickerSupported('contacts' in navigator && 'ContactsManager' in window);
  }, []);

  useEffect(() => {
    if (searchTerm.length >= 2) {
      handleSearch();
    } else {
      setSearchResults([]);
    }
  }, [searchTerm]);

  const loadUserData = async () => {
    setLoading(true);
    try {
      const [user, requests, users] = await Promise.all([
        base44.auth.me(),
        base44.entities.FriendRequest.list('-created_date'),
        base44.entities.User.list()
      ]);
      
      setCurrentUser(user);
      setFriendRequests(requests);
      setAllUsers(users);
    } catch (error) {
      console.error('Error loading user data:', error);
      toast.error('Failed to load friends data');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    setSearching(true);
    try {
      const { data } = await base44.functions.invoke('searchUsers', { 
        search_query: searchTerm 
      });
      
      if (data.success) {
        setSearchResults(data.users || []);
      } else {
        toast.error(data.message || 'Search failed');
      }
    } catch (error) {
      console.error('Error searching users:', error);
      toast.error('Search failed');
    } finally {
      setSearching(false);
    }
  };

  const handleSendRequest = async (receiverUsername) => {
    setSending(true);
    try {
      const { data } = await base44.functions.invoke('sendFriendRequest', {
        receiver_username: receiverUsername,
        message: ''
      });

      if (data.success) {
        toast.success('Friend request sent!');
        await loadUserData();
      } else {
        toast.error(data.message || 'Failed to send request');
      }
    } catch (error) {
      console.error('Error sending friend request:', error);
      toast.error('Failed to send request');
    } finally {
      setSending(false);
    }
  };

  const handleRespondToRequest = async (requestId, action) => {
    setRespondingToRequest(true);
    try {
      const { data } = await base44.functions.invoke('respondToFriendRequest', {
        request_id: requestId,
        action: action
      });

      if (data.success) {
        toast.success(data.message);
        await loadUserData();
      } else {
        toast.error(data.message || 'Failed to respond to request');
      }
    } catch (error) {
      console.error('Error responding to friend request:', error);
      toast.error('Failed to respond to friend request');
    } finally {
      setRespondingToRequest(false);
    }
  };

  const handlePickContacts = async () => {
    try {
      const props = ['email', 'name'];
      const opts = { multiple: true };
      
      const contacts = await navigator.contacts.select(props, opts);
      
      const contactsWithEmails = contacts.filter(contact => 
        contact.email && contact.email.length > 0
      ).map(contact => ({
        name: contact.name?.[0] || 'Unknown',
        email: contact.email[0]
      }));

      setSelectedContacts(prev => {
        const existing = new Set(prev.map(c => c.email));
        const newContacts = contactsWithEmails.filter(c => !existing.has(c.email));
        return [...prev, ...newContacts];
      });

      if (contactsWithEmails.length > 0) {
        toast.success(`Selected ${contactsWithEmails.length} contact(s)`);
      } else {
        toast.info('No contacts with email addresses found');
      }
    } catch (error) {
      if (error.name === 'AbortError') {
        // User cancelled, no action needed
      } else {
        console.error('Error picking contacts:', error);
        toast.error('Failed to access contacts');
      }
    }
  };

  const handleRemoveContact = (email) => {
    setSelectedContacts(prev => prev.filter(c => c.email !== email));
  };

  const handleSendInvites = async () => {
    const emailsToInvite = selectedContacts.length > 0 
      ? selectedContacts.map(c => c.email)
      : inviteEmail.trim() ? [inviteEmail.trim()] : [];

    if (emailsToInvite.length === 0) {
      toast.error('Please enter an email address or select contacts');
      return;
    }

    setSendingInvite(true);
    try {
      const appUrl = window.location.origin;
      const defaultMessage = `Join me on BudBook! Sign up at ${appUrl} and add me as a friend (@${currentUser?.username})`;
      const message = inviteMessage || defaultMessage;

      const sendPromises = emailsToInvite.map(email =>
        base44.integrations.Core.SendEmail({
          to: email,
          subject: `${currentUser?.full_name || 'A friend'} invited you to BudBook`,
          body: message
        })
      );

      await Promise.all(sendPromises);
      toast.success(`Invitation${emailsToInvite.length > 1 ? 's' : ''} sent!`);
      
      setInviteEmail('');
      setInviteMessage('');
      setSelectedContacts([]);
    } catch (error) {
      console.error('Error sending invites:', error);
      toast.error('Failed to send invitations');
    } finally {
      setSendingInvite(false);
    }
  };

  const handleShareInvite = async () => {
    if (!navigator.share) {
      toast.error('Sharing is not supported on this device');
      return;
    }

    try {
      const appUrl = window.location.origin;
      const shareText = `Join me on BudBook! ${appUrl}\n\nAdd me: @${currentUser?.username}`;
      
      await navigator.share({
        title: 'Join me on BudBook',
        text: shareText
      });
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error('Error sharing:', error);
      }
    }
  };

  const pendingRequests = friendRequests.filter(r => r.status === 'pending' && r.receiver_email === currentUser?.email);
  const friends = currentUser?.friends?.map(email => allUsers.find(u => u.email === email)).filter(Boolean) || [];

  if (loading) {
    return (
      <div className="p-3 md:p-6 pb-24 md:pb-6">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200/80 rounded w-1/4"></div>
            <div className="h-24 bg-gray-200/80 rounded-xl"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map(i => <div key={i} className="h-32 bg-gray-200/80 rounded-xl"></div>)}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-3 md:p-6 pb-24 md:pb-6">
      <div className="max-w-6xl mx-auto space-y-6 md:space-y-8">
        <div className="mb-6 md:mb-8 text-center md:text-left">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">Friends</h1>
          <p className="text-gray-600 text-sm md:text-base">Connect with others and grow your circle.</p>
        </div>

        <Tabs defaultValue="friends" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 glass-card p-1 h-auto">
            <TabsTrigger value="friends" className="data-[state=active]:bg-white/90 data-[state=active]:shadow-md">
              My Friends
            </TabsTrigger>
            <TabsTrigger value="requests" className="data-[state=active]:bg-white/90 data-[state=active]:shadow-md relative">
              Requests
              {pendingRequests.length > 0 && (
                <Badge className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center p-0 bg-red-500 text-white">
                  {pendingRequests.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="search" className="data-[state=active]:bg-white/90 data-[state=active]:shadow-md">
              Search
            </TabsTrigger>
            <TabsTrigger value="invite" className="data-[state=active]:bg-white/90 data-[state=active]:shadow-md">
              Invite
            </TabsTrigger>
          </TabsList>

          <TabsContent value="friends" className="mt-6">
            <Card className="glass-card border-white/40">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-purple-600" />
                  Your Friends
                </CardTitle>
                <CardDescription>{friends.length} {friends.length === 1 ? 'friend' : 'friends'}</CardDescription>
              </CardHeader>
              <CardContent>
                {friends.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {friends.map(friend => (
                      <UserCard key={friend.id} user={friend} currentUser={currentUser} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No friends yet</h3>
                    <p className="text-gray-600 mb-6">Start building your cannabis community by searching for users to connect with.</p>
                    <div className="flex flex-wrap justify-center gap-2">
                      <Badge variant="outline" className="glass-card border-white/40">
                        <Heart className="w-3 h-3 mr-1" />
                        Share sessions
                      </Badge>
                      <Badge variant="outline" className="glass-card border-white/40">
                        <MessageSquare className="w-3 h-3 mr-1" />
                        Connect & chat
                      </Badge>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="requests" className="mt-6">
            <Card className="glass-card border-white/40">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-green-600" />
                  Friend Requests ({pendingRequests.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {pendingRequests.length > 0 ? (
                  <div className="space-y-4">
                    {pendingRequests.map(request => (
                      <FriendRequestCard 
                        key={request.id} 
                        request={request} 
                        onRespond={handleRespondToRequest}
                        loading={respondingToRequest}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <UserPlus className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No pending requests</h3>
                    <p className="text-gray-600">When someone sends you a friend request, it will appear here.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="search" className="mt-6">
            <Card className="glass-card border-white/40">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="w-5 h-5 text-blue-600" />
                  Search for Users
                </CardTitle>
                <CardDescription>Find users by their username.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2 mb-6">
                  <Input
                    type="text"
                    placeholder="Enter username..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="flex-grow glass-card border-white/40"
                  />
                  <Button onClick={handleSearch} disabled={searching || searchTerm.length < 2} className="bg-blue-600/90 hover:bg-blue-700/90">
                    {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                  </Button>
                </div>

                {searching && (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
                    <span className="ml-2 text-gray-600">Searching...</span>
                  </div>
                )}

                {!searching && searchTerm.length >= 2 && searchResults.length > 0 && (
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg text-gray-900">Search Results</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {searchResults.map(user => (
                        <UserCard 
                          key={user.id} 
                          user={user} 
                          currentUser={currentUser}
                          onSendRequest={handleSendRequest}
                          sending={sending}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {!searching && searchTerm.length >= 2 && searchResults.length === 0 && (
                  <div className="text-center py-8">
                    <Search className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No users found</h3>
                    <p className="text-gray-600">Try adjusting your search terms.</p>
                  </div>
                )}

                {!searching && searchTerm.length < 2 && (
                  <div className="text-center py-8">
                    <Search className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Start typing to search</h3>
                    <p className="text-gray-600">Enter at least 2 characters to find users.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="invite" className="mt-6">
            <Card className="glass-card border-white/40">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="w-5 h-5 text-indigo-600" />
                  Invite Friends
                </CardTitle>
                <CardDescription>Invite people to join BudBook via email or contacts.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {contactPickerSupported && (
                  <div>
                    <Label className="text-sm font-medium mb-3 block">Select from Contacts</Label>
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={handlePickContacts}
                        className="flex-1 glass-card border-white/40 hover:bg-purple-50/80"
                      >
                        <ContactRound className="w-4 h-4 mr-2" />
                        Pick Contacts
                      </Button>
                      {navigator.share && (
                        <Button
                          type="button"
                          variant="outline"
                          onClick={handleShareInvite}
                          className="flex-1 glass-card border-white/40 hover:bg-blue-50/80"
                        >
                          <Share2 className="w-4 h-4 mr-2" />
                          Share Invite
                        </Button>
                      )}
                    </div>

                    {selectedContacts.length > 0 && (
                      <div className="mt-4 space-y-2">
                        <Label className="text-sm font-medium">Selected Contacts ({selectedContacts.length})</Label>
                        <div className="space-y-2 max-h-48 overflow-y-auto">
                          {selectedContacts.map((contact, index) => (
                            <div key={index} className="flex items-center gap-3 p-3 bg-white/80 rounded-lg border border-gray-200">
                              <ContactRound className="w-4 h-4 text-purple-600 flex-shrink-0" />
                              <div className="flex-1 min-w-0">
                                <p className="font-medium text-sm truncate">{contact.name}</p>
                                <p className="text-xs text-gray-500 truncate">{contact.email}</p>
                              </div>
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => handleRemoveContact(contact.email)}
                                className="text-red-500 hover:text-red-700 hover:bg-red-50 min-h-[40px]"
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {!contactPickerSupported && (
                  <Alert className="bg-blue-50/80 border-blue-200">
                    <AlertCircle className="h-4 w-4 text-blue-600" />
                    <AlertDescription className="text-blue-800 text-sm">
                      Contact picker is not supported on this browser. Please enter email addresses manually or use the share feature.
                    </AlertDescription>
                  </Alert>
                )}

                <div className="border-t border-gray-200 pt-6">
                  <Label htmlFor="invite-email" className="text-sm font-medium mb-2 block">
                    {selectedContacts.length > 0 ? 'Or Enter Email Address' : 'Email Address *'}
                  </Label>
                  <Input
                    id="invite-email"
                    type="email"
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                    placeholder="friend@example.com"
                    className="glass-card border-white/40"
                    disabled={selectedContacts.length > 0}
                  />
                </div>

                <div>
                  <Label htmlFor="invite-message">Custom Message (Optional)</Label>
                  <Textarea
                    id="invite-message"
                    value={inviteMessage}
                    onChange={(e) => setInviteMessage(e.target.value)}
                    placeholder="Add a personal message..."
                    className="mt-1 glass-card border-white/40 min-h-[100px]"
                  />
                </div>

                <Button 
                  onClick={handleSendInvites} 
                  disabled={sendingInvite || (selectedContacts.length === 0 && !inviteEmail.trim())}
                  className="w-full bg-indigo-600/90 hover:bg-indigo-700/90"
                >
                  {sendingInvite ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Send {selectedContacts.length > 0 ? `${selectedContacts.length} ` : ''}Invitation{selectedContacts.length > 1 ? 's' : ''}
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}