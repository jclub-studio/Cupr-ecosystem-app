import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Store, 
  MapPin, 
  Phone, 
  Globe, 
  Star, 
  Heart,
  Search,
  Plus,
  Loader2,
  Navigation,
  Sparkles
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

const ShopCard = ({ shop, onToggleFavorite }) => {
  const shopTypeConfig = {
    dispensary: {
      color: "bg-green-500/10 text-green-700 border-green-500/20",
      label: "Dispensary"
    },
    smoke_accessory_shop: {
      color: "bg-blue-500/10 text-blue-700 border-blue-500/20",
      label: "Accessory Shop"
    },
    other: {
      color: "bg-gray-500/10 text-gray-700 border-gray-500/20",
      label: "Shop"
    }
  };

  const config = shopTypeConfig[shop.shop_type] || shopTypeConfig.other;

  return (
    <Card className="glass-card border-white/40 hover:shadow-xl hover:scale-[1.02] transition-all duration-300 group overflow-hidden">
      <CardHeader className="pb-3 bg-gradient-to-br from-white/50 to-transparent">
        <div className="flex justify-between items-start gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-start gap-2 mb-2">
              <div className="p-2 rounded-lg bg-gradient-to-br from-green-400/20 to-green-600/20 group-hover:scale-110 transition-transform">
                <Store className="w-4 h-4 text-green-700" />
              </div>
              <div className="flex-1 min-w-0">
                <CardTitle className="text-base md:text-lg leading-tight mb-1 group-hover:text-green-600 transition-colors duration-200 truncate">
                  {shop.name}
                </CardTitle>
                <Badge className={`text-xs ${config.color} backdrop-blur-sm`}>
                  {config.label}
                </Badge>
              </div>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(shop);
            }}
            className={`transition-all flex-shrink-0 ${
              shop.is_favorite 
                ? 'text-red-500 hover:text-red-600' 
                : 'text-gray-300 hover:text-red-500'
            }`}
          >
            <Heart className={`w-5 h-5 ${shop.is_favorite ? 'fill-current' : ''}`} />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3">
        {/* Address */}
        {shop.address && (
          <div className="flex items-start gap-2 text-sm text-gray-600 bg-white/40 rounded-lg p-2">
            <MapPin className="w-4 h-4 flex-shrink-0 mt-0.5 text-gray-500" />
            <span className="line-clamp-2 text-xs">{shop.address}</span>
          </div>
        )}

        {/* Quick Info */}
        <div className="flex flex-wrap gap-2">
          {shop.loyalty_program_id && (
            <div className="flex items-center gap-1.5 px-2 py-1 bg-yellow-50/80 rounded-md text-xs">
              <Star className="w-3 h-3 text-yellow-600" />
              <span className="text-yellow-800 font-medium">Rewards Member</span>
            </div>
          )}
          {shop.favorite_budtenders && shop.favorite_budtenders.length > 0 && (
            <div className="flex items-center gap-1.5 px-2 py-1 bg-purple-50/80 rounded-md text-xs">
              <Sparkles className="w-3 h-3 text-purple-600" />
              <span className="text-purple-800 font-medium">{shop.favorite_budtenders.length} Budtender{shop.favorite_budtenders.length > 1 ? 's' : ''}</span>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-2 border-t border-white/30">
          {shop.google_maps_url && (
            <Button
              variant="outline"
              size="sm"
              asChild
              className="flex-1 glass-card border-white/40 hover:bg-green-50/80 text-xs h-8"
            >
              <a href={shop.google_maps_url} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()}>
                <Navigation className="w-3 h-3 mr-1.5" />
                Directions
              </a>
            </Button>
          )}
          {shop.phone && (
            <Button
              variant="outline"
              size="sm"
              asChild
              className="flex-1 glass-card border-white/40 hover:bg-blue-50/80 text-xs h-8"
            >
              <a href={`tel:${shop.phone}`} onClick={(e) => e.stopPropagation()}>
                <Phone className="w-3 h-3 mr-1.5" />
                Call
              </a>
            </Button>
          )}
          {shop.website && (
            <Button
              variant="outline"
              size="sm"
              asChild
              className="flex-1 glass-card border-white/40 hover:bg-purple-50/80 text-xs h-8"
            >
              <a href={shop.website} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()}>
                <Globe className="w-3 h-3 mr-1.5" />
                Website
              </a>
            </Button>
          )}
        </div>

        {/* Notes Preview */}
        {shop.notes && (
          <div className="text-xs text-gray-600 bg-blue-50/50 rounded-lg p-2 line-clamp-2 italic">
            "{shop.notes}"
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default function Shops() {
  const [shops, setShops] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);

  useEffect(() => {
    loadShops();
  }, []);

  const loadShops = async () => {
    try {
      const shopsData = await base44.entities.Dispensary.list('-created_date');
      setShops(shopsData);
    } catch (error) {
      console.error('Error loading shops:', error);
      toast.error('Failed to load shops');
    } finally {
      setLoading(false);
    }
  };

  const toggleFavorite = async (shop) => {
    try {
      const updatedShop = { ...shop, is_favorite: !shop.is_favorite };
      await base44.entities.Dispensary.update(shop.id, { is_favorite: updatedShop.is_favorite });
      setShops(prev => prev.map(s => s.id === shop.id ? updatedShop : s));
      toast.success(updatedShop.is_favorite ? 'Added to favorites' : 'Removed from favorites');
    } catch (error) {
      console.error('Error updating favorite status:', error);
      toast.error('Failed to update favorite');
    }
  };

  const filteredShops = shops.filter(shop => {
    const matchesSearch = shop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         shop.address?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || shop.shop_type === filterType;
    const matchesFavorites = !showFavoritesOnly || shop.is_favorite;
    return matchesSearch && matchesType && matchesFavorites;
  });

  const favoriteShops = shops.filter(shop => shop.is_favorite);
  const stats = {
    total: shops.length,
    favorites: favoriteShops.length,
    dispensaries: shops.filter(s => s.shop_type === 'dispensary').length,
    accessoryShops: shops.filter(s => s.shop_type === 'smoke_accessory_shop').length
  };

  if (loading) {
    return (
      <div className="p-3 md:p-6 pb-24 md:pb-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="w-12 h-12 text-green-600 animate-spin" />
              <p className="text-gray-600 font-medium">Loading your shops...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-3 md:p-6 pb-24 md:pb-6">
      <div className="max-w-6xl mx-auto space-y-6 md:space-y-8">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">My Shops</h1>
          <p className="text-gray-600 text-sm md:text-base">Your saved dispensaries and cannabis retailers</p>
        </div>

        {/* Stats Cards */}
        {shops.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            <Card className="glass-card border-white/40 hover:shadow-lg transition-all">
              <CardContent className="p-4 text-center">
                <div className="text-2xl md:text-3xl font-bold text-gray-900 mb-1">{stats.total}</div>
                <p className="text-xs text-gray-600">Total Shops</p>
              </CardContent>
            </Card>
            <Card className="glass-card border-white/40 hover:shadow-lg transition-all">
              <CardContent className="p-4 text-center">
                <div className="text-2xl md:text-3xl font-bold text-red-500 mb-1">{stats.favorites}</div>
                <p className="text-xs text-gray-600">Favorites</p>
              </CardContent>
            </Card>
            <Card className="glass-card border-white/40 hover:shadow-lg transition-all">
              <CardContent className="p-4 text-center">
                <div className="text-2xl md:text-3xl font-bold text-green-600 mb-1">{stats.dispensaries}</div>
                <p className="text-xs text-gray-600">Dispensaries</p>
              </CardContent>
            </Card>
            <Card className="glass-card border-white/40 hover:shadow-lg transition-all">
              <CardContent className="p-4 text-center">
                <div className="text-2xl md:text-3xl font-bold text-blue-600 mb-1">{stats.accessoryShops}</div>
                <p className="text-xs text-gray-600">Accessory Shops</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Filters and Search */}
        <Card className="glass-card border-white/40">
          <CardContent className="p-4 md:p-6">
            <div className="flex flex-col md:flex-row gap-3">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search by name or location..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 glass-card border-white/40 min-h-[44px]"
                />
              </div>
              
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full md:w-48 glass-card border-white/40 min-h-[44px]">
                  <SelectValue placeholder="Shop Type" />
                </SelectTrigger>
                <SelectContent className="glass-card border-white/40">
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="dispensary">Dispensaries</SelectItem>
                  <SelectItem value="smoke_accessory_shop">Accessory Shops</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>

              <Button
                variant={showFavoritesOnly ? "default" : "outline"}
                onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
                className={`min-h-[44px] px-4 ${
                  showFavoritesOnly 
                    ? 'bg-red-600/90 hover:bg-red-700/90' 
                    : 'glass-card border-white/40 hover:bg-red-50/80'
                }`}
              >
                <Heart className={`w-4 h-4 mr-2 ${showFavoritesOnly ? 'fill-current' : ''}`} />
                <span className="hidden md:inline">Favorites</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Add New Shop Button */}
        <div className="flex justify-center">
          <Link to={createPageUrl("FindDispensary")}>
            <Button className="bg-green-600/90 hover:bg-green-700/90 min-h-[48px] px-8 font-medium shadow-lg hover:shadow-xl transition-all">
              <Plus className="w-5 h-5 mr-2" />
              Find New Shops
            </Button>
          </Link>
        </div>

        {/* Shop Grid */}
        {filteredShops.length === 0 ? (
          <Card className="glass-card border-white/40">
            <CardContent className="text-center py-12 md:py-20">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-green-100 to-green-200 flex items-center justify-center">
                <Store className="w-10 h-10 text-green-600" />
              </div>
              <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2">
                {shops.length === 0 ? 'No shops saved yet' : 'No shops found'}
              </h3>
              <p className="text-gray-600 text-sm md:text-base mb-6 max-w-md mx-auto">
                {shops.length === 0 
                  ? 'Start building your shop collection by finding dispensaries near you.'
                  : 'Try adjusting your search terms or filters.'
                }
              </p>
              {shops.length === 0 && (
                <Link to={createPageUrl("FindDispensary")}>
                  <Button className="bg-green-600/90 hover:bg-green-700/90 min-h-[44px] px-6 font-medium">
                    <Plus className="w-4 h-4 mr-2" />
                    Find Your First Shop
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-600">
                Showing {filteredShops.length} of {shops.length} shop{shops.length !== 1 ? 's' : ''}
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
              {filteredShops.map((shop) => (
                <ShopCard
                  key={shop.id}
                  shop={shop}
                  onToggleFavorite={toggleFavorite}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}