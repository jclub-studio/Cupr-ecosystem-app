
import React, { useState, useEffect } from "react";
import { Link, useLocation, Navigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Home,
  QrCode,
  Package,
  BookOpen,
  Database,
  Plus,
  Compass,
  BrainCircuit,
  Users,
  Sparkles,
  LayoutGrid,
  GraduationCap,
  User,
  UserRound,
  Store,
  MonitorPlay } from
"lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger } from
"@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent } from
"@/components/ui/sidebar";
import { Button } from "@/components/ui/button";

const mainTabs = [
{ title: "Personal", page: "Personal", icon: Home },
{ title: "Social", page: "Social", icon: Users },
{ title: "Explore", page: "Explore", icon: Compass }];


const quickActions = [
{ title: "Add to Stash", icon: QrCode, page: "Scanner" },
{ title: "Log Session", icon: Plus, page: "NewSession" },
{ title: "Buddy AI", icon: BrainCircuit, page: "BuddyAI" },
{ title: "Find Dispensary", icon: Database, page: "FindDispensary" }];


const personalNavItems = [
{ title: "Dashboard", icon: Home, page: "Personal" },
{ title: "My Stash", icon: Package, page: "MyStash" },
{ title: "Journal", icon: BookOpen, page: "Journal" }];


const socialNavItems = [
{ title: "Circles", icon: Users, page: "MyCircles" },
{ title: "Friends", icon: UserRound, page: "Friends" },
{ title: "Shops", icon: Store, page: "Shops" },
{ title: "Media", icon: MonitorPlay, page: "Media" }];


const exploreNavItems = [
{ title: "Cannadex", icon: LayoutGrid, page: "Cannadex" },
{ title: "Learn", icon: GraduationCap, page: "Learn" },
{ title: "Dispensaries", icon: Database, page: "FindDispensary" },
{ title: "Buddy AI", icon: BrainCircuit, page: "BuddyAI" }];


function GlobalQuickActions() {
  const location = useLocation();
  const logSessionUrl = `${createPageUrl("NewSession")}?fullscreen=true&returnPath=${encodeURIComponent(location.pathname + location.search)}`;

  const actions = [
    { title: "Add to Stash", icon: QrCode, page: createPageUrl("Scanner") },
    { title: "Log Session", icon: Plus, page: logSessionUrl },
    { title: "Buddy AI", icon: BrainCircuit, page: createPageUrl("BuddyAI") },
    { title: "Find Dispensary", icon: Database, page: createPageUrl("FindDispensary") },
  ];

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button size="icon" className="rounded-full shadow-lg bg-green-600/90 hover:bg-green-700/90 backdrop-blur-sm border border-white/20 transition-all duration-200 h-10 w-10 md:h-12 md:w-12">
          <Sparkles className="w-5 h-5 md:w-6 md:h-6" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56 bg-white/95 backdrop-blur-md border border-white/30 shadow-xl">
        {actions.map((action) => (
          <DropdownMenuItem key={action.title} asChild className="hover:bg-green-50/80 focus:bg-green-50/80">
            <Link to={action.page} className="flex items-center gap-3 px-3 py-2.5">
              <action.icon className="w-4 h-4 text-gray-600" />
              <span className="font-medium text-gray-800">{action.title}</span>
            </Link>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [showMobileNav, setShowMobileNav] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  // Check for fullscreen mode
  const searchParams = new URLSearchParams(location.search);
  const isFullscreen = searchParams.get('fullscreen') === 'true';

  // Mobile navigation scroll behavior
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;

      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setShowMobileNav(false);
      } else if (currentScrollY < lastScrollY) {
        setShowMobileNav(true);
      }

      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const personalPages = personalNavItems.map((item) => createPageUrl(item.page));
  const socialPages = socialNavItems.map((item) => createPageUrl(item.page));
  const explorePages = exploreNavItems.map((item) => createPageUrl(item.page));

  const getCurrentTab = () => {
    if (location.pathname.startsWith(createPageUrl("Personal"))) return "Personal";
    if (personalPages.some((pageUrl) => location.pathname.startsWith(pageUrl))) return "Personal";
    if (['Scanner', 'NewSession', 'NewPost'].includes(currentPageName)) return 'Personal';
    if (location.pathname.startsWith(createPageUrl("Profile"))) return "Personal";

    if (location.pathname.startsWith(createPageUrl("Social"))) return "Social";
    if (socialPages.some((pageUrl) => location.pathname.startsWith(pageUrl))) return "Social";

    if (location.pathname.startsWith(createPageUrl("Explore"))) return "Explore";
    if (explorePages.some((pageUrl) => location.pathname.startsWith(pageUrl))) return "Explore";

    return "Personal";
  };
  const currentTab = getCurrentTab();

  if (location.pathname === "/") {
    return <Navigate to={createPageUrl("Personal")} replace />;
  }

  if (location.pathname === createPageUrl("Explore") || location.pathname === createPageUrl("Explore/")) {
    return <Navigate to={createPageUrl("Cannadex")} replace />;
  }

  // Handle fullscreen mode - bypasses the entire layout
  if (isFullscreen) {
    return <div className="h-screen w-screen">{children}</div>;
  }

  const showPersonalNavigation = currentTab === "Personal";
  const showSocialNavigation = currentTab === "Social";
  const showExploreNavigation = currentTab === "Explore";

  return (
    <SidebarProvider>
      <style>
        {`
          :root {
            --background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            --primary: #16a34a;
            --primary-foreground: #ffffff;
            --secondary: #22c55e;
            --accent: #84cc16;
            --muted: #f1f5f9;
            --border: #e2e8f0;
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.3);
          }
          
          body {
            background: var(--background);
            background-attachment: fixed;
          }
          
          .glass-card {
            background: var(--glass-bg);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid var(--glass-border);
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
          }
        `}
      </style>
      <div className="min-h-screen flex w-full" style={{ background: 'var(--background)' }}>
        <Sidebar className="border-r border-white/30 bg-white/90 backdrop-blur-xl shadow-xl">
          <SidebarHeader className="bg-stone-100 text-emerald-950 px-3 py-4 flex flex-col gap-2 border-b border-white/30 md:p-6 md:py-8">
            <div className="flex items-center justify-center">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68c1fedef3726c063c49fa29/b48cd1eb5_CuprPitchDeckPhasedpptx1.png" 
                alt="BudBook Logo" 
                className="h-20 md:h-24 w-auto object-contain"
              />
            </div>
          </SidebarHeader>

          <SidebarContent className="p-2 md:p-4">
            {showPersonalNavigation &&
            <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-2 py-2 md:py-3">
                  My Journey
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {personalNavItems.map((item) =>
                  <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                      asChild
                      className={`hover:bg-green-50/80 hover:text-green-700 transition-all duration-200 rounded-lg mb-1 min-h-[44px] ${
                      location.pathname.startsWith(createPageUrl(item.page)) ? 'bg-green-50/90 text-green-700 border border-green-200/50 shadow-sm' : ''}`
                      }>

                          <Link to={createPageUrl(item.page)} className="flex items-center gap-2 md:gap-3 px-3 py-2.5 font-medium text-sm">
                            <item.icon className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                            <span className="text-slate-950 mt-1 mb-1 px-3 py-2.5 text-sm font-normal capitalize peer/menu-button flex w-full items-center gap-2 overflow-hidden outline-none ring-sidebar-ring focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 group-has-[[data-sidebar=menu-action]]/menu-item:pr-8 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground group-data-[collapsible=icon]:!size-8 group-data-[collapsible=icon]:!p-2 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0 h-8 hover:bg-green-50/80 hover:text-green-700 transition-all duration-200 rounded-lg min-h-[44px] md:gap-3">{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                  )}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            }

            {showSocialNavigation &&
            <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-2 py-2 md:py-3">
                  Community
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {socialNavItems.map((item) =>
                  <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                      asChild
                      className={`hover:bg-blue-50/80 hover:text-blue-700 transition-all duration-200 rounded-lg mb-1 min-h-[44px] ${
                      location.pathname.startsWith(createPageUrl(item.page)) ? 'bg-blue-50/90 text-blue-700 border border-blue-200/50 shadow-sm' : ''}`
                      }>

                          <Link to={createPageUrl(item.page)} className="flex items-center gap-2 md:gap-3 px-3 py-2.5 font-medium text-sm">
                            <item.icon className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                  )}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            }

            {showExploreNavigation &&
            <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-2 py-2 md:py-3">
                  Explore
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {exploreNavItems.map((item) =>
                  <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                      asChild
                      className={`hover:bg-purple-50/80 hover:text-purple-700 transition-all duration-200 rounded-lg mb-1 min-h-[44px] ${
                      location.pathname.startsWith(createPageUrl(item.page)) ? 'bg-purple-50/90 text-purple-700 border border-purple-200/50 shadow-sm' : ''}`
                      }>

                          <Link to={createPageUrl(item.page)} className="flex items-center gap-2 md:gap-3 px-3 py-2.5 font-medium text-sm">
                            <item.icon className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                  )}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            }
          </SidebarContent>

          <SidebarFooter className="border-t border-white/30 p-2 md:p-4 space-y-3">
            <SidebarMenu>
                <SidebarMenuItem>
                    <SidebarMenuButton
                  asChild
                  className={`hover:bg-green-50/80 hover:text-green-700 transition-all duration-200 rounded-lg min-h-[44px] ${
                  location.pathname.startsWith(createPageUrl('Profile')) ? 'bg-green-50/90 text-green-700 border border-green-200/50 shadow-sm' : ''}`
                  }>

                        <Link to={createPageUrl('Profile')} className="flex items-center gap-2 md:gap-3 px-3 py-2.5 font-medium text-sm">
                            <User className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                            <span>My Profile</span>
                        </Link>
                    </SidebarMenuButton>
                </SidebarMenuItem>
            </SidebarMenu>
            <div className="text-center pt-2 border-t border-white/20">
              <p className="text-xs text-gray-500 font-medium">
                Track responsibly
              </p>
              <div className="w-full h-1 bg-gradient-to-r from-green-400/60 to-green-600/60 rounded-full mt-2 shadow-sm"></div>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col overflow-hidden">
          <header className="bg-white/85 backdrop-blur-xl border-b border-white/30 px-3 md:px-6 py-3 sticky top-0 z-10 shadow-sm">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <SidebarTrigger className="hover:bg-green-50/80 p-2 rounded-lg transition-all duration-200 glass-card border-0" />
              </div>

              <div className="hidden md:flex items-center gap-2 bg-white/60 backdrop-blur-md p-1.5 rounded-xl border border-white/40 shadow-lg">
                {mainTabs.map((tab) =>
                <Link to={createPageUrl(tab.page)} key={tab.page}>
                    <Button
                    variant={currentTab === tab.page ? 'default' : 'ghost'}
                    className={`gap-2 transition-all duration-200 font-medium ${
                    currentTab === tab.page ?
                    'bg-white/90 shadow-md border border-white/50 text-gray-900' :
                    'hover:bg-white/70 text-gray-600 hover:text-gray-900'}`
                    }
                    size="sm">

                      <tab.icon size={16} /> {tab.title}
                    </Button>
                  </Link>
                )}
              </div>

              <div className="flex items-center">
                <div className="hidden md:block">
                  <GlobalQuickActions />
                </div>
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-auto bg-gradient-to-br from-slate-50 to-blue-50/30">
            {children}
          </div>

          <footer className={`md:hidden border-t bg-white/90 backdrop-blur-xl p-3 fixed bottom-0 left-0 right-0 z-20 transition-all duration-300 ease-in-out shadow-2xl ${
          showMobileNav ? 'translate-y-0 opacity-100' : 'translate-y-full opacity-0'}`
          }>
            <div className="grid grid-cols-4 items-center gap-1">
              {mainTabs.map((tab) =>
              <Link
                to={createPageUrl(tab.page)}
                key={tab.page}
                className={`flex flex-col items-center justify-center gap-1 p-3 rounded-xl transition-all duration-200 min-h-[60px] ${
                currentTab === tab.page ?
                'text-green-600 bg-green-50/90 shadow-sm border border-green-200/50' :
                'text-gray-500 hover:text-gray-700 hover:bg-white/60'}`
                }>

                    <tab.icon size={22} />
                    <span className="text-xs font-medium">{tab.title}</span>
                 </Link>
              )}
               <div className="flex justify-center items-center p-2">
                  <GlobalQuickActions />
               </div>
            </div>
          </footer>
        </main>
      </div>
    </SidebarProvider>);

}
