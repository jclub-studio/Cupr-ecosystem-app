import Scanner from './pages/Scanner';
import NewSession from './pages/NewSession';
import FindDispensary from './pages/FindDispensary';
import NewPost from './pages/NewPost';
import BuddyAI from './pages/BuddyAI';
import Personal from './pages/Personal';
import Social from './pages/Social';
import Explore from './pages/Explore';
import MyStash from './pages/MyStash';
import Journal from './pages/Journal';
import Cannadex from './pages/Cannadex';
import Learn from './pages/Learn';
import SharedChat from './pages/SharedChat';
import Profile from './pages/Profile';
import MyCircles from './pages/MyCircles';
import Friends from './pages/Friends';
import Shops from './pages/Shops';
import Media from './pages/Media';
import ConfirmSessionParticipation from './pages/ConfirmSessionParticipation';
import CircleDetails from './pages/CircleDetails';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Scanner": Scanner,
    "NewSession": NewSession,
    "FindDispensary": FindDispensary,
    "NewPost": NewPost,
    "BuddyAI": BuddyAI,
    "Personal": Personal,
    "Social": Social,
    "Explore": Explore,
    "MyStash": MyStash,
    "Journal": Journal,
    "Cannadex": Cannadex,
    "Learn": Learn,
    "SharedChat": SharedChat,
    "Profile": Profile,
    "MyCircles": MyCircles,
    "Friends": Friends,
    "Shops": Shops,
    "Media": Media,
    "ConfirmSessionParticipation": ConfirmSessionParticipation,
    "CircleDetails": CircleDetails,
}

export const pagesConfig = {
    mainPage: "Personal",
    Pages: PAGES,
    Layout: __Layout,
};